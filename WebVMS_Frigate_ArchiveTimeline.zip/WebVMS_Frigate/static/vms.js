/* Web VMS frontend. Keeps the original Flask/HLS/DVRIP API contract. */
(() => {
  'use strict';
  const $ = (s, root = document) => root.querySelector(s);
  const $$ = (s, root = document) => Array.from(root.querySelectorAll(s));
  const USER = window.WEBVMS_USER || { username: 'user', role: 'viewer', theme: 'auto' };
  const IS_ADMIN = USER.role === 'admin';
  const state = {
    view: 'live', theme: USER.theme || 'auto', cameras: [], groups: [], users: [],
    gridCols: 2, selectedGroup: '', liveSlots: [], slotCounter: 0, liveHls: new Map(),
    archive: { camId: '', start: '', end: '', mode: 'time', records: [], active: null, url: '', loading: false, error: '', playheadMs: null, playbackBaseMs: null, selectionStartMs: null, selectionEndMs: null, drag: null },
    deviceCamId: '', deviceInfo: null, cameraSearch: '', userSearch: ''
  };

  const ICONS = {
    grid: '<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/>',
    archive: '<path d="M3 4h18v4H3z"/><path d="M5 8v12h14V8M10 12h4"/>',
    camera: '<rect x="3" y="6" width="13" height="12" rx="2"/><path d="m16 10 5-3v10l-5-3"/>',
    folder: '<path d="M3 6a2 2 0 0 1 2-2h5l2 2h7a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>',
    users: '<path d="M16 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="10" cy="7" r="4"/><path d="M20 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75"/>',
    sliders: '<path d="M4 21v-7m0-4V3m8 18v-9m0-4V3m8 18v-5m0-4V3M2 14h4m4-6h4m4 8h4"/>',
    menu: '<path d="M4 6h16M4 12h16M4 18h16"/>', monitor: '<rect x="3" y="4" width="18" height="13" rx="2"/><path d="M8 21h8m-4-4v4"/>',
    sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2v2m0 16v2M4.93 4.93l1.42 1.42m11.3 11.3 1.42 1.42M2 12h2m16 0h2M4.93 19.07l1.42-1.42m11.3-11.3 1.42-1.42"/>',
    moon: '<path d="M20.9 13A9 9 0 0 1 11 3.1 9 9 0 1 0 20.9 13Z"/>', logout: '<path d="M10 17l5-5-5-5M15 12H3"/><path d="M12 3h6a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-6"/>',
    plus: '<path d="M12 5v14M5 12h14"/>', search: '<circle cx="11" cy="11" r="7"/><path d="m20 20-4-4"/>',
    play: '<path d="m8 5 11 7-11 7z"/>', pause: '<path d="M8 5h3v14H8zM15 5h3v14h-3z"/>',
    stop: '<rect x="5" y="5" width="14" height="14" rx="2"/>', refresh: '<path d="M20 7v5h-5M4 17v-5h5"/><path d="M5.6 9A7 7 0 0 1 18 6l2 6M4 12l2 6a7 7 0 0 0 12.4-3"/>',
    edit: '<path d="M12 20h9"/><path d="M16.5 3.5a2.12 2.12 0 0 1 3 3L8 18l-4 1 1-4Z"/>',
    trash: '<path d="M3 6h18M8 6V4h8v2m3 0-1 14H6L5 6m4 4v6m6-6v6"/>',
    close: '<path d="m18 6-12 12M6 6l12 12"/>', check: '<path d="m5 12 4 4L19 6"/>',
    download: '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M7 10l5 5 5-5M12 15V3"/>',
    expand: '<path d="M8 3H5a2 2 0 0 0-2 2v3m13-5h3a2 2 0 0 1 2 2v3M3 16v3a2 2 0 0 0 2 2h3m8 0h3a2 2 0 0 0 2-2v-3"/>',
    info: '<circle cx="12" cy="12" r="10"/><path d="M12 16v-4m0-4h.01"/>',
    calendar: '<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M16 3v4M8 3v4M3 10h18"/>',
    server: '<rect x="3" y="3" width="18" height="7" rx="2"/><rect x="3" y="14" width="18" height="7" rx="2"/><path d="M7 6h.01M7 17h.01M11 6h6m-6 11h6"/>',
    shield: '<path d="M12 22s8-4 8-11V5l-8-3-8 3v6c0 7 8 11 8 11Z"/><path d="m9 12 2 2 4-4"/>',
    alert: '<path d="M10.3 3.9 1.9 18.4A2 2 0 0 0 3.6 21h16.8a2 2 0 0 0 1.7-2.6L13.7 3.9a2 2 0 0 0-3.4 0Z"/><path d="M12 9v4m0 4h.01"/>',
    link: '<path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"/>',
    clock: '<circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/>',
    circle: '<circle cx="12" cy="12" r="9"/>',
    key: '<circle cx="8" cy="15" r="5"/><path d="m11.5 11.5 9-9m-2 2 2 2m-5 1 2 2"/>',
    eye: '<path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7-10-7-10-7Z"/><circle cx="12" cy="12" r="3"/>',
    route: '<circle cx="6" cy="6" r="3"/><circle cx="18" cy="18" r="3"/><path d="M9 6h3a3 3 0 0 1 3 3v3a3 3 0 0 0 3 3"/>',
    arrowLeft: '<path d="M19 12H5m7 7-7-7 7-7"/>' ,
    arrowRight: '<path d="M5 12h14m-7-7 7 7-7 7"/>'
  };
  function icon(name, cls = '') { return `<svg class="${cls}" viewBox="0 0 24 24" aria-hidden="true">${ICONS[name] || ICONS.info}</svg>`; }
  function esc(value) { return String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }
  function titleCase(value) { return value ? value[0].toUpperCase() + value.slice(1) : ''; }
  function nowLocalInput(date = new Date()) { const p = n => String(n).padStart(2,'0'); return `${date.getFullYear()}-${p(date.getMonth()+1)}-${p(date.getDate())}T${p(date.getHours())}:${p(date.getMinutes())}`; }
  function inputTime(value) { return value ? String(value).replace(' ','T').slice(0,19) : ''; }
  function localDateTimeSeconds(ms) { const d=new Date(ms); if(!Number.isFinite(d.getTime()))return ''; const p=n=>String(n).padStart(2,'0'); return `${d.getFullYear()}-${p(d.getMonth()+1)}-${p(d.getDate())}T${p(d.getHours())}:${p(d.getMinutes())}:${p(d.getSeconds())}`; }
  function apiDateTimeSeconds(ms) { return localDateTimeSeconds(ms).replace('T',' '); }
  function formatDateTimeSeconds(ms) { const d=new Date(ms); if(!Number.isFinite(d.getTime()))return '—'; return d.toLocaleDateString('ru-RU',{day:'2-digit',month:'short'})+' '+d.toLocaleTimeString('ru-RU',{hour:'2-digit',minute:'2-digit',second:'2-digit'}); }
  function apiTime(value) { return value ? (value.replace('T',' ') + (value.length === 16 ? ':00' : '')) : ''; }
  function parseTime(value) { const d = new Date(String(value || '').replace(' ','T')); return Number.isNaN(d.getTime()) ? null : d; }
  function fmtTime(value) { const d = parseTime(value); if (!d) return '—'; return d.toLocaleTimeString('ru-RU',{hour:'2-digit',minute:'2-digit',second:'2-digit'}); }
  function fmtDate(value) { const d = parseTime(value); if (!d) return '—'; return d.toLocaleDateString('ru-RU',{day:'2-digit',month:'short',year:'numeric'}); }
  function durationText(start, end) { const a=parseTime(start),b=parseTime(end);if(!a||!b)return '—';let s=Math.max(0,Math.round((b-a)/1000));const h=Math.floor(s/3600),m=Math.floor(s%3600/60),sec=s%60;return h?`${h} ч ${m} мин`:(m?`${m} мин ${sec} с`:`${sec} с`); }
  function camById(id) { return state.cameras.find(c => c.id === id); }
  function groupById(id) { return state.groups.find(g => g.id === id); }
  function protocolLabel(cam) { return cam?.protocol === 'dvrip' ? 'DVRIP' : 'RTSP / ONVIF'; }
  function showToast(message, type = 'success') {
    const root = $('#toast-root'); const item = document.createElement('div'); item.className = `toast ${type === 'error' ? 'error' : type === 'warning' ? 'warning' : ''}`;
    const sym = type === 'error' ? 'alert' : type === 'warning' ? 'info' : 'check'; item.innerHTML = `${icon(sym)}<div class="toast-message">${esc(message)}</div>`; root.appendChild(item); setTimeout(() => item.remove(), 4500);
  }
  async function api(url, options = {}) {
    const opts = {...options, headers: {...(options.headers || {})}};
    if (opts.body && typeof opts.body !== 'string') { opts.headers['Content-Type'] = 'application/json'; opts.body = JSON.stringify(opts.body); }
    const response = await fetch(url, opts);
    let data = {}; const type = response.headers.get('content-type') || '';
    if (type.includes('application/json')) data = await response.json();
    if (response.status === 401) { window.location.href = '/login'; throw new Error('Сеанс завершён. Войдите снова.'); }
    if (!response.ok) throw new Error(data.error || `Ошибка ${response.status}`);
    return data;
  }

  async function init() {
    $$('[data-icon]').forEach(el => { el.innerHTML = icon(el.dataset.icon); });
    $('#user-name').textContent = USER.username || 'Пользователь';
    $('#user-avatar').textContent = (USER.username || 'U').slice(0,1).toUpperCase();
    $('#user-role').textContent = IS_ADMIN ? 'Администратор' : 'Просмотр';
    $$('.admin-only').forEach(el => { if (!IS_ADMIN) el.remove(); });
    document.documentElement.dataset.theme = state.theme;
    updateThemeControls();
    $$('.nav-item').forEach(btn => btn.addEventListener('click', () => activateView(btn.dataset.view)));
    $$('[data-theme-choice]').forEach(btn => btn.addEventListener('click', () => setTheme(btn.dataset.themeChoice)));
    $('#mobile-menu').addEventListener('click', () => document.body.classList.toggle('menu-open'));
    document.addEventListener('keydown', e => { if (e.key === 'Escape') { closeModal(); document.body.classList.remove('menu-open'); } });
    try { await loadData(); } catch (e) { showToast(e.message, 'error'); }
    renderCurrentView();
  }

  async function loadData() {
    const [cameras, groups] = await Promise.all([api('/api/cameras'), api('/api/groups')]);
    state.cameras = Array.isArray(cameras) ? cameras : [];
    state.groups = Array.isArray(groups) ? groups : [];
    state.cameras.sort((a,b) => String(a.name).localeCompare(String(b.name),'ru'));
    state.groups.sort((a,b) => String(a.name).localeCompare(String(b.name),'ru'));
    $('#nav-camera-count').textContent = state.cameras.length;
    if (IS_ADMIN) {
      try { const users = await api('/api/users'); state.users = Array.isArray(users) ? users : []; }
      catch (e) { state.users = []; }
    }
    const dvrCameras = state.cameras.filter(c => c.protocol === 'dvrip');
    if (!dvrCameras.some(c => c.id === state.archive.camId)) state.archive.camId = dvrCameras[0]?.id || '';
    if (!state.cameras.some(c => c.id === state.deviceCamId)) state.deviceCamId = dvrCameras[0]?.id || state.cameras[0]?.id || '';
    if (!state.liveSlots.length) state.liveSlots = state.cameras.map(c => ({ uid: ++state.slotCounter, camId: c.id, stream: state.cameras.length > 1 ? 'sub' : 'main' }));
    else state.liveSlots = state.liveSlots.filter(s => camById(s.camId));
  }

  function updateThemeControls() {
    $$('[data-theme-choice]').forEach(btn => { const active = btn.dataset.themeChoice === state.theme; btn.classList.toggle('selected', active); btn.setAttribute('aria-pressed', active ? 'true' : 'false'); });
  }
  async function setTheme(theme) {
    state.theme = ['auto','light','dark'].includes(theme) ? theme : 'auto';
    document.documentElement.dataset.theme = state.theme; updateThemeControls();
    try { await api('/api/profile/theme', {method:'POST', body:{theme:state.theme}}); }
    catch (e) { showToast('Тема применена в браузере, но не сохранена: ' + e.message, 'warning'); }
  }

  const TITLES = { live:'Просмотр', archive:'Архив', cameras:'Камеры', groups:'Группы', users:'Пользователи', devices:'Устройства' };
  function activateView(view) {
    if (!TITLES[view] || (!IS_ADMIN && ['cameras','groups','users','devices'].includes(view))) return;
    if (state.view === 'live' && view !== 'live') stopAllLivePlayers();
    state.view = view; document.body.classList.remove('menu-open');
    $$('.nav-item').forEach(btn => btn.classList.toggle('active', btn.dataset.view === view));
    $('#current-section').textContent = TITLES[view]; renderCurrentView();
  }
  function renderCurrentView() {
    $('#current-section').textContent = TITLES[state.view] || 'Просмотр';
    if (state.view === 'live') renderLive();
    else if (state.view === 'archive') renderArchive();
    else if (state.view === 'cameras') renderCameras();
    else if (state.view === 'groups') renderGroups();
    else if (state.view === 'users') renderUsers();
    else if (state.view === 'devices') renderDevices();
  }
  function pageHeader(title, description, actions = '') {
    return `<div class="page-header"><div class="page-heading"><h1 class="page-title">${title}</h1><p class="page-description">${description}</p></div><div class="page-actions">${actions}</div></div>`;
  }
  function emptyState(title, description, action = '') {
    return `<div class="empty-state"><div class="empty-icon">${icon('camera')}</div><h3>${esc(title)}</h3><p>${esc(description)}</p>${action}</div>`;
  }

  // LIVE VIEW
  function renderLive() {
    // Rerendering replaces video elements, so detach old HLS instances first.
    if (state.liveHls.size) stopAllLivePlayers();
    const groupOptions = state.groups.map(g => `<option value="${esc(g.id)}" ${state.selectedGroup === g.id ? 'selected' : ''}>${esc(g.name)}</option>`).join('');
    const actions = IS_ADMIN ? `<button class="btn btn-primary" id="live-add-camera">${icon('plus')} Добавить камеру</button>` : '';
    let slots = state.liveSlots;
    if (state.selectedGroup) {
      const g = groupById(state.selectedGroup); const ids = g?.camera_ids || [];
      slots = ids.map(id => state.liveSlots.find(s => s.camId === id) || {uid:++state.slotCounter,camId:id,stream:'sub'}).filter(s => camById(s.camId));
    }
    const metrics = `<div class="metric-row"><div class="metric-card"><div class="metric-icon">${icon('camera')}</div><div><div class="metric-value">${state.cameras.length}</div><div class="metric-label">Камер добавлено</div></div></div><div class="metric-card"><div class="metric-icon">${icon('grid')}</div><div><div class="metric-value">${slots.length}</div><div class="metric-label">На текущем экране</div></div></div><div class="metric-card"><div class="metric-icon">${icon('folder')}</div><div><div class="metric-value">${state.groups.length}</div><div class="metric-label">Групп камер</div></div></div></div>`;
    $('#main-content').innerHTML = pageHeader('Просмотр', 'Живые потоки со всех подключённых камер.', actions) + metrics + `<div class="toolbar"><div class="toolbar-left"><span class="toolbar-label">Группа</span><select id="live-group-filter" class="select"><option value="">Все камеры</option>${groupOptions}</select><span class="toolbar-label">Сетка</span><div class="segmented" aria-label="Количество столбцов">${[1,2,3,4].map(n=>`<button data-grid="${n}" class="${state.gridCols===n?'active':''}" title="${n} столбец(а)">${n}×${n}</button>`).join('')}</div></div><div class="toolbar-right"><span class="small-muted">${slots.length} видеопотоков</span><button class="btn btn-sm" id="live-refresh">${icon('refresh')} Обновить</button></div></div><div class="camera-wall" id="camera-wall" style="--grid-cols:${state.gridCols}">${slots.map((slot,i)=>liveTile(slot,i)).join('')}${state.cameras.length ? `<button class="add-tile" id="live-add-tile"><span class="add-circle">${icon('plus')}</span><span>Добавить камеру</span></button>` : ''}</div>`;
    $('#live-group-filter').addEventListener('change', e => {
      stopAllLivePlayers(); state.selectedGroup = e.target.value;
      if (state.selectedGroup) { const g=groupById(state.selectedGroup); state.liveSlots=(g?.camera_ids||[]).filter(id=>camById(id)).map(id=>({uid:++state.slotCounter,camId:id,stream:'sub'})); }
      else state.liveSlots=state.cameras.map(c=>({uid:++state.slotCounter,camId:c.id,stream:state.cameras.length>1?'sub':'main'}));
      renderLive();
    });
    $$('[data-grid]').forEach(btn => btn.addEventListener('click', () => {state.gridCols=Number(btn.dataset.grid);renderLive();}));
    $('#live-refresh').addEventListener('click', () => { renderLive(); showToast('Видеопотоки перезапущены'); });
    ['#live-add-camera','#live-add-tile'].forEach(sel => {const b=$(sel);if(b)b.addEventListener('click',addLiveSlot);});
    $$('.tile-camera-select').forEach(el => el.addEventListener('change', () => changeLiveCamera(el.dataset.uid, el.value)));
    $$('.tile-stream-select').forEach(el => el.addEventListener('change', () => changeLiveStream(el.dataset.uid, el.value)));
    $$('.tile-remove').forEach(el => el.addEventListener('click', () => removeLiveSlot(el.dataset.uid)));
    $$('.tile-fullscreen').forEach(el => el.addEventListener('click', () => {const v=$(`#live-video-${el.dataset.uid}`);if(v?.requestFullscreen)v.requestFullscreen();}));
    if (slots.length) requestAnimationFrame(() => slots.forEach(s => attachLivePlayer(s)));
  }
  function liveTile(slot, index) {
    const cam=camById(slot.camId); if(!cam)return '';
    const options=state.cameras.map(c=>`<option value="${esc(c.id)}" ${c.id===cam.id?'selected':''}>${esc(c.name)}</option>`).join('');
    return `<article class="camera-tile" data-tile="${slot.uid}"><div class="tile-head"><div class="tile-name" title="${esc(cam.name)}">${esc(cam.name)}</div><span class="live-badge">LIVE</span><div class="tile-actions"><select class="select select-sm tile-camera-select" data-uid="${slot.uid}" aria-label="Выбрать камеру">${options}</select><select class="select select-sm tile-stream-select" data-uid="${slot.uid}" aria-label="Качество"><option value="main" ${slot.stream==='main'?'selected':''}>Основной</option><option value="sub" ${slot.stream==='sub'?'selected':''}>Субпоток</option></select><button class="icon-btn btn-icon tile-fullscreen" data-uid="${slot.uid}" title="На весь экран">${icon('expand')}</button><button class="icon-btn btn-icon tile-remove" data-uid="${slot.uid}" title="Убрать с экрана">${icon('close')}</button></div></div><div class="video-stage"><video id="live-video-${slot.uid}" muted autoplay playsinline></video><div class="video-overlay" id="live-overlay-${slot.uid}"><div class="spin"></div><span class="overlay-title">Подключение к камере</span><span class="overlay-msg">${esc(cam.ip)} · ${esc(protocolLabel(cam))}</span></div></div><div class="tile-foot"><span class="ip-label">${esc(cam.ip)}${cam.protocol==='dvrip' ? ` · канал ${Number(cam.channel||0)+1}` : ''}</span><span class="tile-subtitle">${slot.stream==='main'?'Основной поток':'Субпоток'}</span></div></article>`;
  }
  function attachLivePlayer(slot) {
    const video=$(`#live-video-${slot.uid}`);const overlay=$(`#live-overlay-${slot.uid}`);if(!video||!camById(slot.camId))return;
    const url=`/live/${encodeURIComponent(slot.camId)}/${slot.stream}/index.m3u8`;
    const showError=msg=>{if(overlay){overlay.classList.remove('hidden');overlay.innerHTML=`${icon('alert')}<span class="overlay-title">Не удалось открыть поток</span><span class="overlay-msg">${esc(msg||'Проверьте подключение к устройству и настройки FFmpeg.')}</span>`;}};
    video.addEventListener('playing',()=>{if(overlay)overlay.classList.add('hidden');},{once:false});
    video.addEventListener('error',()=>showError('Поток завершился или недоступен.'));
    if(window.Hls && window.Hls.isSupported()){
      const hls=new Hls({liveSyncDurationCount:3,lowLatencyMode:true,enableWorker:true});state.liveHls.set(slot.uid,{hls,camId:slot.camId,stream:slot.stream});
      hls.loadSource(url);hls.attachMedia(video);
      hls.on(Hls.Events.ERROR,(_ev,data)=>{if(data.fatal){showError(data.details||data.type);hls.destroy();state.liveHls.delete(slot.uid);}});
    } else if(video.canPlayType('application/vnd.apple.mpegurl')){video.src=url;video.play().catch(()=>{});}
    else showError('Браузер не поддерживает HLS.');
    setTimeout(()=>{if(overlay&&!overlay.classList.contains('hidden')){const title=overlay.querySelector('.overlay-title');if(title)title.textContent='Ожидание видеопотока';}},9000);
  }
  function stopAllLivePlayers() {
    const stopping=new Set();
    for(const [uid,item] of state.liveHls.entries()){
      try{item.hls?.destroy();}catch(_){}
      stopping.add(`${item.camId}|${item.stream}`);
      const v=$(`#live-video-${uid}`);if(v){v.pause();v.removeAttribute('src');v.load();}
    }
    state.liveHls.clear();
    // If playback uses native HLS (Safari), include the slots when stopping server-side FFmpeg.
    for(const slot of state.liveSlots) stopping.add(`${slot.camId}|${slot.stream}`);
    for(const key of stopping){const [cam_id,stream]=key.split('|');fetch('/api/live/stop',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({cam_id,stream})}).catch(()=>{});}
  }
  function addLiveSlot() {
    if(!state.cameras.length){showToast('Сначала добавьте хотя бы одну камеру.','warning');if(IS_ADMIN)openCameraModal();return;}
    const active = state.selectedGroup ? (groupById(state.selectedGroup)?.camera_ids||[]) : [];
    const candidate=state.cameras.find(c=>!state.liveSlots.some(s=>s.camId===c.id) && (!state.selectedGroup||active.includes(c.id))) || state.cameras[0];
    stopAllLivePlayers();state.liveSlots.push({uid:++state.slotCounter,camId:candidate.id,stream:'sub'});renderLive();
  }
  function changeLiveCamera(uid, camId) {
    const slot=state.liveSlots.find(s=>s.uid===Number(uid));if(!slot)return;const old={camId:slot.camId,stream:slot.stream};
    slot.camId=camId;stopAllLivePlayers();renderLive();stopIfUnused(old);
  }
  function changeLiveStream(uid, stream) {const slot=state.liveSlots.find(s=>s.uid===Number(uid));if(!slot)return;slot.stream=stream;stopAllLivePlayers();renderLive();}
  function stopIfUnused(old){if(!state.liveSlots.some(s=>s.camId===old.camId&&s.stream===old.stream))fetch('/api/live/stop',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(old)}).catch(()=>{});}
  function removeLiveSlot(uid) {const slot=state.liveSlots.find(s=>s.uid===Number(uid));if(!slot)return;state.liveSlots=state.liveSlots.filter(s=>s.uid!==Number(uid));stopAllLivePlayers();renderLive();}

  // ARCHIVE — DVR-native playback with a seekable time ruler and clip selection.
  function initArchiveDates() {
    if(!state.archive.start){state.archive.end=nowLocalInput();state.archive.start=nowLocalInput(new Date(Date.now()-2*3600*1000));}
  }
  function renderArchive() {
    initArchiveDates();
    const dvrCameras=state.cameras.filter(c=>c.protocol==='dvrip');
    const camOptions=dvrCameras.map(c=>`<option value="${esc(c.id)}" ${state.archive.camId===c.id?'selected':''}>${esc(c.name)} · ${esc(c.ip)} / канал ${Number(c.channel||0)+1}</option>`).join('');
    const actions=`<button class="btn" id="archive-reset">${icon('refresh')} Сбросить</button>`;
    const filters=`<div class="panel"><div class="panel-head"><div><h2 class="panel-title">Параметры поиска</h2><p class="panel-note">Записи запрашиваются с HDD регистратора напрямую.</p></div></div><div class="panel-body form-stack archive-filters"><div class="form-field"><label for="archive-cam">Камера / канал</label><select class="select" id="archive-cam" ${dvrCameras.length?'':'disabled'}>${camOptions||'<option value="">Нет DVRIP-устройств</option>'}</select></div><div class="form-field"><label for="archive-mode">Тип поиска</label><select id="archive-mode" class="select"><option value="time" ${state.archive.mode==='time'?'selected':''}>По времени — объединённые отрезки</option><option value="files" ${state.archive.mode==='files'?'selected':''}>Список файлов регистратора</option></select></div><div class="form-field"><label for="archive-start">Начало периода</label><input class="field" id="archive-start" type="datetime-local" step="1" value="${esc(state.archive.start)}"></div><div class="form-field"><label for="archive-end">Конец периода</label><input class="field" id="archive-end" type="datetime-local" step="1" value="${esc(state.archive.end)}"></div><div class="search-action"><button class="btn btn-primary" id="archive-search" style="width:100%">${icon('search')} Найти записи</button></div></div></div>`;
    const player=`<section class="panel archive-player-panel"><div class="panel-head"><div><h2 class="panel-title">Воспроизведение</h2><p class="panel-note" id="archive-playing-label">${state.archive.active?esc(state.archive.active.FilePath||state.archive.active.FileName||'Воспроизведение по времени'):'Выберите запись или нажмите на шкалу времени'}</p></div><span class="badge">${icon('archive')} Архив DVR</span></div><div class="archive-player" id="archive-player"><video id="archive-video" class="${state.archive.url?'':'hidden'}" controls playsinline preload="metadata"></video><div class="player-placeholder ${state.archive.url?'hidden':''}" id="archive-placeholder">${icon('play')}<b>Архив не выбран</b><span class="small-muted">Выберите запись или нажмите на нужное время на шкале ниже</span></div></div><div class="archive-controls"><div class="archive-controls-left"><span class="small-muted">Скорость</span><select class="select select-sm" id="archive-speed"><option value="0.5">0,5×</option><option value="1" selected>1×</option><option value="1.5">1,5×</option><option value="2">2×</option><option value="4">4×</option></select><span class="archive-live-time" id="archive-current-time">${state.archive.playheadMs?esc(formatDateTimeSeconds(state.archive.playheadMs)):'—'}</span></div><div class="archive-controls-right"><button class="btn btn-sm" id="archive-jump-back" title="На 30 секунд назад">${icon('arrowLeft')} −30 с</button><button class="btn btn-sm" id="archive-jump-forward" title="На 30 секунд вперёд">+30 с ${icon('arrowRight')}</button><a class="btn btn-sm ${(state.archive.active?.FilePath||state.archive.active?.FileName)?'':'hidden'}" id="archive-download-active" href="#">${icon('download')} Скачать запись</a><button class="btn btn-sm" id="archive-fullscreen">${icon('expand')} На весь экран</button></div></div></section>`;
    const timeline=`<section class="panel archive-timeline-panel"><div class="panel-head archive-timeline-head"><div><h2 class="panel-title">Шкала времени</h2><p class="panel-note">Нажмите на время для перехода. Протяните мышью по шкале, чтобы выделить фрагмент для скачивания.</p></div><div class="archive-timeline-legend"><span><i class="legend-recorded"></i> Есть запись</span><span><i class="legend-selection"></i> Выбранный фрагмент</span></div></div><div id="archive-timeline-body">${renderArchiveTimelineHtml()}</div><div class="archive-selection-footer"><div><span class="small-muted">Фрагмент для скачивания</span><strong id="archive-selection-label">${selectionLabel()}</strong></div><button class="btn btn-primary" id="archive-download-selection" ${state.archive.selectionStartMs!==null&&state.archive.selectionEndMs!==null?'':'disabled'}>${icon('download')} Скачать фрагмент</button></div></section>`;
    const list=`<section class="panel"><div class="panel-head"><div><h2 class="panel-title">Найденные отрезки</h2><p class="panel-note" id="archive-result-summary">${state.archive.loading?'Поиск на регистраторе…':`Найдено: ${state.archive.records.length}`}</p></div><span class="badge">${state.archive.mode==='time'?'Отрезки':'Файлы'}</span></div><div id="archive-results">${renderArchiveResultsHtml()}</div></section>`;
    const fragment=`<section class="panel"><div class="panel-head"><div><h2 class="panel-title">Экспорт фрагмента</h2><p class="panel-note">Можно указать точное начало и конец вручную.</p></div></div><div class="panel-body form-stack"><div class="form-field"><label for="download-start">От</label><input class="field" id="download-start" type="datetime-local" step="1" value="${esc(state.archive.selectionStartMs!==null?localDateTimeSeconds(state.archive.selectionStartMs):state.archive.start)}"></div><div class="form-field"><label for="download-end">До</label><input class="field" id="download-end" type="datetime-local" step="1" value="${esc(state.archive.selectionEndMs!==null?localDateTimeSeconds(state.archive.selectionEndMs):state.archive.end)}"></div><button id="archive-download-range" class="btn btn-primary">${icon('download')} Скачать указанный период</button><div class="notice">${icon('info')} Видео передаётся напрямую с регистратора. Локальная запись на сервере не включается.</div></div></section>`;
    $('#main-content').innerHTML=pageHeader('Архив','Поиск, перемотка по времени и экспорт выбранного фрагмента с диска регистратора.',actions)+(!dvrCameras.length?emptyState('Нет DVRIP-камер','Архив доступен для камер, добавленных как видеорегистратор DVRIP.',IS_ADMIN?`<button class="btn btn-primary" id="archive-add-camera">${icon('plus')} Добавить регистратор</button>`:''):`<div class="archive-layout"><div class="archive-main">${player}${timeline}${list}</div><aside class="form-stack">${filters}${fragment}</aside></div>`);
    $('#archive-add-camera')?.addEventListener('click',openCameraModal);
    $('#archive-reset')?.addEventListener('click',()=>{state.archive.start=nowLocalInput(new Date(Date.now()-2*3600*1000));state.archive.end=nowLocalInput();state.archive.records=[];state.archive.active=null;state.archive.url='';state.archive.playheadMs=null;state.archive.playbackBaseMs=null;state.archive.selectionStartMs=null;state.archive.selectionEndMs=null;state.archive.error='';renderArchive();});
    $('#archive-search')?.addEventListener('click',searchArchive);
    $('#archive-cam')?.addEventListener('change',e=>{state.archive.camId=e.target.value;state.archive.active=null;state.archive.url='';});
    $('#archive-mode')?.addEventListener('change',e=>{state.archive.mode=e.target.value;});
    $('#archive-speed')?.addEventListener('change',e=>{const video=$('#archive-video');if(video)video.playbackRate=Number(e.target.value);});
    $('#archive-fullscreen')?.addEventListener('click',()=>{const el=$('#archive-player');if(!document.fullscreenElement)el?.requestFullscreen?.();else document.exitFullscreen?.();});
    $('#archive-jump-back')?.addEventListener('click',()=>jumpArchive(-30));
    $('#archive-jump-forward')?.addEventListener('click',()=>jumpArchive(30));
    $('#archive-download-range')?.addEventListener('click',downloadArchiveRange);
    const syncManualSelection=()=>{const ss=parseTime($('#download-start')?.value)?.getTime(),ee=parseTime($('#download-end')?.value)?.getTime();if(Number.isFinite(ss)&&Number.isFinite(ee)&&ee>ss)setArchiveSelection(ss,ee,false);};
    $('#download-start')?.addEventListener('change',syncManualSelection);$('#download-end')?.addEventListener('change',syncManualSelection);
    $('#archive-download-selection')?.addEventListener('click',()=>{if(state.archive.selectionStartMs===null||state.archive.selectionEndMs===null)return;$('#download-start').value=localDateTimeSeconds(state.archive.selectionStartMs);$('#download-end').value=localDateTimeSeconds(state.archive.selectionEndMs);downloadArchiveRange();});
    $('#archive-download-active')?.addEventListener('click',e=>{if(!state.archive.active){e.preventDefault();return;}});
    if(state.archive.url){const v=$('#archive-video');v.src=state.archive.url;$('#archive-placeholder')?.classList.add('hidden');v.load();}
    bindArchiveVideo();bindArchiveResults();bindArchiveTimeline();updateArchivePlayheadVisual();
  }
  function selectionLabel() {
    const a=state.archive;
    if(a.selectionStartMs===null||a.selectionEndMs===null)return 'Не выбран';
    return `${formatDateTimeSeconds(a.selectionStartMs)} — ${formatDateTimeSeconds(a.selectionEndMs)} · ${durationText(new Date(a.selectionStartMs).toISOString(),new Date(a.selectionEndMs).toISOString())}`;
  }
  function renderArchiveTimelineHtml() {
    const a=state.archive,start=parseTime(a.start)?.getTime(),end=parseTime(a.end)?.getTime();
    if(!start||!end||end<=start)return '<div class="empty-inline">Укажите период и нажмите «Найти записи».</div>';
    const span=end-start,ticks=8;
    const tickHtml=Array.from({length:ticks+1},(_,i)=>{const ms=start+span*i/ticks;const cls=i===0?'first':i===ticks?'last':'';return `<span class="archive-ruler-tick ${cls}" style="left:${i/ticks*100}%"><i></i><b>${esc(new Date(ms).toLocaleTimeString('ru-RU',{hour:'2-digit',minute:'2-digit'}))}</b>${i===0||i===ticks?`<small>${esc(new Date(ms).toLocaleDateString('ru-RU',{day:'2-digit',month:'short'}))}</small>`:''}</span>`;}).join('');
    const bars=a.records.map((r,i)=>{const s=parseTime(r.BeginTime)?.getTime(),e=parseTime(r.EndTime)?.getTime();if(!s||!e||e<=start||s>=end)return '';const left=Math.max(0,(s-start)/span*100),right=Math.min(100,(e-start)/span*100);return `<div class="archive-recorded-bar" style="left:${left}%;width:${Math.max(.16,right-left)}%" title="${esc(fmtTime(r.BeginTime))} — ${esc(fmtTime(r.EndTime))}" aria-label="Запись ${esc(fmtTime(r.BeginTime))} — ${esc(fmtTime(r.EndTime))}"></div>`;}).join('');
    let sel='';
    if(a.selectionStartMs!==null&&a.selectionEndMs!==null){const left=Math.max(0,Math.min(100,(a.selectionStartMs-start)/span*100)),right=Math.max(0,Math.min(100,(a.selectionEndMs-start)/span*100));sel=`<div class="archive-selection-window" id="archive-selection-window" style="left:${left}%;width:${Math.max(.15,right-left)}%"><button class="archive-selection-handle handle-start" data-selection-handle="start" title="Изменить начало"></button><button class="archive-selection-handle handle-end" data-selection-handle="end" title="Изменить конец"></button></div>`;}
    const playhead=a.playheadMs!==null?Math.max(0,Math.min(100,(a.playheadMs-start)/span*100)):null;
    return `<div class="archive-timeline-scroll"><div class="archive-time-chart"><div class="archive-time-ruler">${tickHtml}</div><div class="archive-track-caption"><span class="status-dot ${a.records.length?'online':''}"></span><b>${esc(camById(a.camId)?.name||'Канал')}</b><span>${a.records.length} отрезков записи</span></div><div class="archive-time-track ${a.records.length?'has-recordings':''}" data-timeline-track role="slider" tabindex="0" aria-label="Шкала времени архива" aria-valuemin="0" aria-valuemax="100" aria-valuenow="${playhead===null?0:Math.round(playhead)}">${bars}${sel||'<div class="archive-selection-window hidden" id="archive-selection-window"></div>'}${playhead===null?'':`<div class="archive-playhead" id="archive-playhead" style="left:${playhead}%"><span></span></div>`}</div><div class="archive-timeline-hint">${a.records.length?'Жёлтые участки — найденные записи. Синий курсор — текущая позиция.':'Записей на шкале нет или поиск ещё не выполнялся.'}</div></div></div>`;
  }
  function renderArchiveResultsHtml() {
    const a=state.archive;
    if(a.loading)return '<div class="loading-line"></div><div class="empty-inline">Запрашиваем список записей у регистратора…</div>';
    if(a.error)return `<div class="empty-inline" style="color:var(--danger)">${icon('alert')} ${esc(a.error)}</div>`;
    if(!a.records.length)return '<div class="empty-inline">Здесь появятся найденные записи. Выберите камеру и временной диапазон, затем нажмите «Найти записи».</div>';
    return `<div class="results-list">${a.records.map((r,i)=>recordRow(r,i)).join('')}</div>`;
  }
  function recordRow(rec,index) {
    const active=state.archive.active&&state.archive.active.FilePath===rec.FilePath?'active':'';
    const path=rec.FilePath||rec.FileName||'Временной отрезок';
    return `<div role="button" tabindex="0" class="record-row ${active}" data-record="${index}"><span class="record-play">${icon('play')}</span><span class="record-info"><span class="record-time">${esc(fmtTime(rec.BeginTime))} — ${esc(fmtTime(rec.EndTime))}</span><span class="record-path">${esc(path)}</span></span><span class="record-duration">${esc(durationText(rec.BeginTime,rec.EndTime))}</span><a class="icon-btn btn-icon record-download" href="${archiveUrl('download',rec,state.archive.mode)}" title="Скачать" aria-label="Скачать" data-download-record="${index}">${icon('download')}</a></div>`;
  }
  function bindArchiveResults() {
    $$('.record-row').forEach(el=>{
      const run=()=>{const index=Number(el.dataset.record);const rec=state.archive.records[index];if(rec)playArchive(rec,state.archive.mode);};
      el.addEventListener('click',e=>{if(e.target.closest('[data-download-record]'))return;run();});
      el.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();run();}});
    });
  }
  async function searchArchive() {
    const a=state.archive; a.camId=$('#archive-cam')?.value||a.camId;a.mode=$('#archive-mode')?.value||a.mode;a.start=$('#archive-start')?.value||a.start;a.end=$('#archive-end')?.value||a.end;
    if(!a.camId){showToast('Выберите DVRIP-камеру.','warning');return;}
    const start=parseTime(a.start),end=parseTime(a.end);if(!start||!end||start>=end){showToast('Укажите корректный период: начало раньше конца.','warning');return;}
    a.records=[];a.active=null;a.url='';a.loading=true;a.error='';a.playheadMs=start.getTime();a.playbackBaseMs=null;a.selectionStartMs=null;a.selectionEndMs=null;renderArchiveResultsOnly();
    const url=`/api/recordings?cam_id=${encodeURIComponent(a.camId)}&start=${encodeURIComponent(apiTime(a.start))}&end=${encodeURIComponent(apiTime(a.end))}&mode=${encodeURIComponent(a.mode)}`;
    try{const records=await api(url);a.records=Array.isArray(records)?records:[];a.loading=false;renderArchiveResultsOnly();}
    catch(e){a.loading=false;a.error=e.message;renderArchiveResultsOnly();showToast('Поиск архива не выполнен: '+e.message,'error');}
  }
  function renderArchiveResultsOnly(){
    const root=$('#archive-results');if(root)root.innerHTML=renderArchiveResultsHtml();
    const summary=$('#archive-result-summary');if(summary)summary.textContent=state.archive.loading?'Поиск на регистраторе…':`Найдено: ${state.archive.records.length}`;
    const timeline=$('#archive-timeline-body');if(timeline)timeline.innerHTML=renderArchiveTimelineHtml();
    const label=$('#archive-selection-label');if(label)label.textContent=selectionLabel();
    const download=$('#archive-download-selection');if(download)download.disabled=state.archive.selectionStartMs===null||state.archive.selectionEndMs===null;
    bindArchiveResults();bindArchiveTimeline();updateArchivePlayheadVisual();
  }
  function archiveUrl(endpoint,rec,mode) {
    const a=state.archive;const params=new URLSearchParams({cam_id:a.camId,path:rec?.FilePath||'',start:rec?.BeginTime||apiTime(a.start),end:rec?.EndTime||apiTime(a.end),mode:mode||a.mode,t:String(Date.now())});
    return `/api/${endpoint}?${params.toString()}`;
  }
  function archiveUrlRange(endpoint,startMs,endMs,mode='time',path='') {
    const params=new URLSearchParams({cam_id:state.archive.camId,path:path||'',start:apiDateTimeSeconds(startMs),end:apiDateTimeSeconds(endMs),mode,t:String(Date.now())});
    return `/api/${endpoint}?${params.toString()}`;
  }
  function setArchiveSelection(startMs,endMs,updateFields=true) {
    const a=state.archive,rangeStart=parseTime(a.start)?.getTime(),rangeEnd=parseTime(a.end)?.getTime();
    if(!Number.isFinite(startMs)||!Number.isFinite(endMs))return;
    let s=Math.max(rangeStart??startMs,Math.min(startMs,endMs)),e=Math.min(rangeEnd??endMs,Math.max(startMs,endMs));
    if(e-s<1000){if(s+1000<=(rangeEnd??e+1000))e=s+1000;else s=Math.max(rangeStart??0,e-1000);}
    if(e<=s)return;
    a.selectionStartMs=s;a.selectionEndMs=e;
    if(updateFields){const ds=$('#download-start'),de=$('#download-end');if(ds)ds.value=localDateTimeSeconds(s);if(de)de.value=localDateTimeSeconds(e);}
    const label=$('#archive-selection-label');if(label)label.textContent=selectionLabel();const button=$('#archive-download-selection');if(button)button.disabled=false;
    renderArchiveTimelineOnly();
  }
  function renderArchiveTimelineOnly(){const root=$('#archive-timeline-body');if(root){root.innerHTML=renderArchiveTimelineHtml();bindArchiveTimeline();}updateArchivePlayheadVisual();}
  function bindArchiveTimeline() {
    const track=$('[data-timeline-track]');if(!track||track.dataset.bound==='1')return;track.dataset.bound='1';
    const a=state.archive;
    const valueAt=(clientX)=>{const rect=track.getBoundingClientRect(),pct=Math.max(0,Math.min(1,(clientX-rect.left)/Math.max(1,rect.width)));const s=parseTime(a.start)?.getTime()||0,e=parseTime(a.end)?.getTime()||s;return s+(e-s)*pct;};
    track.addEventListener('pointerdown',e=>{
      if(e.button!==0)return;const handle=e.target.closest('[data-selection-handle]');
      const ms=valueAt(e.clientX);a.drag={pointerId:e.pointerId,startX:e.clientX,lastX:e.clientX,startMs:ms,currentMs:ms,handle:handle?.dataset.selectionHandle||'',origStart:a.selectionStartMs,origEnd:a.selectionEndMs,moved:false};
      track.setPointerCapture?.(e.pointerId);track.classList.add('is-dragging');e.preventDefault();
      if(!a.drag.handle){const win=$('#archive-selection-window');if(win){win.classList.remove('hidden');win.style.left=`${(ms-(parseTime(a.start)?.getTime()||0))/((parseTime(a.end)?.getTime()||1)-(parseTime(a.start)?.getTime()||0))*100}%`;win.style.width='0.2%';}}
    });
    track.addEventListener('pointermove',e=>{
      if(!a.drag||a.drag.pointerId!==e.pointerId)return;const d=a.drag;d.lastX=e.clientX;d.currentMs=valueAt(e.clientX);if(Math.abs(d.lastX-d.startX)>4)d.moved=true;
      let ss,ee;if(d.handle==='start'){ss=Math.min(d.currentMs,d.origEnd??d.currentMs+1000);ee=d.origEnd??d.currentMs+1000;}else if(d.handle==='end'){ss=d.origStart??d.currentMs-1000;ee=Math.max(d.currentMs,ss+1000);}else{ss=Math.min(d.startMs,d.currentMs);ee=Math.max(d.startMs,d.currentMs);}
      updateSelectionWindowVisual(ss,ee);
      const label=$('#archive-selection-label');if(label)label.textContent=ee-ss>=1000?`${formatDateTimeSeconds(ss)} — ${formatDateTimeSeconds(ee)} · ${durationText(new Date(ss).toISOString(),new Date(ee).toISOString())}`:'Выберите диапазон мышью';
    });
    const finish=e=>{
      if(!a.drag||a.drag.pointerId!==e.pointerId)return;const d=a.drag;a.drag=null;track.classList.remove('is-dragging');
      if(d.handle){const ss=d.handle==='start'?Math.min(d.currentMs,d.origEnd-1000):d.origStart,ee=d.handle==='end'?Math.max(d.currentMs,d.origStart+1000):d.origEnd;setArchiveSelection(ss,ee);return;}
      if(d.moved&&Math.abs(d.currentMs-d.startMs)>=1000){setArchiveSelection(d.startMs,d.currentMs);}
      else {playArchiveAt(d.currentMs);}
    };
    track.addEventListener('pointerup',finish);track.addEventListener('pointercancel',finish);
    track.addEventListener('keydown',e=>{if(!['ArrowLeft','ArrowRight','Home','End'].includes(e.key))return;e.preventDefault();let ms=a.playheadMs??parseTime(a.start)?.getTime()??Date.now();if(e.key==='ArrowLeft')ms-=30000;if(e.key==='ArrowRight')ms+=30000;if(e.key==='Home')ms=parseTime(a.start)?.getTime()??ms;if(e.key==='End')ms=parseTime(a.end)?.getTime()??ms;playArchiveAt(ms);});
  }
  function updateSelectionWindowVisual(startMs,endMs){
    const a=state.archive,base=parseTime(a.start)?.getTime(),end=parseTime(a.end)?.getTime();if(!base||!end||end<=base)return;
    const s=Math.max(base,Math.min(startMs,endMs)),e=Math.min(end,Math.max(startMs,endMs));let win=$('#archive-selection-window');
    if(!win){const track=$('[data-timeline-track]');if(!track)return;win=document.createElement('div');win.id='archive-selection-window';win.className='archive-selection-window';track.appendChild(win);}
    win.classList.remove('hidden');win.style.left=`${(s-base)/(end-base)*100}%`;win.style.width=`${Math.max(.15,(e-s)/(end-base)*100)}%`;
  }
  function updateArchivePlayheadVisual(){
    const a=state.archive,base=parseTime(a.start)?.getTime(),end=parseTime(a.end)?.getTime();if(!base||!end||end<=base)return;
    const ms=a.playheadMs===null?null:Math.max(base,Math.min(end,a.playheadMs));const pct=ms===null?null:(ms-base)/(end-base)*100;
    const track=$('[data-timeline-track]');if(track&&pct!==null)track.setAttribute('aria-valuenow',String(Math.round(pct)));
    const line=$('#archive-playhead');if(line&&pct!==null)line.style.left=`${pct}%`;
    const current=$('#archive-current-time');if(current&&ms!==null)current.textContent=formatDateTimeSeconds(ms);
  }
  function bindArchiveVideo(){
    const video=$('#archive-video');if(!video||video.dataset.timelineBound==='1')return;video.dataset.timelineBound='1';
    video.addEventListener('timeupdate',()=>{const a=state.archive;if(a.playbackBaseMs===null||!Number.isFinite(video.currentTime))return;a.playheadMs=a.playbackBaseMs+video.currentTime*1000;updateArchivePlayheadVisual();});
    video.addEventListener('ended',()=>{const e=parseTime(state.archive.end)?.getTime();if(e!==undefined&&e!==null)state.archive.playheadMs=e;updateArchivePlayheadVisual();});
  }
  function playArchive(rec,mode) {
    const a=state.archive; a.active=rec;a.playheadMs=parseTime(rec.BeginTime)?.getTime()??parseTime(a.start)?.getTime()??null;a.playbackBaseMs=a.playheadMs;
    const rs=parseTime(rec.BeginTime)?.getTime(),re=parseTime(rec.EndTime)?.getTime();if(rs!==undefined&&rs!==null&&re!==undefined&&re!==null)setArchiveSelection(rs,re);
    a.url=archiveUrl('playback',rec,mode);const video=$('#archive-video');if(!video)return;
    video.pause();video.classList.remove('hidden');video.src=a.url;video.load();video.play().catch(()=>{});
    $('#archive-placeholder')?.classList.add('hidden');$('#archive-playing-label').textContent=rec.FilePath||rec.FileName||`Воспроизведение с ${fmtTime(rec.BeginTime)}`;
    const download=$('#archive-download-active');if(download){download.href=archiveUrl('download',rec,mode);download.classList.remove('hidden');}
    const ds=$('#download-start'),de=$('#download-end');if(ds)ds.value=inputTime(rec.BeginTime);if(de)de.value=inputTime(rec.EndTime);
    renderArchiveResultsOnly();
  }
  function playArchiveAt(ms){
    const a=state.archive,periodStart=parseTime(a.start)?.getTime(),periodEnd=parseTime(a.end)?.getTime();if(periodStart===undefined||periodEnd===undefined||periodStart===null||periodEnd===null)return;
    ms=Math.max(periodStart,Math.min(periodEnd-1000,ms));a.playheadMs=ms;a.playbackBaseMs=ms;
    const rec={FileName:'',FilePath:'',BeginTime:apiDateTimeSeconds(ms),EndTime:apiDateTimeSeconds(periodEnd),Channel:camById(a.camId)?.channel||0};a.active=rec;
    a.url=archiveUrlRange('playback',ms,periodEnd,'time','');const video=$('#archive-video');if(!video)return;
    video.pause();video.classList.remove('hidden');video.src=a.url;video.load();video.play().catch(()=>{});
    $('#archive-placeholder')?.classList.add('hidden');$('#archive-playing-label').textContent=`Воспроизведение с ${formatDateTimeSeconds(ms)}`;
    const download=$('#archive-download-active');if(download)download.classList.add('hidden');
    renderArchiveResultsOnly();updateArchivePlayheadVisual();
  }
  function jumpArchive(seconds){const a=state.archive,cur=a.playheadMs??parseTime(a.start)?.getTime();if(cur===undefined||cur===null)return;playArchiveAt(cur+seconds*1000);}
  async function downloadArchiveRange() {
    const a=state.archive,start=$('#download-start')?.value,end=$('#download-end')?.value;
    if(!a.camId){showToast('Выберите DVRIP-камеру.','warning');return;}
    if(!start||!end||!parseTime(start)||!parseTime(end)||parseTime(start)>=parseTime(end)){showToast('Проверьте начало и конец периода.','warning');return;}
    const params=new URLSearchParams({cam_id:a.camId,mode:'time',path:'',start:apiTime(start),end:apiTime(end),t:String(Date.now())});
    window.location.href='/api/download?'+params.toString();
  }

  function renderCameras() {
    const filtered=state.cameras.filter(c=>`${c.name} ${c.ip} ${c.protocol}`.toLowerCase().includes(state.cameraSearch.toLowerCase()));
    const actions=`<button class="btn btn-primary" id="camera-add">${icon('plus')} Добавить камеру</button>`;
    const cards=filtered.map(c=>`<article class="entity-card"><div class="entity-card-head"><div class="entity-icon">${icon(c.protocol==='dvrip'?'server':'camera')}</div><div style="min-width:0;flex:1"><div class="entity-title">${esc(c.name)}</div><div class="entity-description">${esc(c.ip)}${c.protocol==='dvrip'?` · канал ${Number(c.channel||0)+1}`:''}</div></div><span class="badge ${c.protocol==='dvrip'?'blue':''}">${esc(protocolLabel(c))}</span></div><div class="entity-meta"><span class="badge">${icon('link')} ${c.protocol==='dvrip'?'DVRIP : '+esc(c.port||34567):'RTSP : '+esc(c.rtsp_port||554)}</span><span class="badge">${esc(c.username||'Без логина')}</span></div><div class="entity-actions"><button class="btn btn-sm camera-edit" data-id="${esc(c.id)}">${icon('edit')} Изменить</button><button class="btn btn-sm btn-danger camera-delete" data-id="${esc(c.id)}">${icon('trash')} Удалить</button></div></article>`).join('');
    $('#main-content').innerHTML=pageHeader('Камеры','Добавляйте регистраторы DVRIP и IP-камеры с RTSP-потоками.',actions)+`<div class="toolbar"><div class="toolbar-left"><div class="search-wrap">${icon('search')}<input class="field" id="camera-search" placeholder="Поиск по названию, IP или протоколу" value="${esc(state.cameraSearch)}"></div></div><div class="toolbar-right"><span class="small-muted">${filtered.length} из ${state.cameras.length} устройств</span></div></div>${cards?`<div class="camera-list-grid">${cards}</div>`:emptyState(state.cameras.length?'Ничего не найдено':'Пока нет камер',state.cameras.length?'Измените поисковый запрос.':'Добавьте регистратор или IP-камеру, чтобы начать просмотр.',`<button class="btn btn-primary" id="camera-add-empty">${icon('plus')} Добавить камеру</button>`)}`;
    $('#camera-add')?.addEventListener('click',()=>openCameraModal());$('#camera-add-empty')?.addEventListener('click',()=>openCameraModal());
    $('#camera-search')?.addEventListener('input',e=>{state.cameraSearch=e.target.value;const pos=e.target.selectionStart;renderCameras();const input=$('#camera-search');input?.focus();input?.setSelectionRange(pos,pos);});
    $$('.camera-edit').forEach(btn=>btn.addEventListener('click',()=>openCameraModal(camById(btn.dataset.id))));
    $$('.camera-delete').forEach(btn=>btn.addEventListener('click',()=>deleteCamera(btn.dataset.id)));
  }
  function openCameraModal(camera=null) {
    if(!IS_ADMIN)return;
    const c=camera?{...camera,password:''}:{id:'',name:'',protocol:'dvrip',ip:'',port:34567,rtsp_port:554,channel:0,rtsp_path:'',username:'admin',password:''};
    const isEdit=Boolean(c.id);
    let availableOnvifProfiles=[];
    const protocolFields=()=>c.protocol==='dvrip'?`<div class="form-row"><div class="form-field"><label for="cam-port">Порт DVRIP</label><input class="field" type="number" min="1" max="65535" id="cam-port" name="port" value="${esc(c.port||34567)}" required></div><div class="form-field"><label for="cam-rtsp-port">Порт RTSP</label><input class="field" type="number" min="1" max="65535" id="cam-rtsp-port" name="rtsp_port" value="${esc(c.rtsp_port||554)}" required></div></div><div class="form-field"><label for="cam-channel">Канал регистратора</label><select class="select" name="channel" id="cam-channel">${Array.from({length:64},(_,i)=>`<option value="${i}" ${Number(c.channel||0)===i?'selected':''}>Канал ${i+1}</option>`).join('')}</select><span class="help">Для DVRIP канал вводится в API с нумерацией от 0; в интерфейсе показывается привычный номер от 1.</span></div>`:`<div class="form-row"><div class="form-field"><label for="cam-port">Порт ONVIF / веб-службы</label><input class="field" type="number" min="1" max="65535" id="cam-port" name="port" value="${esc(c.port||80)}"></div><div class="form-field"><label for="cam-rtsp-port">Порт RTSP</label><input class="field" type="number" min="1" max="65535" id="cam-rtsp-port" name="rtsp_port" value="${esc(c.rtsp_port||554)}" required></div></div><div class="form-field"><label for="cam-rtsp-path">RTSP path</label><input class="field" id="cam-rtsp-path" name="rtsp_path" value="${esc(c.rtsp_path||'')}" placeholder="/Streaming/Channels/101"><span class="help">Можно ввести путь вручную либо запросить доступные профили через ONVIF у совместимой камеры.</span></div><div class="form-field"><div class="page-actions"><button type="button" class="btn" id="cam-get-profiles">${icon('search')} Получить профили ONVIF</button></div><div id="cam-profile-status" class="small-muted">Для получения профилей укажите IP, порт ONVIF и учётные данные.</div><div id="cam-profile-select-wrap" class="form-field hidden"><label for="cam-onvif-profile">Профиль видеопотока</label><select id="cam-onvif-profile" class="select"></select></div></div>`;
    $('#modal-root').innerHTML=`<div class="modal-backdrop" data-backdrop><section class="modal" role="dialog" aria-modal="true" aria-labelledby="camera-modal-title"><div class="modal-head"><div><h2 id="camera-modal-title">${isEdit?'Настройки камеры':'Добавить камеру'}</h2><p>${isEdit?'Измените параметры подключения.':'Добавьте регистратор или IP-камеру в систему.'}</p></div><button class="icon-btn btn-icon" data-close aria-label="Закрыть">${icon('close')}</button></div><form id="camera-form"><div class="modal-body form-stack"><div class="form-row"><div class="form-field"><label for="cam-name">Название камеры *</label><input class="field" id="cam-name" name="name" value="${esc(c.name)}" required maxlength="100" placeholder="Например, Вход / Склад"></div><div class="form-field"><label for="cam-protocol">Тип устройства *</label><select class="select" id="cam-protocol" name="protocol"><option value="dvrip" ${c.protocol==='dvrip'?'selected':''}>Видеорегистратор / коаксиал (DVRIP)</option><option value="onvif" ${c.protocol!=='dvrip'?'selected':''}>IP-камера (RTSP / ONVIF)</option></select></div></div><div class="form-field"><label for="cam-ip">IP-адрес или имя узла *</label><input class="field" id="cam-ip" name="ip" value="${esc(c.ip)}" required placeholder="172.17.6.50"></div><div id="camera-protocol-fields">${protocolFields()}</div><div class="form-row"><div class="form-field"><label for="cam-username">Имя пользователя</label><input class="field" id="cam-username" name="username" value="${esc(c.username||'admin')}" autocomplete="off"></div><div class="form-field"><label for="cam-password">Пароль устройства</label><input class="field" id="cam-password" name="password" type="password" value="" autocomplete="new-password" placeholder="${isEdit?'Пусто — оставить прежний пароль':'Пароль устройства'}"><span class="help">Пароль шифруется перед сохранением на сервере.</span></div></div><div id="camera-test-result" class="hidden"></div></div><div class="modal-foot"><button type="button" class="btn" id="camera-test">${icon('link')} Проверить соединение</button><div class="modal-foot-right"><button type="button" class="btn" data-close>Отмена</button><button type="submit" class="btn btn-primary">${icon('check')} Сохранить</button></div></div></form></section></div>`;
    const protocol=$('#cam-protocol');
    const bindOnvifProfilePicker=()=>{
      const queryButton=$('#cam-get-profiles');if(!queryButton)return;
      queryButton.addEventListener('click',async()=>{
        const data=formObject($('#camera-form'));data.id=c.id||'';data.protocol='onvif';data.port=Number(data.port||80);
        const status=$('#cam-profile-status');const selectWrap=$('#cam-profile-select-wrap');
        status.textContent='Подключаемся к ONVIF-службе и запрашиваем профили…';queryButton.disabled=true;
        try{
          const result=await api('/api/onvif/profiles',{method:'POST',body:data});availableOnvifProfiles=result.profiles||[];
          if(!availableOnvifProfiles.length){status.textContent='Камера ответила, но профили видеопотока не найдены.';selectWrap.classList.add('hidden');return;}
          const select=$('#cam-onvif-profile');select.innerHTML=availableOnvifProfiles.map((p,i)=>`<option value="${i}">${esc(p.name||p.token||`Профиль ${i+1}`)}${p.uri?` — ${esc(p.uri)}`:''}</option>`).join('');
          selectWrap.classList.remove('hidden');status.textContent=`Найдено профилей: ${availableOnvifProfiles.length}. Выбор заполнит RTSP-порт и путь.`;
          select.dispatchEvent(new Event('change'));
        }catch(err){status.textContent='Ошибка ONVIF: '+err.message;showToast(err.message,'error');}
        finally{queryButton.disabled=false;}
      });
      $('#cam-onvif-profile')?.addEventListener('change',e=>{const p=availableOnvifProfiles[Number(e.target.value)];if(!p)return;const port=$('#cam-rtsp-port');const path=$('#cam-rtsp-path');if(port&&p.rtsp_port)port.value=p.rtsp_port;if(path&&p.rtsp_path)path.value=p.rtsp_path;});
    };
    protocol.addEventListener('change',()=>{c.protocol=protocol.value;$('#camera-protocol-fields').innerHTML=protocolFields();bindOnvifProfilePicker();});
    bindOnvifProfilePicker();
    $('#camera-form').addEventListener('submit',async e=>{e.preventDefault();const data=formObject(e.target);data.id=c.id||'';data.protocol=protocol.value;data.port=Number(data.port|| (data.protocol==='dvrip'?34567:80));data.rtsp_port=Number(data.rtsp_port||554);if(data.protocol==='dvrip')data.channel=Number(data.channel||0);else data.rtsp_path=data.rtsp_path||'';const btn=e.target.querySelector('button[type="submit"]');btn.disabled=true;try{await api('/api/cameras',{method:'POST',body:data});closeModal();await loadData();state.view='cameras';renderCameras();showToast(isEdit?'Камера обновлена':'Камера добавлена');}catch(err){showToast(err.message,'error');}finally{btn.disabled=false;}});
    $('#camera-test').addEventListener('click',async()=>{const data=formObject($('#camera-form'));data.id=c.id||'';data.protocol=protocol.value;data.port=Number(data.port||(data.protocol==='dvrip'?34567:80));data.rtsp_port=Number(data.rtsp_port||554);if(data.protocol==='dvrip')data.channel=Number(data.channel||0);const box=$('#camera-test-result');box.className='notice';box.textContent='Проверяем соединение…';try{const result=await api('/api/cameras/test',{method:'POST',body:data});box.className=result.ok?'notice':'form-alert';box.innerHTML=result.ok?`${icon('check')} Соединение успешно.`:`${icon('alert')} ${esc(result.error||'Проверка не прошла')}`;}catch(err){box.className='form-alert';box.textContent=err.message;}});
    bindModalClose();$('#cam-name').focus();
  }
  function formObject(form) { const data={};new FormData(form).forEach((value,key)=>{data[key]=value;});return data; }
  async function deleteCamera(id) {const cam=camById(id);if(!cam||!confirm(`Удалить камеру «${cam.name}»? Она также будет удалена из групп.`))return;try{await api(`/api/cameras/${encodeURIComponent(id)}`,{method:'DELETE'});state.liveSlots=state.liveSlots.filter(s=>s.camId!==id);await loadData();renderCameras();showToast('Камера удалена');}catch(e){showToast(e.message,'error');}}

  // GROUPS
  function renderGroups() {
    const cards=state.groups.map(g=>{const cams=(g.camera_ids||[]).map(id=>camById(id)).filter(Boolean);return `<article class="entity-card"><div class="entity-card-head"><div class="entity-icon">${icon('folder')}</div><div style="min-width:0;flex:1"><div class="entity-title">${esc(g.name)}</div><div class="entity-description">${cams.length} ${cams.length===1?'камера':'камер'} в группе</div></div><span class="badge">${cams.length}</span></div><div class="entity-meta">${cams.length?cams.slice(0,5).map(c=>`<span class="badge">${esc(c.name)}</span>`).join('')+(cams.length>5?`<span class="badge">+${cams.length-5}</span>`:''):'<span class="small-muted">В группу пока не добавлены камеры</span>'}</div><div class="entity-actions"><button class="btn btn-sm group-watch" data-id="${esc(g.id)}">${icon('eye')} Смотреть</button><button class="btn btn-sm group-edit" data-id="${esc(g.id)}">${icon('edit')} Изменить</button><button class="btn btn-sm btn-danger group-delete" data-id="${esc(g.id)}">${icon('trash')} Удалить</button></div></article>`;}).join('');
    $('#main-content').innerHTML=pageHeader('Группы камер','Объединяйте камеры по объектам или отделам, чтобы быстро открывать нужный набор.',`<button class="btn btn-primary" id="group-add">${icon('plus')} Создать группу</button>`)+(cards?`<div class="group-grid">${cards}</div>`:emptyState('Нет групп','Создайте группу и выберите камеры, которые должны в неё входить.',`<button class="btn btn-primary" id="group-add-empty">${icon('plus')} Создать группу</button>`));
    $('#group-add')?.addEventListener('click',()=>openGroupModal());$('#group-add-empty')?.addEventListener('click',()=>openGroupModal());
    $$('.group-edit').forEach(b=>b.addEventListener('click',()=>openGroupModal(groupById(b.dataset.id))));
    $$('.group-watch').forEach(b=>b.addEventListener('click',()=>{const g=groupById(b.dataset.id);if(!g)return;state.selectedGroup=g.id;state.liveSlots=(g.camera_ids||[]).filter(id=>camById(id)).map(id=>({uid:++state.slotCounter,camId:id,stream:'sub'}));activateView('live');}));
    $$('.group-delete').forEach(b=>b.addEventListener('click',()=>deleteGroup(b.dataset.id)));
  }
  function openGroupModal(group=null) {
    const g=group?{...group,camera_ids:[...(group.camera_ids||[])]}:{id:'',name:'',camera_ids:[]};const selected=new Set(g.camera_ids);
    $('#modal-root').innerHTML=`<div class="modal-backdrop" data-backdrop><section class="modal modal-sm" role="dialog" aria-modal="true"><div class="modal-head"><div><h2>${g.id?'Редактирование группы':'Новая группа'}</h2><p>Укажите название и выберите камеры.</p></div><button class="icon-btn btn-icon" data-close>${icon('close')}</button></div><form id="group-form"><div class="modal-body form-stack"><div class="form-field"><label for="group-name">Название группы *</label><input class="field" id="group-name" name="name" required maxlength="100" value="${esc(g.name)}" placeholder="Например, Периметр"></div><div class="form-field"><label>Камеры в группе</label><div class="checkbox-list">${state.cameras.length?state.cameras.map(c=>`<label class="check-row"><input type="checkbox" name="camera_ids" value="${esc(c.id)}" ${selected.has(c.id)?'checked':''}><span><b>${esc(c.name)}</b><small>${esc(c.ip)}</small></span></label>`).join(''):'<div class="empty-inline">Сначала добавьте камеры.</div>'}</div></div></div><div class="modal-foot"><span></span><div class="modal-foot-right"><button type="button" class="btn" data-close>Отмена</button><button class="btn btn-primary" type="submit">${icon('check')} Сохранить</button></div></div></form></section></div>`;
    $('#group-form').addEventListener('submit',async e=>{e.preventDefault();const camera_ids=$$('[name="camera_ids"]:checked',e.target).map(x=>x.value);try{await api('/api/groups',{method:'POST',body:{id:g.id||'',name:$('#group-name').value.trim(),camera_ids}});closeModal();await loadData();renderGroups();showToast(g.id?'Группа обновлена':'Группа создана');}catch(err){showToast(err.message,'error');}});bindModalClose();$('#group-name').focus();
  }
  async function deleteGroup(id){const g=groupById(id);if(!g||!confirm(`Удалить группу «${g.name}»? Камеры останутся в системе.`))return;try{await api(`/api/groups/${encodeURIComponent(id)}`,{method:'DELETE'});await loadData();renderGroups();showToast('Группа удалена');}catch(e){showToast(e.message,'error');}}

  // USERS
  function renderUsers() {
    const filtered=state.users.filter(u=>`${u.username} ${u.role}`.toLowerCase().includes(state.userSearch.toLowerCase()));
    const rows=filtered.map(u=>`<tr><td><div style="display:flex;align-items:center;gap:9px"><span class="avatar">${esc(u.username.slice(0,1).toUpperCase())}</span><div><div class="cell-main">${esc(u.username)}</div><div class="cell-sub">Тема: ${esc(u.theme||'auto')}</div></div></div></td><td><span class="badge ${u.role==='admin'?'blue':'green'}">${u.role==='admin'?'Администратор':'Только просмотр'}</span></td><td><span class="small-muted">${u.username===USER.username?'Текущая учётная запись':'—'}</span></td><td><div class="table-actions"><button class="btn btn-sm user-edit" data-user="${esc(u.username)}">${icon('edit')} Изменить</button>${u.username!==USER.username?`<button class="btn btn-sm btn-danger user-delete" data-user="${esc(u.username)}">${icon('trash')}</button>`:''}</div></td></tr>`).join('');
    $('#main-content').innerHTML=pageHeader('Пользователи','Управление учётными записями и уровнем доступа.',`<button class="btn btn-primary" id="user-add">${icon('plus')} Создать пользователя</button>`)+`<div class="toolbar"><div class="toolbar-left"><div class="search-wrap">${icon('search')}<input class="field" id="user-search" placeholder="Найти пользователя" value="${esc(state.userSearch)}"></div></div><div class="toolbar-right"><span class="small-muted">Всего пользователей: ${state.users.length}</span></div></div><section class="panel"><div class="table-wrap"><table class="data-table"><thead><tr><th>Учётная запись</th><th>Роль</th><th>Состояние</th><th style="text-align:right">Действия</th></tr></thead><tbody>${rows||`<tr><td colspan="4"><div class="empty-inline">Пользователи не найдены.</div></td></tr>`}</tbody></table></div></section><div class="notice" style="margin-top:14px">${icon('shield')} Администратор может управлять устройствами, камерами, группами и учётными записями. Роль «Только просмотр» предназначена для просмотра камер и архива.</div>`;
    $('#user-add')?.addEventListener('click',()=>openUserModal());$('#user-search')?.addEventListener('input',e=>{state.userSearch=e.target.value;const pos=e.target.selectionStart;renderUsers();const el=$('#user-search');el?.focus();el?.setSelectionRange(pos,pos);});
    $$('.user-edit').forEach(b=>b.addEventListener('click',()=>openUserModal(state.users.find(u=>u.username===b.dataset.user))));
    $$('.user-delete').forEach(b=>b.addEventListener('click',()=>deleteUser(b.dataset.user)));
  }
  function openUserModal(user=null) {
    const u=user?{...user,password:''}:{username:'',role:'viewer',password:''};const edit=!!user;
    $('#modal-root').innerHTML=`<div class="modal-backdrop" data-backdrop><section class="modal modal-sm" role="dialog" aria-modal="true"><div class="modal-head"><div><h2>${edit?'Изменить пользователя':'Создать пользователя'}</h2><p>${edit?'Можно изменить роль и сбросить пароль.':'Создайте новую учётную запись.'}</p></div><button class="icon-btn btn-icon" data-close>${icon('close')}</button></div><form id="user-form"><div class="modal-body form-stack"><div class="form-field"><label for="user-form-name">Имя пользователя *</label><input class="field" id="user-form-name" name="username" value="${esc(u.username)}" ${edit?'readonly':''} required minlength="2" maxlength="64" autocomplete="off"></div><div class="form-field"><label for="user-form-role">Уровень доступа</label><select class="select" id="user-form-role" name="role"><option value="viewer" ${u.role==='viewer'?'selected':''}>Пользователь — только просмотр</option><option value="admin" ${u.role==='admin'?'selected':''}>Администратор — полный доступ</option></select></div><div class="form-field"><label for="user-form-password">${edit?'Новый пароль':'Пароль *'}</label><input class="field" id="user-form-password" name="password" type="password" ${edit?'':'required'} minlength="6" autocomplete="new-password" placeholder="${edit?'Оставьте пустым, чтобы не менять':'Не менее 6 символов'}"><span class="help">Пароль не отображается после сохранения.</span></div></div><div class="modal-foot"><span></span><div class="modal-foot-right"><button type="button" class="btn" data-close>Отмена</button><button type="submit" class="btn btn-primary">${icon('check')} Сохранить</button></div></div></form></section></div>`;
    $('#user-form').addEventListener('submit',async e=>{e.preventDefault();const data=formObject(e.target);try{if(edit){delete data.username;await api(`/api/users/${encodeURIComponent(u.username)}`,{method:'PUT',body:data});}else await api('/api/users',{method:'POST',body:data});closeModal();await loadData();renderUsers();showToast(edit?'Пользователь обновлён':'Пользователь создан');}catch(err){showToast(err.message,'error');}});bindModalClose();$('#user-form-name').focus();
  }
  async function deleteUser(username){if(username===USER.username)return showToast('Нельзя удалить собственную учётную запись из текущего сеанса.','warning');if(!confirm(`Удалить пользователя «${username}»?`))return;try{await api(`/api/users/${encodeURIComponent(username)}`,{method:'DELETE'});await loadData();renderUsers();showToast('Пользователь удалён');}catch(e){showToast(e.message,'error');}}

  // DEVICE ADMINISTRATION — only generic information is exposed by the existing DVRIP backend.
  function renderDevices() {
    const devices=state.cameras;
    const options=devices.map(c=>`<option value="${esc(c.id)}" ${state.deviceCamId===c.id?'selected':''}>${esc(c.name)} · ${esc(c.ip)} · ${esc(protocolLabel(c))}</option>`).join('');
    const cam=camById(state.deviceCamId);const isOnvif=cam?.protocol==='onvif';
    const info=state.deviceInfo?.system_info?JSON.stringify(state.deviceInfo.system_info,null,2):'Нажмите «Запросить информацию», чтобы получить данные устройства.';
    const controls=isOnvif?`<div class="divider"></div><div class="form-field"><label for="device-hostname">Изменить сетевое имя (ONVIF)</label><div class="form-row"><input class="field" id="device-hostname" maxlength="63" placeholder="camera-lobby" value="${esc(state.deviceInfo?.system_info?.hostname||'')}"><button id="device-set-hostname" class="btn">${icon('check')} Применить</button></div><span class="help">Изменение поддерживается только устройствами, разрешающими ONVIF SetHostname. После применения это меняет сетевое имя, а не название карточки в Web VMS.</span></div>`:`<div class="notice">${icon('info')} Изменение параметров DVRIP-регистратора выполняется через его собственный веб-интерфейс; набор команд записи настроек у производителей различается.</div>`;
    $('#main-content').innerHTML=pageHeader('Устройства','Техническая информация, ONVIF-профили и доступные операции управления.')+(!devices.length?emptyState('Нет устройств','Добавьте камеру или регистратор, чтобы открыть их системную информацию.'): `<div class="content-grid"><section class="panel"><div class="panel-head"><div><h2 class="panel-title">Карточка устройства</h2><p class="panel-note">Запросы выполняются с правами администратора.</p></div><span class="badge blue">ADMIN</span></div><div class="panel-body form-stack"><div class="form-field"><label for="device-select">Устройство</label><select id="device-select" class="select">${options}</select></div><div class="entity-card" style="padding:13px"><div class="entity-card-head"><div class="entity-icon">${icon(isOnvif?'camera':'server')}</div><div style="min-width:0;flex:1"><div class="entity-title" id="device-card-name">${esc(cam?.name||'—')}</div><div class="entity-description" id="device-card-address">${esc(cam?.ip||'—')} · ${esc(protocolLabel(cam||{}))} · порт ${esc(cam?.port||80)}</div></div><span class="badge">${cam?'Добавлено':'—'}</span></div></div><div class="page-actions"><button class="btn btn-primary" id="device-query">${icon('refresh')} Запросить информацию</button>${cam?`<a class="btn" id="device-open" href="http://${esc(cam.ip)}" target="_blank" rel="noopener noreferrer">${icon('link')} Веб-интерфейс устройства</a>`:''}</div>${controls}</div></section><section class="panel"><div class="panel-head"><div><h2 class="panel-title">Системная информация</h2><p class="panel-note">Ответ регистратора или ONVIF-устройства.</p></div><span class="badge ${state.deviceInfo?.success?'green':''}" id="device-info-state">${state.deviceInfo?.success?'Получено':'Не запрашивалась'}</span></div><div class="panel-body"><pre class="device-info-pre" id="device-info-output">${esc(info)}</pre></div></section></div>`);
    $('#device-select')?.addEventListener('change',e=>{state.deviceCamId=e.target.value;state.deviceInfo=null;renderDevices();});
    $('#device-query')?.addEventListener('click',loadDeviceInfo);
    $('#device-set-hostname')?.addEventListener('click',setDeviceHostname);
  }
  async function loadDeviceInfo() {
    const cam=camById(state.deviceCamId);if(!cam)return showToast('Выберите устройство.','warning');
    const output=$('#device-info-output');const badge=$('#device-info-state');if(output)output.textContent='Запрос выполняется…';if(badge)badge.textContent='Подключение…';
    try{const result=await api('/api/device/info',{method:'POST',body:{cam_id:cam.id}});state.deviceInfo=result;if(output)output.textContent=JSON.stringify(result.system_info??result,null,2);if(badge){badge.textContent=result.success?'Получено':'Ошибка';badge.className=`badge ${result.success?'green':'red'}`;}const name=$('#device-hostname');if(name&&result.system_info?.hostname)name.value=result.system_info.hostname;showToast('Информация устройства получена');}
    catch(e){state.deviceInfo=null;if(output)output.textContent=JSON.stringify({error:e.message},null,2);if(badge){badge.textContent='Ошибка подключения';badge.className='badge red';}showToast(e.message,'error');}
  }
  async function setDeviceHostname() {
    const cam=camById(state.deviceCamId);const hostname=$('#device-hostname')?.value.trim();if(!cam||!hostname)return showToast('Укажите новое имя устройства.','warning');
    if(!confirm(`Изменить сетевое имя устройства ${cam.ip} на «${hostname}»?`))return;
    try{await api('/api/device/hostname',{method:'POST',body:{cam_id:cam.id,hostname}});showToast('Имя устройства изменено.');await loadDeviceInfo();}
    catch(e){showToast(e.message,'error');}
  }

  function bindModalClose() {
    $$('[data-close]').forEach(btn=>btn.addEventListener('click',closeModal));
    $('[data-backdrop]')?.addEventListener('click',e=>{if(e.target.matches('[data-backdrop]'))closeModal();});
  }
  function closeModal() { $('#modal-root').innerHTML=''; }

  document.addEventListener('DOMContentLoaded', init);
})();
