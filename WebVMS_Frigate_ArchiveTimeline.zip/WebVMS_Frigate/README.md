# Web VMS — Frigate-inspired frontend rebuild

This package is a full frontend replacement for the uploaded Flask project, not a color-only patch. Existing camera data, users, groups, the DVRIP archive handler, FFmpeg/HLS live pipeline, and server routes are retained. The new UI uses standalone HTML/CSS/JavaScript and the existing local `hls.min.js`; it does not depend on Tailwind CDN, Font Awesome CDN, or Alpine.js.

## What is included

- Frigate-inspired workspace layout: left navigation, compact top bar, high-density camera tiles, neutral charcoal/navy dark theme, blue active states and responsive layouts.
- Light, dark, and automatic theme selection. Each signed-in user's choice is saved through the existing profile API.
- Live view: display a set of cameras, change camera per tile, switch main/substream, change grid density, remove tiles, open video fullscreen and filter by group.
- DVRIP archive: select a start/end period and search the recorder; a dedicated time ruler shows recording intervals. Click the ruler to restart remote playback at that timestamp, use ±30-second jumps, drag across the ruler to select an exact clip, then adjust its start/end handles or precise date-time fields and download it directly from the DVR. Playback and export remain DVR-native; no duplicate server recording is created.
- Camera management: create/edit/delete devices, test connectivity, choose DVRIP recorder/channel or manually configured RTSP path for an IP camera.
- Groups: create/edit/delete groups, assign multiple cameras, and jump directly to a group's live view.
- User administration: create accounts, change roles, reset passwords and delete accounts. Viewers do not see administrator navigation.
- Device page: request system information from DVRIP devices; for ONVIF-compatible cameras, request device information and stream profiles (`GetProfiles` / `GetStreamUri`), select a profile, and change hostname where supported by `SetHostname`. The native device web interface can also be opened.
- API fixes: time-based archive playback/export now accepts an empty file path, archive endpoints reject non-DVRIP cameras and invalid time windows, ports/protocol/channel inputs are validated, user/group management validates key inputs, and camera test reports a useful error when FFmpeg is missing.

## Archive workflow

1. Open **Архив**, choose the DVRIP recorder/channel and the start/end of the search period.
2. Click **Найти записи**. Yellow bars on **Шкала времени** show intervals returned by the DVR.
3. Click anywhere on the timeline to begin playback from that point. The app opens a fresh DVRIP playback request for the chosen timestamp; this is how seeking works for the current streamed MP4 response.
4. Drag across the timeline to mark a clip. Drag either blue edge handle to fine-tune the interval, or edit the exact start/end fields. Click **Скачать фрагмент** to export only that interval.
5. Clicking an item in **Найденные отрезки** plays that returned segment and selects its interval for export. The **Скачать запись** action remains available for an actual returned file/segment; it is hidden when the timeline is playing from an arbitrary timestamp.

If the DVR rejects a time-based playback request or does not expose footage for that interval, the timeline cannot manufacture the missing recording; test the same time range in the DVR's own client.

## Run

Requirements: Python 3.10+, dependencies from `requirements.txt`, FFmpeg installed and available in `PATH`, network access to the camera/DVR devices.

```bash
python3 -m venv venv
. venv/bin/activate
pip install -r requirements.txt
python app.py
```

Then open `http://SERVER-IP:5000`.

## Existing data has been retained

`users.json`, `camconfig.json`, `groups.json`, `.camkey`, and `.flask_secret` are copied from the uploaded project. This lets the project reuse existing accounts and encrypted camera passwords. Back up `.camkey` and `.flask_secret`; losing `.camkey` makes encrypted camera passwords unreadable. Restrict access to the project directory because it contains credentials/configuration material.

Initial accounts from the source project were `admin` and `viewer` with the passwords originally configured by that project. Change both passwords before putting this on an operational network.

## Important feature boundaries

- DVRIP live view and archive playback use the code in the supplied backend. Archive streams are requested from the DVR; this application does not enable Frigate recording or duplicate the DVR's archive onto the application server.
- For direct IP cameras, ONVIF profile negotiation is implemented for devices that expose compatible ONVIF Media services. The selected profile fills the RTSP port/path and the existing FFmpeg pipeline connects to it. Automatic WS-Discovery network scanning is not implemented; if a camera advertises a stream URI host that differs from its configured IP, the device may require manual RTSP adjustment.
- The Devices page uses the current DVRIP `get_system_info()` support and opens the vendor web interface in a new tab. Generic settings changes for arbitrary camera vendors cannot be implemented safely without vendor/model-specific APIs; the UI does not pretend that the universal write operation exists.
- “Unlimited cameras” means there is no fixed application-side camera count. Actual stream capacity depends on FFmpeg CPU load, server resources, camera settings, network bandwidth and browser capacity.

## Security and operations

- Do not publish the development Flask server directly to the Internet. Use a VPN and an HTTPS reverse proxy for remote access.
- Rotate all initial passwords. Back up the data files and encryption keys in a protected location.
- For production, add CSRF protection, reverse-proxy HTTPS, rate limiting, audit logging and a service manager (systemd/Docker) appropriate for your environment.

## Validation performed on this build

- Python syntax compilation (`python -m py_compile app.py`).
- ONVIF routes are syntax-checked but require the `onvif-zeep` dependency and a compatible camera to be exercised against a real device.
- JavaScript syntax validation (`node --check static/vms.js`).
- Backend archive changes reviewed against the existing `create_archive_response()` DVRIP implementation.
- A real connection to the user's recorder/cameras has not been executed from this build environment; validate the supplied device credentials and actual archive playback on your network.
