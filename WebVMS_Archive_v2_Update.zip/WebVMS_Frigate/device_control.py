"""Capability-based ONVIF controls; deliberately no arbitrary vendor command proxy.

Operations follow ONVIF Media v10, Imaging v20, PTZ v20 and Device v10.
DVRIP support uses the public OpenIPC/python-dvr methods only.
"""
from __future__ import annotations

import math
import threading
import time
from datetime import datetime, timedelta, timezone
from functools import wraps

from flask import jsonify, request


def plain(value):
    """Serialize Zeep objects without exposing credentials or internal transport state."""
    if value is None or isinstance(value, (str, bool, int, float)):
        return value
    if isinstance(value, datetime):
        return value.isoformat()
    if isinstance(value, (list, tuple)):
        return [plain(v) for v in value]
    if isinstance(value, dict):
        return {str(k): plain(v) for k, v in value.items()
                if not any(s in str(k).lower() for s in ("password", "passwd", "secret", "credential"))}
    try:
        from zeep.helpers import serialize_object
        serialized = serialize_object(value)
        if isinstance(serialized, (dict, list, tuple)):
            return plain(serialized)
    except (ImportError, TypeError):
        pass
    if hasattr(value, "__dict__"):
        return plain({k: v for k, v in vars(value).items() if not k.startswith("_")})
    return str(value)


def field(obj, key, default=None):
    return obj.get(key, default) if isinstance(obj, dict) else getattr(obj, key, default)


def number(value, label, minimum=None, maximum=None, integer=False):
    if isinstance(value, bool):
        raise ValueError(f"{label}: укажите число")
    try:
        result = float(value)
    except (TypeError, ValueError):
        raise ValueError(f"{label}: укажите число") from None
    if not math.isfinite(result) or (integer and result != int(result)):
        raise ValueError(f"{label}: недопустимое число")
    if minimum is not None and result < float(minimum):
        raise ValueError(f"{label}: минимум {minimum}")
    if maximum is not None and result > float(maximum):
        raise ValueError(f"{label}: максимум {maximum}")
    return int(result) if integer else result


def check_dvr_reply(reply):
    if isinstance(reply, dict) and "Ret" in reply and reply["Ret"] not in (100, 150, 515):
        raise RuntimeError(f"DVRIP отказал в операции (код {reply['Ret']})")
    if reply is False or reply is None:
        raise RuntimeError("DVRIP отказал в операции")
    return reply


def register_device_routes(app, current_user, get_camera, onvif_connect, dvr_connect, logger):
    clients, device_locks = {}, {}
    cache_lock = threading.RLock()

    def endpoint(fn):
        @wraps(fn)
        def wrapped():
            me = current_user()
            if not me or me.get("role") != "admin":
                return jsonify(error="Доступ запрещён"), 403
            data = request.get_json(silent=True)
            if not isinstance(data, dict):
                return jsonify(error="Ожидается JSON-объект"), 400
            cam = get_camera(str(data.get("cam_id") or ""))
            if not cam:
                return jsonify(error="Устройство не найдено"), 404
            try:
                # Zeep clients/requests Sessions are shared only under this device
                # lock. Reuse discovery between PTZ renewals instead of reconnecting
                # and reparsing every WSDL while the operator holds a direction.
                with cache_lock:
                    device_lock = device_locks.setdefault(cam["id"], threading.RLock())
                with device_lock:
                    return jsonify(success=True, **fn(cam, data))
            except ValueError as exc:
                return jsonify(error=str(exc)), 400
            except NotImplementedError as exc:
                return jsonify(error=str(exc)), 501
            except Exception as exc:
                # SOAP/FFmpeg errors can contain entire credential-bearing URLs.
                logger.warning("Device operation %s failed on %s (%s)", fn.__name__, cam.get("id"), type(exc).__name__)
                return jsonify(error="Устройство не выполнило операцию. Проверьте подключение, права и поддержку функции."), 502
        return wrapped

    def client_for(cam):
        if cam.get("protocol") != "onvif":
            raise NotImplementedError("Эта функция доступна для совместимых ONVIF-устройств")
        signature = tuple(str(cam.get(k, "")) for k in ("id", "ip", "port", "username", "password"))
        with cache_lock:
            item = clients.get(signature)
            if item is not None and time.monotonic() - item[0] < 60:
                return item[1]
        client = onvif_connect(cam)
        with cache_lock:
            if len(clients) >= 64:
                clients.pop(min(clients, key=lambda key: clients[key][0]))
            clients[signature] = (time.monotonic(), client)
        return client

    def service_for(client, name):
        services = getattr(client, "services", {})
        return services.get(name) or getattr(client, f"create_{name}_service")()

    def profile_for(client, token):
        media = service_for(client, "media")
        cached = getattr(client, "_vms_profiles", None)
        if cached is not None and time.monotonic() - cached[0] < 30:
            profiles = cached[1]
        else:
            profiles = media.GetProfiles() or []
            client._vms_profiles = (time.monotonic(), profiles)
        profile = next((p for p in profiles if str(field(p, "token", "")) == str(token)), None) if token else next(iter(profiles), None)
        if profile is None:
            raise ValueError("Профиль видеопотока не найден")
        return media, profile

    @app.post("/api/device/capabilities")
    @endpoint
    def capabilities(cam, data):
        if cam.get("protocol") == "dvrip":
            dvr = dvr_connect(cam)
            try:
                info = check_dvr_reply(dvr.get_system_info())
                return dict(protocol="dvrip", system_info=plain(info), profiles=[],
                            capabilities=dict(info=True, ptz=False, imaging=False, encoder=False,
                                              reboot=callable(getattr(dvr, "reboot", None)),
                                              time=callable(getattr(dvr, "get_time", None)) and callable(getattr(dvr, "set_time", None)),
                                              network=callable(getattr(dvr, "get_netcommon", None))),
                            notes=["Для DVRIP доступны сведения, чтение сети, часы и перезагрузка. Настройки записи, аналитики и каналов зависят от модели и доступны через интерфейс производителя."])
            finally:
                dvr.close()
        client = client_for(cam)
        device = service_for(client, "devicemgmt")
        caps = device.GetCapabilities({"Category": "All"})
        profiles = service_for(client, "media").GetProfiles() or []
        client._vms_profiles = (time.monotonic(), profiles)
        result = []
        has_ptz, has_source, has_encoder = False, False, False
        for p in profiles:
            source = field(p, "VideoSourceConfiguration")
            encoder = field(p, "VideoEncoderConfiguration")
            ptz = field(p, "PTZConfiguration")
            ptz_supported = ptz is not None and field(caps, "PTZ") is not None
            result.append(dict(token=str(field(p, "token", "")), name=str(field(p, "Name", "Профиль")),
                               ptz=ptz_supported, video_source_token=field(source, "SourceToken", ""),
                               encoder_token=field(encoder, "token", "")))
            has_ptz = has_ptz or ptz_supported
            has_source = has_source or bool(field(source, "SourceToken"))
            has_encoder = has_encoder or bool(field(encoder, "token"))
        return dict(protocol="onvif", profiles=result,
                    capabilities=dict(info=True, ptz=has_ptz, imaging=has_source and field(caps, "Imaging") is not None,
                                      encoder=has_encoder, reboot=True, time=True, network=True),
                    notes=["Наличие ONVIF-службы не гарантирует поддержку каждой команды: доступные диапазоны запрашиваются у устройства. Сеть читается без изменения IP."])

    @app.post("/api/device/ptz")
    @endpoint
    def ptz(cam, data):
        action = data.get("action", "stop")
        if action not in {"move", "stop", "presets", "goto", "save", "remove"}:
            raise ValueError("Неизвестная PTZ-команда")
        # Validate user input before opening any device connection.
        velocity = {k: number(data.get(k, 0), k, -1, 1) for k in ("pan", "tilt", "zoom")} if action == "move" else {}
        preset_token = str(data.get("preset_token") or "").strip()
        if action in {"goto", "remove"} and not preset_token:
            raise ValueError("Выберите предустановку")
        name = str(data.get("name") or "").strip()
        if action == "save" and (not name or len(name) > 64):
            raise ValueError("Имя предустановки должно содержать 1–64 символа")
        client = client_for(cam)
        _, profile = profile_for(client, data.get("profile_token"))
        config = field(profile, "PTZConfiguration")
        if config is None:
            raise NotImplementedError("Выбранный профиль не поддерживает PTZ")
        service = service_for(client, "ptz")
        token = str(field(profile, "token"))
        if action == "move":
            # A bounded device-side timeout is essential if browser/network disappears.
            params = {"ProfileToken": token, "Timeout": timedelta(seconds=0.8), "Velocity": {}}
            if velocity["pan"] or velocity["tilt"]:
                params["Velocity"]["PanTilt"] = {"x": velocity["pan"], "y": velocity["tilt"]}
            if velocity["zoom"]:
                params["Velocity"]["Zoom"] = {"x": velocity["zoom"]}
            if not params["Velocity"]:
                service.Stop({"ProfileToken": token, "PanTilt": True, "Zoom": True})
            else:
                service.ContinuousMove(params)
        elif action == "stop":
            service.Stop({"ProfileToken": token, "PanTilt": True, "Zoom": True})
        elif action == "presets":
            return dict(presets=[dict(token=str(field(p, "token", "")), name=str(field(p, "Name", "")))
                                 for p in (service.GetPresets({"ProfileToken": token}) or [])])
        elif action == "goto":
            service.GotoPreset({"ProfileToken": token, "PresetToken": preset_token})
        elif action == "remove":
            service.RemovePreset({"ProfileToken": token, "PresetToken": preset_token})
        elif action == "save":
            params = {"ProfileToken": token, "PresetName": name}
            if preset_token:
                params["PresetToken"] = preset_token
            return dict(preset_token=str(service.SetPreset(params)))
        return dict(action=action)

    @app.post("/api/device/imaging")
    @endpoint
    def imaging(cam, data):
        settings = data.get("settings")
        allowed = {"Brightness", "Contrast", "ColorSaturation", "Sharpness"}
        if settings is not None and (not isinstance(settings, dict) or not settings or set(settings) - allowed):
            raise ValueError("Допустимы: Brightness, Contrast, ColorSaturation, Sharpness")
        client = client_for(cam)
        _, profile = profile_for(client, data.get("profile_token"))
        source = field(field(profile, "VideoSourceConfiguration"), "SourceToken")
        if not source:
            raise NotImplementedError("Профиль не содержит источник изображения")
        service = service_for(client, "imaging")
        options = service.GetOptions({"VideoSourceToken": source})
        supported = {key: plain(field(options, key)) for key in allowed if field(options, key) is not None}
        if settings is not None:
            validated = {}
            for key, value in settings.items():
                option = field(options, key)
                if option is None:
                    raise ValueError(f"Устройство не поддерживает параметр {key}")
                validated[key] = number(value, key, field(option, "Min"), field(option, "Max"))
            service.SetImagingSettings({"VideoSourceToken": source, "ImagingSettings": validated, "ForcePersistence": True})
        current = service.GetImagingSettings({"VideoSourceToken": source})
        return dict(settings={key: plain(field(current, key)) for key in supported}, options=supported)

    @app.post("/api/device/encoder")
    @endpoint
    def encoder(cam, data):
        settings = data.get("settings")
        allowed = {"width", "height", "fps", "bitrate", "quality"}
        if settings is not None and (not isinstance(settings, dict) or not settings or set(settings) - allowed):
            raise ValueError("Неизвестные параметры видеопотока")
        client = client_for(cam)
        media, profile = profile_for(client, data.get("profile_token"))
        enc = field(profile, "VideoEncoderConfiguration")
        enc_token = field(enc, "token")
        if not enc_token:
            raise NotImplementedError("Профиль не содержит конфигурацию кодировщика")
        config = media.GetVideoEncoderConfiguration({"ConfigurationToken": enc_token})
        options = media.GetVideoEncoderConfigurationOptions({"ConfigurationToken": enc_token, "ProfileToken": field(profile, "token")})
        encoding = str(field(config, "Encoding", ""))
        codec = field(options, encoding)
        if codec is None:
            raise NotImplementedError("Устройство не сообщает диапазоны для текущего кодека")
        # BitrateRange is in the v1 extension for many cameras, not H264Options.
        extended_codec = field(field(options, "Extension"), encoding)
        bitrate_range = field(codec, "BitrateRange") or field(extended_codec, "BitrateRange")
        resolutions = field(codec, "ResolutionsAvailable", []) or []
        public_options = dict(resolutions=[dict(width=field(r, "Width"), height=field(r, "Height")) for r in resolutions],
                              fps=plain(field(codec, "FrameRateRange")), bitrate=plain(bitrate_range),
                              quality=plain(field(options, "QualityRange")))
        if settings is not None:
            if "width" in settings or "height" in settings:
                if not {"width", "height"} <= set(settings):
                    raise ValueError("Укажите ширину и высоту одновременно")
                width = number(settings["width"], "Ширина", 1, 16384, True)
                height = number(settings["height"], "Высота", 1, 16384, True)
                if not any(field(r, "Width") == width and field(r, "Height") == height for r in resolutions):
                    raise ValueError("Разрешение не поддерживается текущим кодеком")
                config.Resolution.Width, config.Resolution.Height = width, height
            for key, path, option in (("quality", "Quality", field(options, "QualityRange")),
                                       ("fps", "FrameRateLimit", field(codec, "FrameRateRange")),
                                       ("bitrate", "BitrateLimit", bitrate_range)):
                if key not in settings:
                    continue
                if option is None:
                    raise ValueError(f"Устройство не сообщает допустимый диапазон {key}")
                validated = number(settings[key], key, field(option, "Min"), field(option, "Max"), key != "quality")
                if key == "quality":
                    config.Quality = validated
                else:
                    if field(config, "RateControl") is None:
                        raise NotImplementedError("Устройство не предоставляет управление частотой/битрейтом")
                    setattr(config.RateControl, path, validated)
            media.SetVideoEncoderConfiguration({"Configuration": config, "ForcePersistence": True})
            config = media.GetVideoEncoderConfiguration({"ConfigurationToken": enc_token})
        resolution, rate = field(config, "Resolution"), field(config, "RateControl")
        return dict(settings=dict(width=field(resolution, "Width"), height=field(resolution, "Height"),
                                  fps=field(rate, "FrameRateLimit"), bitrate=field(rate, "BitrateLimit"),
                                  quality=field(config, "Quality"), encoding=encoding), options=public_options)

    @app.post("/api/device/system")
    @endpoint
    def system(cam, data):
        action = data.get("action", "read")
        if action not in {"read", "time", "reboot"}:
            raise ValueError("Неизвестная системная операция")
        # Reboot requires an explicit intent flag, preventing accidental form submits.
        if action == "reboot" and data.get("confirm") is not True:
            raise ValueError("Подтвердите перезагрузку устройства")
        utc = datetime.now(timezone.utc)
        if action == "time" and data.get("utc"):
            try:
                utc = datetime.fromisoformat(str(data["utc"]).replace("Z", "+00:00"))
                if utc.tzinfo is None:
                    raise ValueError()
                utc = utc.astimezone(timezone.utc)
            except (TypeError, ValueError):
                raise ValueError("Передайте дату ISO 8601 с часовым поясом") from None
        if cam.get("protocol") == "dvrip":
            dvr = dvr_connect(cam)
            try:
                if action == "reboot":
                    dvr.reboot()
                    return dict(message="Команда перезагрузки отправлена")
                if action == "time":
                    # OPTimeSetting accepts an unzoned LOCAL recorder clock, whereas
                    # ONVIF accepts UTC. Require explicit local time; do not guess a
                    # vendor-specific timezone field or the server's own timezone.
                    try:
                        local_time = datetime.fromisoformat(str(data.get("local_time") or ""))
                        if local_time.tzinfo is not None:
                            raise ValueError()
                    except (TypeError, ValueError):
                        raise ValueError("Для DVRIP укажите местное время регистратора в поле local_time без часового пояса") from None
                    check_dvr_reply(dvr.set_time(local_time))
                    return dict(message="Местное время регистратора установлено")
                notes = []
                info = check_dvr_reply(dvr.get_system_info())
                result = dict(system_info=plain(info), time=None, network=None, notes=notes)
                for key, method in (("time", "get_time"), ("network", "get_netcommon")):
                    try:
                        result[key] = plain(check_dvr_reply(getattr(dvr, method)()))
                    except Exception:
                        notes.append(f"Устройство не предоставило {key}")
                return result
            finally:
                dvr.close()
        client = client_for(cam)
        device = service_for(client, "devicemgmt")
        if action == "reboot":
            return dict(message=str(device.SystemReboot() or "Команда перезагрузки отправлена"))
        if action == "time":
            current = device.GetSystemDateAndTime()
            device.SetSystemDateAndTime({"DateTimeType": "Manual", "DaylightSavings": bool(field(current, "DaylightSavings", False)),
                                         "TimeZone": field(current, "TimeZone"),
                                         "UTCDateTime": {"Date": {"Year": utc.year, "Month": utc.month, "Day": utc.day},
                                                         "Time": {"Hour": utc.hour, "Minute": utc.minute, "Second": utc.second}}})
            return dict(message="Время синхронизировано (UTC)")
        result = dict(system_info=plain(device.GetDeviceInformation()), time=None, network=None, notes=[])
        try:
            result["time"] = plain(device.GetSystemDateAndTime())
        except Exception:
            result["notes"].append("Устройство не предоставило время")
        try:
            result["network"] = plain(device.GetNetworkInterfaces())
        except Exception:
            result["notes"].append("Устройство не предоставило сетевые интерфейсы")
        return result
