/* DVR archive workspace: a single selection model, no native video controls. */
(() => {
  'use strict';
  const C=window.VMSArchiveCore;
  let saved=null;
  const escape=value=>String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const paths={
    archive:'<rect x="3" y="4" width="18" height="5" rx="1"/><path d="M5 9v11h14V9m-9 4h4"/>',
    camera:'<rect x="3" y="6" width="13" height="12" rx="2"/><path d="m16 10 5-3v10l-5-3"/>',
    play:'<path d="m8 5 11 7-11 7z"/>',pause:'<path d="M8 5v14M16 5v14"/>',
    prev:'<path d="m14 5-7 7 7 7M4 5v14"/>',next:'<path d="m10 5 7 7-7 7M20 5v14"/>',
    left:'<path d="m14 6-6 6 6 6"/>',right:'<path d="m10 6 6 6-6 6"/>',
    minus:'<path d="M5 12h14"/>',plus:'<path d="M5 12h14M12 5v14"/>',
    zoom:'<circle cx="10" cy="10" r="6"/><path d="m15 15 5 5M7 10h6m-3-3v6"/>',
    fit:'<path d="M8 3H3v5m13-5h5v5M3 16v5h5m13-5v5h-5M8 12h8"/>',
    expand:'<path d="M8 3H3v5m13-5h5v5M3 16v5h5m13-5v5h-5"/>',
    download:'<path d="M12 3v12m-5-5 5 5 5-5M4 16v5h16v-5"/>',
    close:'<path d="m6 6 12 12M6 18 18 6"/>',
    refresh:'<path d="M20 7v5h-5M4 17v-5h5M5 9a7 7 0 0 1 12-4l3 7M4 12l3 7a7 7 0 0 0 12-4"/>',
    clock:'<circle cx="12" cy="12" r="9"/><path d="M12 6v6l4 2"/>',
    selection:'<path d="M8 4H4v16h4m8-16h4v16h-4M9 12h6"/>',
    alert:'<path d="m12 3 10 18H2zM12 9v4m0 4h.01"/>',
    skip:'<path d="m4 5 7 7-7 7M13 5l7 7-7 7"/>',
    list:'<path d="M8 6h13M8 12h13M8 18h13M3 6h.01M3 12h.01M3 18h.01"/>'
  };
  const icon=name=>`<svg viewBox="0 0 24 24" aria-hidden="true">${paths[name]||paths.clock}</svg>`;
  const btn=(id,name,label,extra='')=>`<button type="button" id="${id}" class="icon-btn" title="${label}" aria-label="${label}" ${extra}>${icon(name)}</button>`;
  const clock=ms=>Number.isFinite(ms)?new Date(ms).toLocaleTimeString('ru-RU',{hour:'2-digit',minute:'2-digit',second:'2-digit'}):'—';
  const date=ms=>Number.isFinite(ms)?new Date(ms).toLocaleDateString('ru-RU',{day:'2-digit',month:'short'}):'';
  const duration=ms=>{const s=Math.round(ms/1000);return s>=3600?`${Math.floor(s/3600)} ч ${Math.floor(s%3600/60)} мин`:s>=60?`${Math.floor(s/60)} мин ${s%60} с`:`${s} с`;};
  const abortError=error=>error?.name==='AbortError';

  function mount(options) {
    const {root,api,onError=()=>{},onSuccess=()=>{},onSelect=()=>{}}=options;
    const cameras=options.cameras.filter(c=>c.protocol==='dvrip');
    const valid=id=>cameras.some(c=>c.id===id);
    const requested=valid(options.selectedId)?options.selectedId:cameras[0]?.id||'';
    if(!saved) {
      const day=C.local(Date.now()).slice(0,10),range=C.dayRange(day);
      saved={camId:requested,day,custom:false,draftStart:C.local(range.start),draftEnd:C.local(range.end),range,view:{...range},records:[],intervals:[],loaded:false,cursor:null,selection:null,speed:1,skipGaps:true};
    }
    const m=saved;
    if(m.camId!==requested){m.camId=requested;m.loaded=false;m.records=[];m.intervals=[];m.selection=null;}
    const life=new AbortController(),signal=life.signal;
    let disposed=false,searchAbort=null,searchGeneration=0,hideTimer=0,loadTimer=0,playGeneration=0,loading=false;
    let playbackBase=null,playbackEnd=null,status=m.loaded?'ready':'idle',error='',wantPlay=false,timelineDrag=null;
    let zoom={scale:1,x:0,y:0},pointers=new Map(),pan=null,pinch=null,precise=false,preciseDirty=false,selectionMode=false,followCursor=true;
    const $=selector=>root.querySelector(selector);
    const on=(el,event,fn,opts={})=>el?.addEventListener(event,fn,{...opts,signal});
    const camera=()=>cameras.find(c=>c.id===m.camId);
    const dom=()=>`<section class="archive-console" aria-label="Архив видеозаписей">
      <div class="arc-toolbar"><div class="arc-title">${icon('archive')}<h1>Архив</h1></div><div class="arc-toolbar-main"><div class="arc-field arc-camera-field"><label for="arc-camera">Камера / канал</label><select id="arc-camera" class="select" ${!cameras.length?'disabled':''}>${cameras.length?cameras.map(c=>`<option value="${escape(c.id)}" ${c.id===m.camId?'selected':''}>${escape(c.name)} · CH ${Number(c.channel||0)+1}</option>`).join(''):'<option>Нет DVRIP-каналов</option>'}</select></div><div class="arc-field"><label for="arc-date">Дата архива</label><div class="arc-date-navigation">${btn('arc-day-prev','left','Предыдущий день')}<input id="arc-date" type="date" class="field" value="${m.day}" aria-label="Дата архива">${btn('arc-day-next','right','Следующий день')}</div></div><button type="button" id="arc-period" class="btn btn-sm" aria-expanded="${m.custom}">${icon('clock')} Период</button></div><div class="arc-toolbar-actions"><button type="button" id="arc-search" class="btn" ${!cameras.length?'disabled':''}>${icon('refresh')} Обновить</button>${btn('arc-fullscreen','expand','Архив на весь экран')}</div><div class="arc-custom-period" id="arc-custom-period" ${m.custom?'':'hidden'}><div class="arc-time-range"><div class="arc-field"><label for="arc-from">Начало периода</label><input class="field" type="datetime-local" step="1" id="arc-from" value="${m.draftStart}"></div><span class="arc-time-range-sep">—</span><div class="arc-field"><label for="arc-to">Конец периода</label><input class="field" type="datetime-local" step="1" id="arc-to" value="${m.draftEnd}"></div></div><span>Измените период и нажмите «Обновить».</span></div></div>
      <div class="arc-body"><div class="arc-viewer" id="arc-viewer" tabindex="0" aria-label="Видео архива. Колесо — увеличение, двойной щелчок — увеличить или сбросить, пробел — пауза."><div class="arc-video-layer" id="arc-video-layer"><video id="arc-video" playsinline preload="metadata" disableRemotePlayback></video></div><div class="arc-hud"><div><b id="arc-camera-title">${escape(camera()?.name||'Камера не выбрана')}</b><small id="arc-video-time">Видеозапись регистратора</small></div><span class="arc-camera-chip">${icon('archive')} АРХИВ</span></div><div class="arc-state" id="arc-state" role="status" aria-live="polite"></div><span class="arc-zoom-indicator" id="arc-zoom-indicator" hidden></span><div class="arc-player-controls" id="arc-player-controls" aria-label="Управление воспроизведением"><div class="arc-controls-start">${btn('arc-player-prev','prev','Предыдущая запись')}<button type="button" id="arc-play" class="arc-primary-play" aria-label="Воспроизвести">${icon('play')}</button>${btn('arc-player-next','next','Следующая запись')}<span class="arc-timecode" id="arc-timecode">—</span><select id="arc-speed" aria-label="Скорость воспроизведения">${[.25,.5,1,2,4].map(n=>`<option value="${n}" ${m.speed===n?'selected':''}>${String(n).replace('.',',')}×</option>`).join('')}</select></div><div class="arc-controls-end">${btn('arc-zoom-out','minus','Уменьшить изображение')}<span id="arc-zoom-value" class="arc-zoom-value">1×</span>${btn('arc-zoom-in','plus','Увеличить изображение')}${btn('arc-zoom-reset','fit','Сбросить увеличение')}${btn('arc-snapshot','camera','Сохранить снимок')}${btn('arc-player-fullscreen','expand','Архив на весь экран')}</div></div></div></div>
      <section class="arc-timeline-section" aria-label="Шкала архива и экспорт"><div class="arc-transport"><div><span class="arc-section-label">${icon('clock')}<span id="arc-range-label">Шкала времени</span></span><span class="arc-current-time" id="arc-current-time">—</span></div><div>${btn('arc-record-prev','prev','Предыдущая запись на шкале')}${btn('arc-record-next','next','Следующая запись на шкале')}<button type="button" class="btn btn-sm" id="arc-skip-gaps" aria-pressed="${m.skipGaps}" title="При завершении записи перейти к следующей, минуя промежуток">${icon('skip')}<span>Пропускать паузы</span></button>${btn('arc-time-back','left','Сдвинуть шкалу назад')}${btn('arc-time-out','minus','Уменьшить масштаб шкалы')}<button type="button" class="btn btn-sm" id="arc-time-fit" title="Показать весь период">Весь период</button>${btn('arc-time-in','plus','Увеличить масштаб шкалы')}${btn('arc-time-forward','right','Сдвинуть шкалу вперёд')}</div></div>
      <div class="arc-timeline-window"><div class="arc-ruler" id="arc-ruler"></div><div class="arc-track" id="arc-track" role="group" tabindex="0" aria-label="Шкала времени архива. Стрелки — переход, протягивание — выделение."><span class="arc-track-label" id="arc-track-label"></span><div class="arc-recordings" id="arc-recordings"></div><div class="arc-selection" id="arc-selection" hidden><button class="arc-handle start" data-handle="start" role="slider" aria-label="Начало выделения. Стрелки — изменить на секунду."></button><button class="arc-handle end" data-handle="end" role="slider" aria-label="Конец выделения. Стрелки — изменить на секунду."></button></div><div class="arc-playhead" id="arc-playhead" role="slider" tabindex="0" aria-label="Позиция воспроизведения" aria-valuemin="0" aria-valuemax="100" hidden></div></div></div><div class="arc-timeline-hint"><p id="arc-timeline-hint">Щелчок — просмотр · протяните — фрагмент · Ctrl + колесо — масштаб</p><div class="arc-legend"><span><i></i>Запись</span><span><i class="selection"></i>Фрагмент</span><span><i class="cursor"></i>Позиция</span></div></div>
      <div class="arc-export-bar"><button type="button" class="btn btn-sm" id="arc-select-mode" aria-pressed="false">${icon('selection')} Выделить</button><div class="arc-export-copy"><small id="arc-selection-title">Фрагмент не выбран</small><strong id="arc-selection-label">Выделите нужный участок на шкале</strong><small id="arc-selection-coverage"></small></div><div class="arc-export-actions"><button type="button" class="btn btn-sm" id="arc-precise" aria-expanded="false" disabled>Точно</button>${btn('arc-clear-selection','close','Снять выделение','disabled')}<button type="button" class="btn btn-primary" id="arc-export" disabled>${icon('download')} Скачать фрагмент</button></div><div class="arc-selection-fields" id="arc-selection-fields" hidden><div class="arc-field"><label for="arc-selection-start">Начало фрагмента</label><input type="datetime-local" step="1" class="field" id="arc-selection-start"></div><div class="arc-field"><label for="arc-selection-end">Конец фрагмента</label><input type="datetime-local" step="1" class="field" id="arc-selection-end"></div><button type="button" class="btn btn-sm" id="arc-selection-apply">Применить</button></div></div></section><footer class="arc-status"><span id="arc-status-text" role="status">Готово к поиску</span><span>Время регистратора · ${camera()?escape(camera().ip):'—'}</span></footer></section>`;
    root.innerHTML=dom();
    const video=$('#arc-video'),viewer=$('#arc-viewer'),layer=$('#arc-video-layer'),track=$('#arc-track');

    function stopPlayback() {
      ++playGeneration;clearTimeout(loadTimer);loadTimer=0;loading=false;wantPlay=false;
      video.pause();video.removeAttribute('src');video.load();playbackBase=null;playbackEnd=null;
    }
    function showControls() {
      if(disposed)return;viewer.classList.add('controls-visible');clearTimeout(hideTimer);
      hideTimer=setTimeout(()=>{if(!disposed)viewer.classList.remove('controls-visible');},2200);
    }
    function setState(next,message='') {
      status=next;error=message;
      const display=$('#arc-state');
      const states={idle:['archive','Архив готов к просмотру','Выберите дату и камеру.'],searching:['spin','Поиск записей','Запрашиваем архив регистратора…'],ready:['play','Выберите момент на шкале','Нажмите на зелёный участок, чтобы открыть запись.'],empty:['archive','Записей за этот период нет','Выберите другой день или измените период.'],loading:['spin','Загрузка записи','Подключаемся к архиву регистратора…'],gap:['clock','В этот момент нет записи','На шкале пропуски оставлены пустыми.'],error:['alert','Не удалось открыть архив',message||'Проверьте доступность регистратора и FFmpeg.'],paused:['play','Пауза','']};
      if(next==='playing'||(next==='paused'&&video.videoWidth)){display.hidden=true;display.innerHTML='';}
      else {
        const [symbol,title,note]=states[next]||states.ready;display.hidden=false;
        display.innerHTML=`${symbol==='spin'?'<span class="arc-spinner"></span>':icon(symbol)}<strong>${escape(title)}</strong><p>${escape(note)}</p>${next==='ready'||next==='paused'?'<button type="button" class="btn btn-sm" data-action="play">Воспроизвести</button>':next==='gap'&&C.adjacent(m.intervals,m.cursor,1)?'<button type="button" class="btn btn-sm" data-action="next">К следующей записи</button>':next==='error'?'<button type="button" class="btn btn-sm" data-action="retry">Повторить</button>':''}`;
      }
      const pauseAction=next==='playing'||next==='loading'&&wantPlay;
      $('#arc-play').innerHTML=icon(pauseAction?'pause':'play');$('#arc-play').setAttribute('aria-label',pauseAction?'Пауза':'Воспроизвести');
      $('#arc-play').disabled=!m.intervals.length||next==='searching';
      $('#arc-status-text').textContent=next==='searching'?'Поиск записей…':next==='error'?'Ошибка: '+message:next==='loading'?'Загрузка записи…':m.loaded?`${m.intervals.length} отрезков · ${duration(m.intervals.reduce((sum,r)=>sum+r.end-r.start,0))} записи`:'Готово к поиску';
    }
    function updateCursor(follow=false) {
      const cursor=m.cursor,valid=Number.isFinite(cursor),pct=valid?(cursor-m.view.start)/(m.view.end-m.view.start)*100:-1;
      $('#arc-current-time').textContent=valid?clock(cursor):'—';$('#arc-timecode').textContent=valid?clock(cursor):'—';$('#arc-video-time').textContent=valid?`${date(cursor)} · ${clock(cursor)}`:'Видеозапись регистратора';
      if(follow&&followCursor&&valid&&(pct<0||pct>100)){m.view=C.viewWindow(m.range.start,m.range.end,m.view.end-m.view.start,cursor,.3);renderTimeline();return;}
      const head=$('#arc-playhead');head.hidden=!valid||pct<0||pct>100;if(!head.hidden)head.style.left=`${pct}%`;
      head.setAttribute('aria-valuenow',String(Math.round(C.clamp(pct,0,100))));head.setAttribute('aria-valuetext',valid?`${date(cursor)} ${clock(cursor)}`:'Позиция не выбрана');
    }
    function updateSelection(working=m.selection) {
      const win=$('#arc-selection'),span=m.view.end-m.view.start;
      const visible=working&&working.end>m.view.start&&working.start<m.view.end;
      win.hidden=!visible;
      if(visible){win.style.left=`${C.clamp((working.start-m.view.start)/span*100,0,100)}%`;win.style.width=`${(Math.min(working.end,m.view.end)-Math.max(working.start,m.view.start))/span*100}%`;win.querySelector('.start').hidden=working.start<m.view.start;win.querySelector('.end').hidden=working.end>m.view.end;}
      if(working){win.querySelectorAll('[data-handle]').forEach(handle=>{const edge=handle.dataset.handle;handle.setAttribute('aria-valuemin',String(edge==='start'?m.range.start:working.start+1000));handle.setAttribute('aria-valuemax',String(edge==='start'?working.end-1000:m.range.end));handle.setAttribute('aria-valuenow',String(working[edge]));handle.setAttribute('aria-valuetext',date(working[edge])+' '+clock(working[edge]));});}
      const selected=Boolean(working),covered=C.coverage(m.intervals,working);
      $('#arc-selection-title').textContent=selected?'Выбранный фрагмент':'Фрагмент не выбран';
      $('#arc-selection-label').textContent=selected?`${date(working.start)} ${clock(working.start)} — ${date(working.end)} ${clock(working.end)} · ${duration(working.end-working.start)}`:'Выделите нужный участок на шкале';
      $('#arc-selection-coverage').textContent=selected?(covered===0?'В выделении нет записей':covered<working.end-working.start?'В диапазоне есть пропуски: будет выгружена доступная запись.':''):'';
      if(!selected)preciseDirty=false;
      if(preciseDirty)$('#arc-selection-coverage').textContent='Примените новые границы фрагмента.';
      $('#arc-export').disabled=!selected||covered<=0||!m.loaded||status==='searching'||preciseDirty;$('#arc-precise').disabled=!selected;$('#arc-clear-selection').disabled=!selected;
      $('#arc-selection-fields').hidden=!selected||!precise;$('#arc-precise').setAttribute('aria-expanded',String(selected&&precise));
      if(selected&&!$('#arc-selection-fields').contains(document.activeElement)){$('#arc-selection-start').value=C.local(working.start);$('#arc-selection-end').value=C.local(working.end);}
    }
    function renderTimeline() {
      const start=m.view.start,end=m.view.end,span=end-start;
      const count=track.clientWidth<480?4:8;
      $('#arc-ruler').innerHTML=Array.from({length:count+1},(_,i)=>{const t=start+span*i/count;return `<span class="arc-tick ${i===0?'first':i===count?'last':''}" style="left:${i/count*100}%">${escape(new Date(t).toLocaleTimeString('ru-RU',{hour:'2-digit',minute:'2-digit',...(span<300000?{second:'2-digit'}:{})}))}${i===0||i===count?`<small>${escape(date(t))}</small>`:''}</span>`;}).join('');
      $('#arc-recordings').innerHTML=m.intervals.filter(r=>r.end>start&&r.start<end).map(r=>`<span class="arc-recording" style="left:${Math.max(0,(r.start-start)/span*100)}%;width:${(Math.min(r.end,end)-Math.max(r.start,start))/span*100}%" title="${clock(r.start)} — ${clock(r.end)}"></span>`).join('');
      $('#arc-track-label').textContent=m.loaded?`${camera()?.name||''} · ${m.intervals.length} отрезков`:status==='searching'?'Поиск записей…':'Нет загруженных записей';
      $('#arc-range-label').textContent=`${date(m.range.start)} · ${duration(span)}`;
      $('#arc-time-fit').textContent=span>=m.range.end-m.range.start-1?'Весь период':duration(span);
      $('#arc-time-out').disabled=span>=m.range.end-m.range.start-1;
      $('#arc-time-in').disabled=span<=Math.min(60000,m.range.end-m.range.start);
      $('#arc-time-back').disabled=m.view.start<=m.range.start;$('#arc-time-forward').disabled=m.view.end>=m.range.end;
      updateCursor();updateSelection();
    }
    function playbackURL(endpoint,start,end) {
      return '/api/'+endpoint+'?'+new URLSearchParams({cam_id:m.camId,mode:'time',path:'',start:C.local(start,' '),end:C.local(end,' '),t:String(Date.now())});
    }
    function seek(ms,autoplay=true) {
      if(!m.loaded||!m.intervals.length)return;
      const target=C.clamp(Math.floor(ms/1000)*1000,m.range.start,m.range.end-1000),interval=C.intervalAt(m.intervals,target);
      followCursor=true;m.cursor=target;updateCursor(true);
      if(!interval){stopPlayback();setState('gap');showControls();return;}
      // A DVR response is an unseekable streamed MP4. Remote seek always opens a
      // fresh ByTime request within ONE contiguous recording interval.
      stopPlayback();playbackBase=target;playbackEnd=interval.end;wantPlay=autoplay;
      const generation=++playGeneration;video.playbackRate=m.speed;
      setState('loading');loading=true;video.src=playbackURL('playback',target,interval.end);video.load();
      if(autoplay)video.play().catch(e=>{if(!disposed&&generation===playGeneration&&!abortError(e)&&e.name==='NotAllowedError'){wantPlay=false;loading=false;clearTimeout(loadTimer);setState('paused');showControls();}});
      loadTimer=setTimeout(()=>{if(!disposed&&generation===playGeneration&&loading){stopPlayback();setState('error','Регистратор не передал воспроизводимое видео. Проверьте выбранное время и подключение.');}},25000);
    }
    function playToggle() {
      if(status==='searching'||!m.intervals.length)return;
      if(wantPlay&&video.hasAttribute('src')&&!video.ended){wantPlay=false;clearTimeout(loadTimer);loading=false;video.pause();setState('paused');showControls();return;}
      if(video.hasAttribute('src')&&status==='paused'&&!video.ended){wantPlay=true;video.play().catch(()=>{setState('error','Браузер не смог запустить видео. Повторите переход по шкале.');});}
      else {const target=C.intervalAt(m.intervals,m.cursor)?m.cursor:C.adjacent(m.intervals,m.cursor??-Infinity,1)?.start??m.intervals[0].start;seek(target);}
      showControls();
    }
    function nextRecord(direction) {const interval=C.adjacent(m.intervals,Number.isFinite(m.cursor)?m.cursor:direction<0?Infinity:-Infinity,direction);if(interval)seek(interval.start);}
    async function search({retainCursor=false}={}) {
      if(!valid(m.camId))return;
      const draft=m.custom?{start:C.time($('#arc-from').value),end:C.time($('#arc-to').value)}:C.dayRange($('#arc-date').value);
      if(!draft||![draft.start,draft.end].every(Number.isFinite)||draft.end-draft.start<1000){onError('Укажите корректный период: начало раньше конца.');return;}
      if(!m.custom){$('#arc-from').value=C.local(draft.start);$('#arc-to').value=C.local(draft.end);}
      m.draftStart=$('#arc-from').value;m.draftEnd=$('#arc-to').value;m.day=$('#arc-date').value;
      searchAbort?.abort();searchAbort=new AbortController();const generation=++searchGeneration,camId=m.camId;
      stopPlayback();m.range=draft;m.view={...draft};m.records=[];m.intervals=[];m.selection=null;m.loaded=false;if(!retainCursor)m.cursor=null;setState('searching');renderTimeline();$('#arc-search').disabled=true;
      try {
        const records=await api('/api/recordings?'+new URLSearchParams({cam_id:camId,start:C.local(draft.start,' '),end:C.local(draft.end,' '),mode:'files'}),{signal:searchAbort.signal});
        if(disposed||generation!==searchGeneration||camId!==m.camId)return;
        if(!Array.isArray(records))throw new Error('Регистратор вернул некорректный список записей.');
        m.records=records;m.intervals=C.normalize(records,draft.start,draft.end);m.loaded=true;
        m.cursor=retainCursor&&Number.isFinite(m.cursor)?C.clamp(m.cursor,draft.start,draft.end-1000):m.intervals[0]?.start??null;
        setState(m.intervals.length?'ready':'empty');renderTimeline();
      }catch(e){if(disposed||generation!==searchGeneration||abortError(e))return;setState('error',e.message);renderTimeline();}
      finally{if(!disposed&&generation===searchGeneration)$('#arc-search').disabled=!cameras.length;}
    }
    function changeDay(offset) {const d=new Date((C.dayRange($('#arc-date').value)||m.range).start);d.setDate(d.getDate()+offset);$('#arc-date').value=C.local(d.getTime()).slice(0,10);m.custom=false;$('#arc-custom-period').hidden=true;$('#arc-period').setAttribute('aria-expanded','false');search();}
    function changeScale(factor,anchor=(m.view.start+m.view.end)/2,ratio=.5) {followCursor=false;const span=C.clamp((m.view.end-m.view.start)*factor,Math.min(60000,m.range.end-m.range.start),m.range.end-m.range.start);m.view=C.viewWindow(m.range.start,m.range.end,span,anchor,ratio);renderTimeline();}
    function moveWindow(direction) {followCursor=false;m.view=C.viewWindow(m.range.start,m.range.end,m.view.end-m.view.start,(m.view.start+m.view.end)/2+direction*(m.view.end-m.view.start)*.6);renderTimeline();}
    function applyZoom(next,px=0,py=0) {zoom=C.zoomPoint(zoom.scale,next,zoom.x,zoom.y,px,py,layer.clientWidth,layer.clientHeight);video.style.transform=`translate(${zoom.x}px,${zoom.y}px) scale(${zoom.scale})`;viewer.classList.toggle('is-zoomed',zoom.scale>1);$('#arc-zoom-value').textContent=`${Number(zoom.scale.toFixed(1))}×`;$('#arc-zoom-indicator').hidden=zoom.scale<=1;$('#arc-zoom-indicator').textContent=`${Number(zoom.scale.toFixed(1))}× · перетащите изображение`;}
    function fullscreen() {if(document.fullscreenElement)document.exitFullscreen?.();else if(!document.fullscreenEnabled||!$('.archive-console').requestFullscreen)onError('Полноэкранный режим недоступен в этом браузере.');else $('.archive-console').requestFullscreen().catch(()=>onError('Полноэкранный режим недоступен в этом браузере.'));}
    function snapshot() {
      if(!video.videoWidth){onError('Сначала откройте видеозапись.');return;}
      const canvas=document.createElement('canvas');canvas.width=video.videoWidth;canvas.height=video.videoHeight;canvas.getContext('2d').drawImage(video,0,0);
      canvas.toBlob(blob=>{if(!blob)return;const a=document.createElement('a'),url=URL.createObjectURL(blob);a.href=url;a.download=`archive-${m.camId}-${C.local(m.cursor).replace(/[:T]/g,'-')}.jpg`;a.click();setTimeout(()=>URL.revokeObjectURL(url),2000);},'image/jpeg',.95);
    }
    function exportSelection() {
      if(!m.selection||!m.loaded||preciseDirty||C.coverage(m.intervals,m.selection)<=0)return;
      // Keep error JSON in an isolated same-origin frame, never navigate the app
      // or buffer a potentially multi-hour MP4 into browser RAM.
      const frame=document.createElement('iframe');frame.hidden=true;frame.title='Загрузка фрагмента архива';
      frame.addEventListener('load',()=>{try{const text=frame.contentDocument?.body?.textContent||'';if(!text.trim())return;const payload=JSON.parse(text);if(payload.error){onError('Экспорт: '+payload.error);if(!disposed&&$('#arc-status-text'))$('#arc-status-text').textContent='Экспорт не выполнен: '+payload.error;}frame.remove();}catch(_){/* attachment downloads do not expose a document */}});
      frame.src=playbackURL('download',m.selection.start,m.selection.end);document.body.append(frame);setTimeout(()=>frame.remove(),6*3600*1000);
      $('#arc-status-text').textContent='Экспорт запрошен. Состояние загрузки отображается в браузере.';
    }

    // Search controls use a separate draft range; editing inputs never changes
    // the identity or timestamps of already loaded footage.
    function invalidate() {searchAbort?.abort();++searchGeneration;stopPlayback();m.loaded=false;m.records=[];m.intervals=[];m.selection=null;setState('idle');renderTimeline();}
    on($('#arc-camera'),'change',()=>{invalidate();m.camId=$('#arc-camera').value;onSelect(m.camId);$('#arc-camera-title').textContent=camera()?.name||'';$('.arc-status > span:last-child').textContent=`Время регистратора · ${camera()?.ip||'—'}`;applyZoom(1);search({retainCursor:true});});
    on($('#arc-date'),'change',()=>{invalidate();m.custom=false;$('#arc-custom-period').hidden=true;$('#arc-period').setAttribute('aria-expanded','false');search();});
    on($('#arc-day-prev'),'click',()=>changeDay(-1));on($('#arc-day-next'),'click',()=>changeDay(1));
    on($('#arc-period'),'click',()=>{m.custom=!m.custom;$('#arc-custom-period').hidden=!m.custom;$('#arc-period').setAttribute('aria-expanded',String(m.custom));if(!m.custom)search();});
    on($('#arc-search'),'click',()=>search());
    on($('#arc-fullscreen'),'click',fullscreen);on($('#arc-player-fullscreen'),'click',fullscreen);
    on($('#arc-play'),'click',playToggle);on($('#arc-player-prev'),'click',()=>nextRecord(-1));on($('#arc-record-prev'),'click',()=>nextRecord(-1));on($('#arc-player-next'),'click',()=>nextRecord(1));on($('#arc-record-next'),'click',()=>nextRecord(1));
    on($('#arc-state'),'click',e=>{const action=e.target.closest('[data-action]')?.dataset.action;if(action==='play')playToggle();if(action==='next')nextRecord(1);if(action==='retry'){if(m.loaded&&m.intervals.length)seek(m.cursor??m.intervals[0].start);else search();}});
    on($('#arc-speed'),'change',()=>{m.speed=Number($('#arc-speed').value);video.playbackRate=m.speed;showControls();});
    on($('#arc-skip-gaps'),'click',()=>{m.skipGaps=!m.skipGaps;$('#arc-skip-gaps').setAttribute('aria-pressed',String(m.skipGaps));});
    on($('#arc-time-in'),'click',()=>changeScale(.5));on($('#arc-time-out'),'click',()=>changeScale(2));on($('#arc-time-fit'),'click',()=>{m.view={...m.range};renderTimeline();});on($('#arc-time-back'),'click',()=>moveWindow(-1));on($('#arc-time-forward'),'click',()=>moveWindow(1));
    on($('#arc-zoom-in'),'click',()=>{applyZoom(zoom.scale*1.25);showControls();});on($('#arc-zoom-out'),'click',()=>{applyZoom(zoom.scale/1.25);showControls();});on($('#arc-zoom-reset'),'click',()=>{applyZoom(1);showControls();});on($('#arc-snapshot'),'click',snapshot);
    on(viewer,'pointermove',showControls);on(viewer,'pointerdown',showControls);on(viewer,'focusin',showControls);
    on(layer,'wheel',e=>{if(!video.videoWidth)return;e.preventDefault();const r=layer.getBoundingClientRect();applyZoom(zoom.scale*(e.deltaY<0?1.15:1/1.15),e.clientX-r.left-r.width/2,e.clientY-r.top-r.height/2);showControls();},{passive:false});
    on(layer,'dblclick',e=>{if(!video.videoWidth)return;const r=layer.getBoundingClientRect();applyZoom(zoom.scale>1?1:2,e.clientX-r.left-r.width/2,e.clientY-r.top-r.height/2);showControls();});
    on(layer,'pointerdown',e=>{if(e.button!==0)return;pointers.set(e.pointerId,{x:e.clientX,y:e.clientY});layer.setPointerCapture(e.pointerId);if(pointers.size===2){const [a,b]=[...pointers.values()];pinch={distance:Math.hypot(a.x-b.x,a.y-b.y),scale:zoom.scale};pan=null;}else if(zoom.scale>1){pan={id:e.pointerId,x:e.clientX,y:e.clientY,baseX:zoom.x,baseY:zoom.y};viewer.classList.add('is-panning');}});
    on(layer,'pointermove',e=>{if(!pointers.has(e.pointerId))return;pointers.set(e.pointerId,{x:e.clientX,y:e.clientY});if(pinch&&pointers.size===2){const [a,b]=[...pointers.values()];applyZoom(pinch.scale*Math.hypot(a.x-b.x,a.y-b.y)/Math.max(1,pinch.distance));}else if(pan?.id===e.pointerId){zoom.x=C.clamp(pan.baseX+e.clientX-pan.x,-layer.clientWidth*(zoom.scale-1)/2,layer.clientWidth*(zoom.scale-1)/2);zoom.y=C.clamp(pan.baseY+e.clientY-pan.y,-layer.clientHeight*(zoom.scale-1)/2,layer.clientHeight*(zoom.scale-1)/2);video.style.transform=`translate(${zoom.x}px,${zoom.y}px) scale(${zoom.scale})`;}});
    const releasePointer=e=>{pointers.delete(e.pointerId);pinch=null;pan=null;viewer.classList.remove('is-panning');};on(layer,'pointerup',releasePointer);on(layer,'pointercancel',releasePointer);on(layer,'lostpointercapture',releasePointer);
    on($('#arc-export'),'click',exportSelection);
    on($('#arc-clear-selection'),'click',()=>{m.selection=null;precise=false;updateSelection();});
    on($('#arc-select-mode'),'click',()=>{selectionMode=!selectionMode;$('#arc-select-mode').setAttribute('aria-pressed',String(selectionMode));$('#arc-timeline-hint').textContent=selectionMode?'Протяните по шкале для выделения. Ручки меняют границы фрагмента.':'Щелчок — просмотр · протяните — фрагмент · Ctrl + колесо — масштаб';});
    on($('#arc-precise'),'click',()=>{precise=!precise;preciseDirty=false;updateSelection();if(precise)$('#arc-selection-start').focus();});
    const markPreciseDraft=()=>{preciseDirty=!!m.selection&&(C.time($('#arc-selection-start').value)!==m.selection.start||C.time($('#arc-selection-end').value)!==m.selection.end);updateSelection();};
    on($('#arc-selection-start'),'input',markPreciseDraft);on($('#arc-selection-end'),'input',markPreciseDraft);
    on($('#arc-selection-apply'),'click',()=>{const start=C.time($('#arc-selection-start').value),end=C.time($('#arc-selection-end').value);if(start===null||end===null||end-start<1000||start<m.range.start||end>m.range.end){onError('Фрагмент должен находиться внутри загруженного периода, начало — раньше конца.');return;}m.selection=C.selection(start,end,m.range.start,m.range.end);preciseDirty=false;$('#arc-selection-apply').focus();updateSelection();});

    const at=clientX=>{const r=track.getBoundingClientRect();return m.view.start+C.clamp((clientX-r.left)/Math.max(1,r.width),0,1)*(m.view.end-m.view.start);};
    on(track,'pointerdown',e=>{if(!m.loaded||!m.intervals.length||![0,1].includes(e.button))return;if($('#arc-selection-fields').contains(document.activeElement))document.activeElement.blur();preciseDirty=false;const handle=e.target.closest('[data-handle]')?.dataset.handle||'';timelineDrag={id:e.pointerId,x:e.clientX,time:at(e.clientX),last:at(e.clientX),handle,old:m.selection&&{...m.selection},mode:e.altKey||e.button===1?'pan':'select',view:{...m.view},moved:false,working:null};track.setPointerCapture(e.pointerId);track.classList.add('is-dragging');e.preventDefault();});
    on(track,'pointermove',e=>{const d=timelineDrag;if(!d||d.id!==e.pointerId)return;d.last=at(e.clientX);if(Math.abs(e.clientX-d.x)>4)d.moved=true;if(d.mode==='pan'){followCursor=false;const delta=(d.x-e.clientX)/Math.max(1,track.clientWidth)*(d.view.end-d.view.start);m.view=C.viewWindow(m.range.start,m.range.end,d.view.end-d.view.start,(d.view.start+d.view.end)/2+delta);renderTimeline();return;}let start=d.time,end=d.last;if(d.handle==='start'&&d.old){start=Math.min(d.last,d.old.end-1000);end=d.old.end;}if(d.handle==='end'&&d.old){start=d.old.start;end=Math.max(d.last,d.old.start+1000);}d.working=C.selection(start,end,m.range.start,m.range.end);if(d.moved||d.handle)updateSelection(d.working);});
    on(track,'pointerup',e=>{const d=timelineDrag;if(!d||d.id!==e.pointerId)return;timelineDrag=null;track.classList.remove('is-dragging');if(d.mode==='pan')return;if(d.handle||d.moved||selectionMode){m.selection=d.working||C.selection(d.time,d.last,m.range.start,m.range.end);updateSelection();}else{updateSelection();seek(d.time);}});
    on(track,'pointercancel',()=>{timelineDrag=null;track.classList.remove('is-dragging');updateSelection();});
    on(track,'wheel',e=>{if(!e.ctrlKey&&!e.metaKey&&!e.shiftKey&&Math.abs(e.deltaX)<1)return;e.preventDefault();if(e.ctrlKey||e.metaKey){const r=track.getBoundingClientRect();changeScale(e.deltaY<0?.65:1/.65,at(e.clientX),(e.clientX-r.left)/r.width);}else moveWindow((e.deltaX||e.deltaY)>0?1:-1);},{passive:false});
    on(track,'keydown',e=>{const handle=e.target.closest('[data-handle]')?.dataset.handle;if(!['ArrowLeft','ArrowRight','Home','End'].includes(e.key))return;e.preventDefault();const step=(e.shiftKey?10:1)*1000,direction=e.key==='ArrowLeft'?-1:1;if(handle&&m.selection){const s={...m.selection},min=handle==='start'?m.range.start:s.start+1000,max=handle==='start'?s.end-1000:m.range.end;s[handle]=e.key==='Home'?min:e.key==='End'?max:C.clamp(s[handle]+direction*step,min,max);m.selection=s;updateSelection();return;}let target=m.cursor??m.intervals[0]?.start??m.range.start;if(e.key==='Home')target=m.range.start;else if(e.key==='End')target=m.range.end-1000;else target+=direction*step;seek(target);});
    on($('.archive-console'),'keydown',e=>{if(e.target.closest('input,select,textarea,button'))return;if(e.code==='Space'){e.preventDefault();playToggle();}if(e.key==='Escape'&&zoom.scale>1)applyZoom(1);if(e.key==='+'||e.key==='='){e.preventDefault();applyZoom(zoom.scale*1.25);showControls();}if(e.key==='-'){e.preventDefault();applyZoom(zoom.scale/1.25);showControls();}});

    on(video,'playing',()=>{if(!video.hasAttribute('src')||playbackBase===null)return;clearTimeout(loadTimer);loading=false;wantPlay=true;video.playbackRate=m.speed;setState('playing');});
    on(video,'canplay',()=>{if(!wantPlay&&status==='loading'){clearTimeout(loadTimer);loading=false;setState('paused');}});
    on(video,'waiting',()=>{if(video.hasAttribute('src')&&wantPlay){setState('loading');clearTimeout(loadTimer);loadTimer=setTimeout(()=>{if(!disposed&&wantPlay&&status==='loading'){stopPlayback();setState('error','Передача видео остановилась. Повторите переход по шкале.');}},25000);}});
    on(video,'timeupdate',()=>{if(playbackBase===null||!Number.isFinite(video.currentTime))return;m.cursor=Math.min(playbackEnd,playbackBase+video.currentTime*1000);updateCursor(true);});
    on(video,'ended',()=>{
      if(playbackEnd===null||playbackBase===null||!video.ended)return;
      const actual=Math.min(playbackEnd,playbackBase+video.currentTime*1000),complete=playbackEnd-actual<=3000;
      m.cursor=complete?playbackEnd:actual;updateCursor(true);
      const next=m.intervals.find(r=>r.start>=playbackEnd);
      if(complete&&m.skipGaps&&wantPlay&&next)seek(next.start);
      else{wantPlay=false;setState('paused');showControls();if(!complete)$('#arc-status-text').textContent='Регистратор завершил передачу раньше конца отрезка. Позиция сохранена; можно продолжить с неё.';}
    });
    on(video,'error',()=>{if(disposed||!video.hasAttribute('src'))return;clearTimeout(loadTimer);loading=false;wantPlay=false;setState('error','Видео недоступно или кодек не поддерживается браузером. Проверьте время, регистратор и FFmpeg, затем повторите.');showControls();});
    on(document,'fullscreenchange',()=>{if(!disposed){applyZoom(zoom.scale);renderTimeline();}});
    const resize=new ResizeObserver(()=>{if(!disposed){applyZoom(zoom.scale);renderTimeline();}});resize.observe(viewer);
    renderTimeline();setState(!cameras.length?'empty':m.loaded?(m.intervals.length?'ready':'empty'):'idle');
    if(cameras.length&&!m.loaded)search();
    function dispose(){if(disposed)return;disposed=true;++searchGeneration;searchAbort?.abort();life.abort();resize.disconnect();clearTimeout(hideTimer);stopPlayback();}
    return dispose;
  }
  window.VMSArchive={mount};
})();
