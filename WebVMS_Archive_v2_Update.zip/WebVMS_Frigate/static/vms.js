/* Web VMS frontend. Keeps the original Flask/HLS/DVRIP API contract. */
(() => {
  'use strict';
  const $ = (s, root = document) => root.querySelector(s);
  const $$ = (s, root = document) => Array.from(root.querySelectorAll(s));
  const USER = window.WEBVMS_USER || { username: 'user', role: 'viewer', theme: 'auto' };
  const IS_ADMIN = USER.role === 'admin';
  const state = {
    view: 'live', theme: USER.theme || 'auto', cameras: [], groups: [], users: [],
    gridCols: 2, selectedGroup: '', liveSlots: [], slotCounter: 0, liveHls: new Map(),
    archive: { camId: '' },
    deviceCamId: '', deviceInfo: null, cameraSearch: '', userSearch: ''
  };

  const ICONS = {
    grid: '<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/>',
    archive: '<path d="M3 4h18v4H3z"/><path d="M5 8v12h14V8M10 12h4"/>',
    camera: '<rect x="3" y="6" width="13" height="12" rx="2"/><path d="m16 10 5-3v10l-5-3"/>',
    folder: '<path d="M3 6a2 2 0 0 1 2-2h5l2 2h7a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>',
    users: '<path d="M16 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="10" cy="7" r="4"/><path d="M20 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75"/>',
    sliders: '<path d="M4 21v-7m0-4V3m8 18v-9m0-4V3m8 18v-5m0-4V3M2 14h4m4-6h4m4 8h4"/>',
    menu: '<path d="M4 6h16M4 12h16M4 18h16"/>', monitor: '<rect x="3" y="4" width="18" height="13" rx="2"/><path d="M8 21h8m-4-4v4"/>',
    sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2v2m0 16v2M4.93 4.93l1.42 1.42m11.3 11.3 1.42 1.42M2 12h2m16 0h2M4.93 19.07l1.42-1.42m11.3-11.3 1.42-1.42"/>',
    moon: '<path d="M20.9 13A9 9 0 0 1 11 3.1 9 9 0 1 0 20.9 13Z"/>', logout: '<path d="M10 17l5-5-5-5M15 12H3"/><path d="M12 3h6a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-6"/>',
    plus: '<path d="M12 5v14M5 12h14"/>', search: '<circle cx="11" cy="11" r="7"/><path d="m20 20-4-4"/>',
    play: '<path d="m8 5 11 7-11 7z"/>', pause: '<path d="M8 5h3v14H8zM15 5h3v14h-3z"/>',
    stop: '<rect x="5" y="5" width="14" height="14" rx="2"/>', refresh: '<path d="M20 7v5h-5M4 17v-5h5"/><path d="M5.6 9A7 7 0 0 1 18 6l2 6M4 12l2 6a7 7 0 0 0 12.4-3"/>',
    edit: '<path d="M12 20h9"/><path d="M16.5 3.5a2.12 2.12 0 0 1 3 3L8 18l-4 1 1-4Z"/>',
    trash: '<path d="M3 6h18M8 6V4h8v2m3 0-1 14H6L5 6m4 4v6m6-6v6"/>',
    close: '<path d="m18 6-12 12M6 6l12 12"/>', check: '<path d="m5 12 4 4L19 6"/>',
    download: '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M7 10l5 5 5-5M12 15V3"/>',
    expand: '<path d="M8 3H5a2 2 0 0 0-2 2v3m13-5h3a2 2 0 0 1 2 2v3M3 16v3a2 2 0 0 0 2 2h3m8 0h3a2 2 0 0 0 2-2v-3"/>',
    info: '<circle cx="12" cy="12" r="10"/><path d="M12 16v-4m0-4h.01"/>',
    calendar: '<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M16 3v4M8 3v4M3 10h18"/>',
    server: '<rect x="3" y="3" width="18" height="7" rx="2"/><rect x="3" y="14" width="18" height="7" rx="2"/><path d="M7 6h.01M7 17h.01M11 6h6m-6 11h6"/>',
    shield: '<path d="M12 22s8-4 8-11V5l-8-3-8 3v6c0 7 8 11 8 11Z"/><path d="m9 12 2 2 4-4"/>',
    alert: '<path d="M10.3 3.9 1.9 18.4A2 2 0 0 0 3.6 21h16.8a2 2 0 0 0 1.7-2.6L13.7 3.9a2 2 0 0 0-3.4 0Z"/><path d="M12 9v4m0 4h.01"/>',
    link: '<path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"/>',
    clock: '<circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/>',
    circle: '<circle cx="12" cy="12" r="9"/>',
    key: '<circle cx="8" cy="15" r="5"/><path d="m11.5 11.5 9-9m-2 2 2 2m-5 1 2 2"/>',
    eye: '<path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7-10-7-10-7Z"/><circle cx="12" cy="12" r="3"/>',
    route: '<circle cx="6" cy="6" r="3"/><circle cx="18" cy="18" r="3"/><path d="M9 6h3a3 3 0 0 1 3 3v3a3 3 0 0 0 3 3"/>',
    arrowLeft: '<path d="M19 12H5m7 7-7-7 7-7"/>' ,
    arrowRight: '<path d="M5 12h14m-7-7 7 7-7 7"/>'
  };
  function icon(name, cls = '') { return `<svg class="${cls}" viewBox="0 0 24 24" aria-hidden="true">${ICONS[name] || ICONS.info}</svg>`; }
  function esc(value) { return String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }
  function titleCase(value) { return value ? value[0].toUpperCase() + value.slice(1) : ''; }
  function nowLocalInput(date = new Date()) { const p = n => String(n).padStart(2,'0'); return `${date.getFullYear()}-${p(date.getMonth()+1)}-${p(date.getDate())}T${p(date.getHours())}:${p(date.getMinutes())}`; }
  function inputTime(value) { return value ? String(value).replace(' ','T').slice(0,19) : ''; }
  function localDateTimeSeconds(ms) { const d=new Date(ms); if(!Number.isFinite(d.getTime()))return ''; const p=n=>String(n).padStart(2,'0'); return `${d.getFullYear()}-${p(d.getMonth()+1)}-${p(d.getDate())}T${p(d.getHours())}:${p(d.getMinutes())}:${p(d.getSeconds())}`; }
  function apiDateTimeSeconds(ms) { return localDateTimeSeconds(ms).replace('T',' '); }
  function formatDateTimeSeconds(ms) { const d=new Date(ms); if(!Number.isFinite(d.getTime()))return '—'; return d.toLocaleDateString('ru-RU',{day:'2-digit',month:'short'})+' '+d.toLocaleTimeString('ru-RU',{hour:'2-digit',minute:'2-digit',second:'2-digit'}); }
  function apiTime(value) { return value ? (value.replace('T',' ') + (value.length === 16 ? ':00' : '')) : ''; }
  function parseTime(value) { const d = new Date(String(value || '').replace(' ','T')); return Number.isNaN(d.getTime()) ? null : d; }
  function fmtTime(value) { const d = parseTime(value); if (!d) return '—'; return d.toLocaleTimeString('ru-RU',{hour:'2-digit',minute:'2-digit',second:'2-digit'}); }
  function fmtDate(value) { const d = parseTime(value); if (!d) return '—'; return d.toLocaleDateString('ru-RU',{day:'2-digit',month:'short',year:'numeric'}); }
  function durationText(start, end) { const a=parseTime(start),b=parseTime(end);if(!a||!b)return '—';let s=Math.max(0,Math.round((b-a)/1000));const h=Math.floor(s/3600),m=Math.floor(s%3600/60),sec=s%60;return h?`${h} ч ${m} мин`:(m?`${m} мин ${sec} с`:`${sec} с`); }
  function camById(id) { return state.cameras.find(c => c.id === id); }
  function groupById(id) { return state.groups.find(g => g.id === id); }
  function protocolLabel(cam) { return cam?.protocol === 'dvrip' ? 'DVRIP' : 'RTSP / ONVIF'; }
  function showToast(message, type = 'success') {
    const root = $('#toast-root'); const item = document.createElement('div'); item.className = `toast ${type === 'error' ? 'error' : type === 'warning' ? 'warning' : ''}`;
    const sym = type === 'error' ? 'alert' : type === 'warning' ? 'info' : 'check'; item.innerHTML = `${icon(sym)}<div class="toast-message">${esc(message)}</div>`; root.appendChild(item); setTimeout(() => item.remove(), 4500);
  }
  async function api(url, options = {}) {
    const opts = {...options, headers: {...(options.headers || {})}};
    if (opts.body && typeof opts.body !== 'string') { opts.headers['Content-Type'] = 'application/json'; opts.body = JSON.stringify(opts.body); }
    const response = await fetch(url, opts);
    let data = {}; const type = response.headers.get('content-type') || '';
    if (type.includes('application/json')) data = await response.json();
    if (response.status === 401) { window.location.href = '/login'; throw new Error('Сеанс завершён. Войдите снова.'); }
    if (!response.ok) throw new Error(data.error || `Ошибка ${response.status}`);
    return data;
  }

  async function init() {
    $$('[data-icon]').forEach(el => { el.innerHTML = icon(el.dataset.icon); });
    $('#user-name').textContent = USER.username || 'Пользователь';
    $('#user-avatar').textContent = (USER.username || 'U').slice(0,1).toUpperCase();
    $('#user-role').textContent = IS_ADMIN ? 'Администратор' : 'Просмотр';
    $$('.admin-only').forEach(el => { if (!IS_ADMIN) el.remove(); });
    document.documentElement.dataset.theme = state.theme;
    updateThemeControls();
    $$('.nav-item').forEach(btn => {btn.setAttribute('aria-label',TITLES[btn.dataset.view]);btn.title=TITLES[btn.dataset.view];btn.addEventListener('click', () => activateView(btn.dataset.view));});
    $$('[data-theme-choice]').forEach(btn => btn.addEventListener('click', () => setTheme(btn.dataset.themeChoice)));
    $('#mobile-menu').addEventListener('click', () => document.body.classList.toggle('menu-open'));
    document.addEventListener('keydown', e => { if (e.key === 'Escape') { closeModal(); document.body.classList.remove('menu-open'); } });
    try { await loadData(); } catch (e) { showToast(e.message, 'error'); }
    readWorkspace();
    state.treeHidden=window.matchMedia('(max-width:560px)').matches;
    renderCurrentView();
  }

  async function loadData() {
    const [cameras, groups] = await Promise.all([api('/api/cameras'), api('/api/groups')]);
    state.cameras = Array.isArray(cameras) ? cameras : [];
    state.groups = Array.isArray(groups) ? groups : [];
    state.cameras.sort((a,b) => String(a.name).localeCompare(String(b.name),'ru'));
    state.groups.sort((a,b) => String(a.name).localeCompare(String(b.name),'ru'));
    $('#nav-camera-count').textContent = state.cameras.length;
    if (IS_ADMIN) {
      try { const users = await api('/api/users'); state.users = Array.isArray(users) ? users : []; }
      catch (e) { state.users = []; }
    }
    const dvrCameras = state.cameras.filter(c => c.protocol === 'dvrip');
    if (!dvrCameras.some(c => c.id === state.archive.camId)) state.archive.camId = dvrCameras[0]?.id || '';
    if (!state.cameras.some(c => c.id === state.deviceCamId)) state.deviceCamId = dvrCameras[0]?.id || state.cameras[0]?.id || '';
    if (!state.liveSlots.length) state.liveSlots = state.cameras.map(c => ({ uid: ++state.slotCounter, camId: c.id, stream: state.cameras.length > 1 ? 'sub' : 'main' }));
    else state.liveSlots = state.liveSlots.filter(s => !s.camId||camById(s.camId));
  }

  function updateThemeControls() {
    $$('[data-theme-choice]').forEach(btn => { const active = btn.dataset.themeChoice === state.theme; btn.classList.toggle('selected', active); btn.setAttribute('aria-pressed', active ? 'true' : 'false'); });
  }
  async function setTheme(theme) {
    state.theme = ['auto','light','dark'].includes(theme) ? theme : 'auto';
    document.documentElement.dataset.theme = state.theme; updateThemeControls();
    try { await api('/api/profile/theme', {method:'POST', body:{theme:state.theme}}); }
    catch (e) { showToast('Тема применена в браузере, но не сохранена: ' + e.message, 'warning'); }
  }

  const TITLES = { live:'Просмотр', archive:'Архив', cameras:'Камеры', groups:'Группы', users:'Пользователи', devices:'Устройства' };
  function activateView(view) {
    if (!TITLES[view] || (!IS_ADMIN && ['cameras','groups','users','devices'].includes(view))) return;
    if (state.view === 'live' && view !== 'live') stopAllLivePlayers();
    state.view = view; document.body.dataset.view=view; document.body.classList.remove('menu-open');
    closeLiveContextMenu();
    devicePageCleanup?.();devicePageCleanup=null;
    archivePageCleanup?.();archivePageCleanup=null;
    if(view!=='live'&&sequenceTimer){clearInterval(sequenceTimer);sequenceTimer=null;}
    $$('.nav-item').forEach(btn => btn.classList.toggle('active', btn.dataset.view === view));
    $('#current-section').textContent = TITLES[view]; renderCurrentView();
  }
  function renderCurrentView() {
    document.body.dataset.view=state.view;
    $('#current-section').textContent = TITLES[state.view] || 'Просмотр';
    if (state.view === 'live') renderLive();
    else if (state.view === 'archive') renderArchive();
    else if (state.view === 'cameras') renderCameras();
    else if (state.view === 'groups') renderGroups();
    else if (state.view === 'users') renderUsers();
    else if (state.view === 'devices') renderDevices();
  }
  function pageHeader(title, description, actions = '') {
    return `<div class="page-header"><div class="page-heading"><h1 class="page-title">${title}</h1><p class="page-description">${description}</p></div><div class="page-actions">${actions}</div></div>`;
  }
  function emptyState(title, description, action = '') {
    return `<div class="empty-state"><div class="empty-icon">${icon('camera')}</div><h3>${esc(title)}</h3><p>${esc(description)}</p>${action}</div>`;
  }

  // Compact VMS workspace. Layout changes keep server streams shared by viewers.
  let archivePageCleanup = null;
  let devicePageCleanup = null;
  let ptzCleanup = null;
  let sequenceTimer = null;
  const layoutKey = `webvms.workspace.${USER.username}`;
  function readWorkspace() {
    try {
      const saved = JSON.parse(localStorage.getItem(layoutKey) || 'null');
      if (!saved) return;
      if ([1,2,3,4].includes(saved.cols)) state.gridCols = saved.cols;
      if (Array.isArray(saved.slots)) state.liveSlots = saved.slots.filter(s => s&&(!s.camId||camById(s.camId))).slice(0,256).map(s => ({uid:++state.slotCounter,camId:s.camId,stream:s.stream === 'main' ? 'main' : 'sub'}));
    } catch (_) {}
  }
  function saveWorkspace() {
    try { localStorage.setItem(layoutKey,JSON.stringify({cols:state.gridCols,slots:state.liveSlots.map(({camId,stream})=>({camId,stream}))})); }
    catch (_) { showToast('Браузер не разрешил сохранить раскладку.','warning'); }
  }
  function visibleSlots() {
    const capacity=state.gridCols**2;
    state.livePage=Math.min(state.livePage||0,Math.max(0,Math.ceil(state.liveSlots.length/capacity)-1));
    return state.liveSlots.slice(state.livePage*capacity,(state.livePage+1)*capacity);
  }
  function selectedLiveSlot() { return state.liveSlots.find(s=>s.uid===state.selectedSlot); }
  function treeCamera(cam) {
    const active=state.liveSlots.some(s=>s.camId===cam.id);
    return `<button class="device-tree-camera ${active?'in-layout':''}" draggable="true" data-camera="${esc(cam.id)}" title="${esc(cam.name)} — перетащите в ячейку или нажмите дважды">${icon('camera')}<span>${esc(cam.name)}</span><small>${cam.protocol==='dvrip'?String(Number(cam.channel||0)+1).padStart(2,'0'):'IP'}</small></button>`;
  }
  function deviceTreeHtml() {
    const term=(state.treeSearch||'').toLowerCase();
    const group=groupById(state.selectedGroup);
    const cameras=state.cameras.filter(c=>(!group||(group.camera_ids||[]).includes(c.id))&&`${c.name} ${c.ip}`.toLowerCase().includes(term));
    const recorders=new Map(),direct=[];
    cameras.forEach(c=>{if(c.protocol==='dvrip'){const key=`${c.ip}:${c.port||34567}`;if(!recorders.has(key))recorders.set(key,[]);recorders.get(key).push(c);}else direct.push(c);});
    return [...recorders.entries()].map(([host,cams])=>`<details class="tree-recorder" open><summary>${icon('server')}<span>${esc(host)}</span><small>${cams.length}</small></summary><div class="tree-channels">${cams.map(treeCamera).join('')}</div></details>`).join('')+(direct.length?`<details class="tree-recorder" open><summary>${icon('folder')}<span>IP-камеры</span><small>${direct.length}</small></summary><div class="tree-channels">${direct.map(treeCamera).join('')}</div></details>`:'')||'<div class="tree-empty">Камеры не найдены</div>';
  }
  function renderLive() {
    stopAllLivePlayers();
    closeLiveContextMenu();
    document.body.dataset.view='live';
    const slots=visibleSlots(),capacity=state.gridCols**2;
    if(!slots.some(s=>s.uid===state.selectedSlot&&camById(s.camId)))state.selectedSlot=slots.find(s=>camById(s.camId))?.uid||null;
    const pages=Math.max(1,Math.ceil(state.liveSlots.length/capacity));
    const groupOptions=state.groups.map(g=>`<option value="${esc(g.id)}" ${state.selectedGroup===g.id?'selected':''}>${esc(g.name)}</option>`).join('');
    $('#main-content').innerHTML=`<section class="vms-console">
      <div class="console-toolbar"><div class="console-title">${icon('monitor')}<h1>Видеонаблюдение</h1><span class="console-live-label">ПРЯМОЙ ЭФИР</span></div><div class="console-toolbar-actions"><button class="btn btn-sm" id="toggle-tree" title="Дерево устройств" aria-label="Дерево устройств">${icon('folder')}</button><div class="segmented layout-picker" aria-label="Раскладка камер">${[1,2,3,4].map(n=>`<button data-grid="${n}" class="${state.gridCols===n?'active':''}" aria-pressed="${state.gridCols===n}" title="${n*n} ${n===1?'камера':'камер'}">${layoutIcon(n)}<span>${n*n}</span></button>`).join('')}</div><button class="btn btn-sm" id="save-layout" title="Сохранить раскладку в этом браузере">${icon('download')}<span>Сохранить вид</span></button><button class="btn btn-sm" id="wall-fullscreen" title="Видеостена на весь экран" aria-label="Видеостена на весь экран">${icon('expand')}</button><button class="btn btn-sm ${state.inspectorOpen?'selected':''}" id="toggle-inspector" title="Панель активной камеры" aria-label="Панель активной камеры">${icon('sliders')}</button></div></div>
      <div class="console-body ${state.treeHidden?'tree-hidden':''} ${state.inspectorOpen?'inspector-open':''}">
        <aside class="device-explorer"><div class="explorer-heading"><b>Устройства</b><span>${state.cameras.length}</span>${IS_ADMIN?`<button class="icon-btn" id="explorer-add" title="Добавить устройство" aria-label="Добавить устройство">${icon('plus')}</button>`:''}</div><div class="explorer-filters"><div class="search-wrap">${icon('search')}<input id="tree-search" class="field" placeholder="Поиск камеры или IP" aria-label="Поиск устройств" value="${esc(state.treeSearch||'')}"></div><select class="select" id="live-group-filter" aria-label="Группа камер"><option value="">Все устройства</option>${groupOptions}</select></div><div class="device-tree" id="device-tree">${deviceTreeHtml()}</div><div class="explorer-bottom"><button class="btn btn-sm" id="show-all-cameras">${icon('grid')} Все камеры на экран</button><p>Двойной щелчок — открыть<br>Перетаскивание — назначить ячейку</p></div></aside>
        <div class="monitor-workspace"><div class="monitor-strip"><span>${icon('grid')} <b>${state.selectedGroup?esc(groupById(state.selectedGroup)?.name):'Основной монитор'}</b></span><div><button class="icon-btn" id="page-prev" aria-label="Предыдущая страница" ${state.livePage===0?'disabled':''}>${icon('arrowLeft')}</button><span class="page-count">${state.livePage+1} / ${pages}</span><button class="icon-btn" id="page-next" aria-label="Следующая страница" ${state.livePage>=pages-1?'disabled':''}>${icon('arrowRight')}</button><button class="icon-btn ${sequenceTimer?'sequence-active':''}" id="sequence-toggle" title="Автосмена страниц каждые 15 секунд" aria-label="Автосмена страниц" aria-pressed="${Boolean(sequenceTimer)}">${icon('route')}</button></div></div>
          <div class="camera-wall vms-wall" id="camera-wall" style="--grid-cols:${state.gridCols};--grid-rows:${state.gridCols}">${Array.from({length:capacity},(_,i)=>slots[i]&&camById(slots[i].camId)?liveTile(slots[i],state.livePage*capacity+i):emptyLiveTile(i)).join('')}</div>
          <div class="monitor-transport"><div class="transport-camera" id="transport-camera">${icon('camera')}<span>Выберите камеру</span></div><div class="transport-actions"><button class="icon-btn" id="selected-zoom-reset" title="Сбросить цифровое увеличение" aria-label="Сбросить увеличение">${icon('search')}</button><button class="icon-btn" id="selected-pip" title="Картинка в картинке" aria-label="Картинка в картинке">${icon('monitor')}</button><button class="icon-btn" id="selected-reconnect" title="Переподключить выбранную камеру" aria-label="Переподключить выбранную камеру">${icon('refresh')}</button><button class="icon-btn" id="selected-snapshot" title="Сохранить снимок выбранной камеры" aria-label="Сохранить снимок">${icon('camera')}</button><button class="btn btn-sm" id="selected-archive">${icon('archive')} Архив</button></div></div>
        </div><aside class="camera-inspector" id="camera-inspector"></aside>
      </div><footer class="console-status"><span><i class="status-dot online"></i> Сервер подключён</span><span id="stream-summary">Подключение потоков…</span><span class="console-clock" id="console-clock"></span></footer>
    </section>`;
    bindDeviceTree();
    $('#tree-search').addEventListener('input',e=>{state.treeSearch=e.target.value;$('#device-tree').innerHTML=deviceTreeHtml();bindDeviceTree();});
    $('#live-group-filter').addEventListener('change',e=>{state.selectedGroup=e.target.value;state.focusRestore=null;const group=groupById(state.selectedGroup);state.liveSlots=state.cameras.filter(c=>!group||(group.camera_ids||[]).includes(c.id)).map(c=>({uid:++state.slotCounter,camId:c.id,stream:'sub'}));state.livePage=0;renderLive();});
    $('#explorer-add')?.addEventListener('click',()=>openCameraModal());
    $('#show-all-cameras').addEventListener('click',()=>{state.focusRestore=null;const group=groupById(state.selectedGroup);state.liveSlots=state.cameras.filter(c=>!group||(group.camera_ids||[]).includes(c.id)).map(c=>({uid:++state.slotCounter,camId:c.id,stream:'sub'}));state.livePage=0;renderLive();});
    $$('[data-grid]').forEach(b=>b.addEventListener('click',()=>{state.gridCols=Number(b.dataset.grid);state.livePage=0;state.focusRestore=null;renderLive();}));
    $('#save-layout').addEventListener('click',()=>{saveWorkspace();showToast('Раскладка сохранена для этого пользователя');});
    $('#toggle-tree').addEventListener('click',()=>{state.treeHidden=!state.treeHidden;$('.console-body').classList.toggle('tree-hidden',state.treeHidden);});
    $('#toggle-inspector').addEventListener('click',()=>{state.inspectorOpen=!state.inspectorOpen;$('.console-body').classList.toggle('inspector-open',state.inspectorOpen);if(state.inspectorOpen)renderLiveInspector();else{ptzCleanup?.();ptzCleanup=null;}});
    $('#wall-fullscreen').addEventListener('click',()=>{if(document.fullscreenElement)document.exitFullscreen?.();else $('.monitor-workspace').requestFullscreen?.().catch(()=>showToast('Полноэкранный режим недоступен','warning'));});
    $('#page-prev').addEventListener('click',()=>{state.focusRestore=null;state.livePage=Math.max(0,state.livePage-1);renderLive();});
    $('#page-next').addEventListener('click',()=>{state.focusRestore=null;state.livePage=Math.min(pages-1,state.livePage+1);renderLive();});
    $('#sequence-toggle').addEventListener('click',()=>{if(sequenceTimer){clearInterval(sequenceTimer);sequenceTimer=null;}else sequenceTimer=setInterval(()=>{if(state.view!=='live')return;const count=Math.ceil(state.liveSlots.length/state.gridCols**2);if(count>1){state.livePage=(state.livePage+1)%count;renderLive();}},15000);$('#sequence-toggle').classList.toggle('sequence-active',Boolean(sequenceTimer));$('#sequence-toggle').setAttribute('aria-pressed',String(Boolean(sequenceTimer)));});
    $$('.camera-tile').forEach(tile=>{tile.addEventListener('click',()=>selectLiveSlot(Number(tile.dataset.tile)));tile.addEventListener('dblclick',e=>{if(e.target.closest('button,select'))return;focusLiveSlot(Number(tile.dataset.tile));});});
    $$('.vms-wall > *').forEach(tile=>{tile.addEventListener('dragover',e=>{e.preventDefault();tile.classList.add('drop-target');});tile.addEventListener('dragleave',()=>tile.classList.remove('drop-target'));tile.addEventListener('drop',e=>{e.preventDefault();placeLiveCamera(e.dataTransfer.getData('text/plain'),tile.dataset.tile?Number(tile.dataset.tile):null,Number(tile.dataset.empty));});});
    $$('.empty-live-tile').forEach(b=>b.addEventListener('click',()=>openSlotPicker(Number(b.dataset.empty))));
    $$('.tile-stream-select').forEach(el=>el.addEventListener('change',()=>changeLiveStream(el.dataset.uid,el.value)));
    $$('.tile-remove').forEach(el=>el.addEventListener('click',e=>{e.stopPropagation();removeLiveSlot(el.dataset.uid);}));
    $$('.tile-fullscreen').forEach(el=>el.addEventListener('click',e=>{e.stopPropagation();focusLiveSlot(Number(el.dataset.uid));}));
    $('#selected-zoom-reset').addEventListener('click',()=>setDigitalZoom(state.selectedSlot,1));
    $('#selected-pip').addEventListener('click',pictureInPicture);
    $$('.camera-tile').forEach(tile=>{tile.addEventListener('contextmenu',e=>{e.preventDefault();selectLiveSlot(Number(tile.dataset.tile));openLiveContextMenu(e.clientX,e.clientY);});tile.addEventListener('keydown',e=>{if(e.key==='Enter'&&!e.target.closest('button,select')){e.preventDefault();focusLiveSlot(Number(tile.dataset.tile));}});const stage=tile.querySelector('.video-stage');stage.addEventListener('wheel',e=>{e.preventDefault();selectLiveSlot(Number(tile.dataset.tile));const video=tile.querySelector('video');setDigitalZoom(Number(tile.dataset.tile),Math.max(1,Math.min(5,(Number(video.dataset.zoom)||1)+(e.deltaY<0?.25:-.25))),e);},{passive:false});stage.addEventListener('pointermove',e=>{const v=tile.querySelector('video');if(Number(v.dataset.zoom)>1){const r=stage.getBoundingClientRect();v.style.transformOrigin=`${(e.clientX-r.left)/r.width*100}% ${(e.clientY-r.top)/r.height*100}%`;}});});
    $('#selected-reconnect').addEventListener('click',()=>{const s=selectedLiveSlot();if(s){destroyLivePlayer(s.uid);attachLivePlayer(s);}});
    $('#selected-snapshot').addEventListener('click',snapshotSelected);
    $('#selected-archive').addEventListener('click',()=>openSelectedArchive());
    selectLiveSlot(state.selectedSlot);updateConsoleClock();
    requestAnimationFrame(()=>{if(state.view==='live')slots.forEach(attachLivePlayer);});
  }
  function layoutIcon(n) { return `<svg viewBox="0 0 18 18" aria-hidden="true"><rect x="2" y="2" width="14" height="14" rx="1"/>${Array.from({length:n-1},(_,i)=>`<path d="M${2+14*(i+1)/n} 2v14M2 ${2+14*(i+1)/n}h14"/>`).join('')}</svg>`; }
  function emptyLiveTile(index) { return `<button class="empty-live-tile" data-empty="${index}" aria-label="Назначить камеру в ячейку ${index+1}"><span class="empty-channel">${String(state.livePage*state.gridCols**2+index+1).padStart(2,'0')}</span>${icon('plus')}<span>Перетащите камеру</span></button>`; }
  function liveTile(slot,index) {
    const cam=camById(slot.camId);if(!cam)return '';
    return `<article class="camera-tile ${state.selectedSlot===slot.uid?'selected':''}" data-tile="${slot.uid}" tabindex="0" aria-label="${esc(cam.name)}"><div class="tile-head"><span class="channel-number">${String(index+1).padStart(2,'0')}</span><div class="tile-name" title="${esc(cam.name)}">${esc(cam.name)}</div><span class="stream-state" id="stream-state-${slot.uid}">Соединение</span><div class="tile-actions">${cam.protocol==='dvrip'?`<select class="select select-sm tile-stream-select" data-uid="${slot.uid}" aria-label="Качество ${esc(cam.name)}"><option value="main" ${slot.stream==='main'?'selected':''}>${cam.protocol==='dvrip'?'HD':'1'}</option><option value="sub" ${slot.stream==='sub'?'selected':''}>${cam.protocol==='dvrip'?'SD':'2'}</option></select>`:'<span class="tile-fixed-stream">RTSP</span>'}<button class="icon-btn tile-fullscreen" data-uid="${slot.uid}" title="Развернуть / вернуть сетку" aria-label="Развернуть ${esc(cam.name)}">${icon('expand')}</button><button class="icon-btn tile-remove" data-uid="${slot.uid}" title="Убрать с экрана" aria-label="Убрать ${esc(cam.name)}">${icon('close')}</button></div></div><div class="video-stage"><video id="live-video-${slot.uid}" muted autoplay playsinline></video><div class="video-overlay" id="live-overlay-${slot.uid}"><div class="spin"></div><span class="overlay-title">Подключение</span><span class="overlay-msg">${esc(cam.ip)}</span></div></div><div class="tile-foot"><span>${esc(cam.ip)}${cam.protocol==='dvrip'?` / CH ${Number(cam.channel||0)+1}`:''}</span><span>${esc(protocolLabel(cam))}</span></div></article>`;
  }
  function bindDeviceTree() {
    $$('.device-tree-camera').forEach(b=>{b.addEventListener('dragstart',e=>e.dataTransfer.setData('text/plain',b.dataset.camera));b.addEventListener('dblclick',()=>placeLiveCamera(b.dataset.camera,state.selectedSlot));b.addEventListener('click',()=>{$$('.device-tree-camera').forEach(x=>x.classList.toggle('tree-selected',x===b));});b.addEventListener('keydown',e=>{if(e.key==='Enter')placeLiveCamera(b.dataset.camera,state.selectedSlot);});});
  }
  function openSlotPicker(index){
    $('#modal-root').innerHTML=`<div class="modal-backdrop" data-backdrop><section class="modal modal-sm" role="dialog" aria-modal="true" aria-labelledby="slot-picker-title"><div class="modal-head"><div><h2 id="slot-picker-title">Камера для ячейки ${state.livePage*state.gridCols**2+index+1}</h2><p>Подключение устройства останется прежним.</p></div><button class="icon-btn" data-close aria-label="Закрыть">${icon('close')}</button></div><div class="modal-body slot-picker-list">${state.cameras.length?state.cameras.map(c=>`<button class="btn slot-pick" data-camera="${esc(c.id)}">${icon('camera')}<span>${esc(c.name)}<small>${esc(c.ip)}</small></span></button>`).join(''):'<p>Нет добавленных камер</p>'}</div></section></div>`;
    $$('.slot-pick').forEach(b=>b.addEventListener('click',()=>{closeModal();placeLiveCamera(b.dataset.camera,null,index);}));bindModalClose();$('#modal-root .slot-pick')?.focus();
  }
  function placeLiveCamera(camId,uid=null,emptyIndex=0) {
    if(!camById(camId))return;
    const slot=state.liveSlots.find(s=>s.uid===uid);
    if(slot){slot.camId=camId;state.selectedSlot=slot.uid;}
    else {const added={uid:++state.slotCounter,camId,stream:'sub'},position=state.livePage*state.gridCols**2+(emptyIndex||0);while(state.liveSlots.length<=position)state.liveSlots.push({uid:++state.slotCounter,camId:null,stream:'sub'});state.liveSlots[position]=added;state.selectedSlot=added.uid;}
    renderLive();
  }
  function selectLiveSlot(uid) {
    const changed=state.selectedSlot!==uid;state.selectedSlot=uid;
    $$('.camera-tile').forEach(t=>t.classList.toggle('selected',Number(t.dataset.tile)===uid));
    const slot=selectedLiveSlot(),cam=camById(slot?.camId);
    $('#transport-camera').innerHTML=`${icon('camera')}<span>${cam?esc(cam.name):'Камера не выбрана'}</span>${cam?`<small>${esc(cam.ip)}</small>`:''}`;
    $('#selected-archive').disabled=!cam||cam.protocol!=='dvrip';
    $('#selected-archive').title=cam?.protocol==='dvrip'?'Архив выбранного канала':'Архив доступен для DVRIP-каналов';
    if(state.inspectorOpen&&(changed||!$('#camera-inspector').children.length))renderLiveInspector();
  }
  function setDigitalZoom(uid,zoom,event=null){const video=$(`#live-video-${uid}`);if(!video)return;video.dataset.zoom=String(zoom);video.style.transform=`scale(${zoom})`;video.closest('.video-stage').classList.toggle('digitally-zoomed',zoom>1);const old=video.parentElement.querySelector('.digital-zoom-label');old?.remove();if(zoom>1){const label=document.createElement('span');label.className='digital-zoom-label';label.textContent=`${zoom.toFixed(2).replace(/0$/,'')}× · колесо — масштаб`;video.parentElement.append(label);}}
  async function pictureInPicture(){const s=selectedLiveSlot(),video=s&&$(`#live-video-${s.uid}`);if(!video?.videoWidth)return showToast('Дождитесь изображения с камеры','warning');try{if(document.pictureInPictureElement)await document.exitPictureInPicture();else if(document.pictureInPictureEnabled)await video.requestPictureInPicture();else showToast('Картинка в картинке недоступна в этом браузере','warning');}catch(_){showToast('Не удалось открыть отдельное окно видео','warning');}}
  function closeLiveContextMenu(){document.querySelector('.live-context-menu')?.remove();}
  function openLiveContextMenu(x,y){closeLiveContextMenu();const menu=document.createElement('div');menu.className='live-context-menu';menu.setAttribute('role','menu');const actions=[['expand','Развернуть / вернуть сетку',()=>focusLiveSlot(state.selectedSlot)],['camera','Сохранить снимок',snapshotSelected],['search','Сбросить увеличение',()=>setDigitalZoom(state.selectedSlot,1)],['monitor','Картинка в картинке',pictureInPicture],['refresh','Переподключить',()=>{const s=selectedLiveSlot();if(s){destroyLivePlayer(s.uid);attachLivePlayer(s);}}],['archive','Архив канала',openSelectedArchive],['close','Убрать с экрана',()=>removeLiveSlot(state.selectedSlot)]];actions.forEach(([symbol,label,run])=>{const b=document.createElement('button');b.setAttribute('role','menuitem');b.innerHTML=`${icon(symbol)}<span>${label}</span>`;if(symbol==='archive')b.disabled=camById(selectedLiveSlot()?.camId)?.protocol!=='dvrip';b.onclick=()=>{closeLiveContextMenu();run();};menu.append(b);});(document.fullscreenElement||document.body).append(menu);menu.style.left=`${Math.max(8,Math.min(x,window.innerWidth-menu.offsetWidth-8))}px`;menu.style.top=`${Math.max(8,Math.min(y,window.innerHeight-menu.offsetHeight-8))}px`;menu.querySelector('button').focus();}
  document.addEventListener('pointerdown',e=>{if(!e.target.closest('.live-context-menu'))closeLiveContextMenu();});
  document.addEventListener('keydown',e=>{if(e.key==='Escape')closeLiveContextMenu();if(state.view!=='live'||e.target.closest('input,select,textarea,[contenteditable],.modal'))return;if(e.key==='Escape'&&state.focusRestore){focusLiveSlot(state.selectedSlot);return;}if(e.key==='ArrowRight'){e.preventDefault();$('#page-next')?.click();}if(e.key==='ArrowLeft'){e.preventDefault();$('#page-prev')?.click();}if(['1','2','3','4'].includes(e.key)){state.gridCols=Number(e.key);state.livePage=0;state.focusRestore=null;renderLive();}if(e.ctrlKey&&e.key.toLowerCase()==='s'){e.preventDefault();saveWorkspace();showToast('Раскладка сохранена');}});
  function renderLiveInspector() {
    ptzCleanup?.();ptzCleanup=null;
    const root=$('#camera-inspector'),s=selectedLiveSlot(),c=camById(s?.camId);if(!root)return;
    root.innerHTML=`<div class="inspector-heading"><b>Активная камера</b>${icon('camera')}</div>${c?`<div class="inspector-details"><h2>${esc(c.name)}</h2><dl><dt>Адрес</dt><dd>${esc(c.ip)}</dd><dt>Протокол</dt><dd>${esc(protocolLabel(c))}</dd><dt>Поток</dt><dd>${c.protocol!=='dvrip'?'Настроенный RTSP':s.stream==='main'?'Основной (HD)':'Дополнительный (SD)'}</dd>${c.protocol==='dvrip'?`<dt>Канал</dt><dd>${Number(c.channel||0)+1}</dd>`:''}</dl><button class="btn btn-sm" id="inspector-snapshot">${icon('camera')} Снимок</button>${IS_ADMIN?`<button class="btn btn-sm" id="inspector-settings">${icon('sliders')} Настройки устройства</button>`:''}<div class="inspector-ptz" id="live-ptz"><button class="btn btn-sm" id="load-ptz">${icon('route')} Подключить PTZ</button><p>Доступно для совместимых ONVIF-камер.</p></div></div>`:'<div class="tree-empty">Выберите ячейку видеостены</div>'}`;
    $('#inspector-snapshot')?.addEventListener('click',snapshotSelected);
    $('#inspector-settings')?.addEventListener('click',()=>{state.deviceCamId=c.id;activateView('devices');});
    $('#load-ptz')?.addEventListener('click',()=>{if(window.VMSDevices)ptzCleanup=window.VMSDevices.mountPTZ($('#live-ptz'),c,{isAdmin:IS_ADMIN,onError:m=>showToast(m,'error'),onSuccess:m=>showToast(m)});});
  }
  function focusLiveSlot(uid) {
    const index=state.liveSlots.findIndex(s=>s.uid===uid);if(index<0)return;
    if(state.focusRestore){state.gridCols=state.focusRestore.cols;state.livePage=state.focusRestore.page;state.focusRestore=null;}
    else{state.focusRestore={cols:state.gridCols,page:state.livePage};state.gridCols=1;state.livePage=index;}
    state.selectedSlot=uid;renderLive();
  }
  function snapshotSelected() {
    const slot=selectedLiveSlot(),v=slot&&$(`#live-video-${slot.uid}`);if(!v?.videoWidth)return showToast('Дождитесь изображения с камеры','warning');
    const canvas=document.createElement('canvas');canvas.width=v.videoWidth;canvas.height=v.videoHeight;canvas.getContext('2d').drawImage(v,0,0);
    canvas.toBlob(blob=>{if(!blob)return;const url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=`camera-${slot.camId}-${Date.now()}.jpg`;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);},'image/jpeg',0.94);
  }
  function openSelectedArchive() {const cam=camById(selectedLiveSlot()?.camId);if(cam?.protocol==='dvrip'){state.archive.camId=cam.id;activateView('archive');}}
  function updateConsoleClock() { const el=$('#console-clock');if(el)el.textContent=new Date().toLocaleString('ru-RU'); }
  setInterval(updateConsoleClock,1000);
  function updateStreamSummary() {
    const el=$('#stream-summary');if(!el)return;
    const states=$$('.stream-state');el.textContent=`Видео: ${states.filter(s=>s.dataset.status==='playing').length} / ${states.length} · Ячеек: ${state.gridCols**2}`;
  }
  function destroyLivePlayer(uid) {
    const item=state.liveHls.get(uid);try{item?.hls?.destroy();}catch(_){}state.liveHls.delete(uid);
    const v=$(`#live-video-${uid}`);if(v){v.pause();v.removeAttribute('src');v.load();}
  }
  function attachLivePlayer(slot) {
    const video=$(`#live-video-${slot.uid}`),overlay=$(`#live-overlay-${slot.uid}`),badge=$(`#stream-state-${slot.uid}`);if(!video||!camById(slot.camId)||state.liveHls.has(slot.uid))return;
    const setStatus=(status,text)=>{if(badge){badge.dataset.status=status;badge.textContent=text;}updateStreamSummary();};
    const showError=msg=>{setStatus('error','Нет связи');if(overlay){overlay.classList.remove('hidden');overlay.innerHTML=`${icon('alert')}<span class="overlay-title">Нет видеосигнала</span><span class="overlay-msg">${esc(msg||'Проверьте устройство и настройки подключения.')}</span><button class="btn btn-sm stream-retry">${icon('refresh')} Повторить</button>`;overlay.querySelector('button').onclick=e=>{e.stopPropagation();destroyLivePlayer(slot.uid);attachLivePlayer(slot);};}};
    overlay?.classList.remove('hidden');if(overlay)overlay.innerHTML='<div class="spin"></div><span class="overlay-title">Подключение</span>';
    setStatus('connecting','Соединение');
    const url=`/live/${encodeURIComponent(slot.camId)}/${slot.stream}/index.m3u8`;
    video.onplaying=()=>{overlay?.classList.add('hidden');setStatus('playing','LIVE');};video.onerror=()=>showError('Не удалось воспроизвести поток');
    if(window.Hls&&window.Hls.isSupported()){
      const hls=new Hls({liveSyncDurationCount:3,lowLatencyMode:true,enableWorker:true});state.liveHls.set(slot.uid,{hls,camId:slot.camId,stream:slot.stream});
      hls.on(Hls.Events.MANIFEST_PARSED,()=>video.play().catch(()=>showError('Нажмите «Повторить», чтобы запустить видео')));
      hls.on(Hls.Events.ERROR,(_ev,data)=>{if(data.fatal){showError('Поток недоступен. Проверьте RTSP и FFmpeg.');hls.destroy();state.liveHls.delete(slot.uid);}});
      hls.loadSource(url);hls.attachMedia(video);
    }else if(video.canPlayType('application/vnd.apple.mpegurl')){state.liveHls.set(slot.uid,{camId:slot.camId,stream:slot.stream});video.src=url;video.play().catch(()=>showError('Запуск видео заблокирован браузером'));}
    else showError('Браузер не поддерживает HLS');
  }
  function stopAllLivePlayers() {
    ptzCleanup?.();ptzCleanup=null;
    for(const uid of [...state.liveHls.keys()])destroyLivePlayer(uid);
    // The backend owns shared FFmpeg workers; a layout change must not stop other viewers.
  }
  function addLiveSlot(){const c=state.cameras.find(c=>!state.liveSlots.some(s=>s.camId===c.id))||state.cameras[0];if(c)placeLiveCamera(c.id);else if(IS_ADMIN)openCameraModal();}
  function changeLiveCamera(uid,camId){placeLiveCamera(camId,Number(uid));}
  function changeLiveStream(uid,stream){const s=state.liveSlots.find(s=>s.uid===Number(uid));if(s){s.stream=stream;renderLive();}}
  function removeLiveSlot(uid){state.liveSlots=state.liveSlots.map(s=>s.uid===Number(uid)?{...s,camId:null}:s);while(state.liveSlots.length&&!state.liveSlots.at(-1).camId)state.liveSlots.pop();renderLive();}

  // Archive owns its request, player and timeline lifecycle as one workspace.
  function renderArchive() {
    archivePageCleanup?.();
    archivePageCleanup=window.VMSArchive.mount({root:$('#main-content'),cameras:state.cameras,selectedId:state.archive.camId,api,onSelect:id=>state.archive.camId=id,onError:m=>showToast(m,'error'),onSuccess:m=>showToast(m)});
  }

  function renderCameras() {
    const filtered=state.cameras.filter(c=>`${c.name} ${c.ip} ${c.protocol}`.toLowerCase().includes(state.cameraSearch.toLowerCase()));
    const actions=`<button class="btn btn-primary" id="camera-add">${icon('plus')} Добавить камеру</button>`;
    const cards=filtered.map(c=>`<article class="entity-card"><div class="entity-card-head"><div class="entity-icon">${icon(c.protocol==='dvrip'?'server':'camera')}</div><div style="min-width:0;flex:1"><div class="entity-title">${esc(c.name)}</div><div class="entity-description">${esc(c.ip)}${c.protocol==='dvrip'?` · канал ${Number(c.channel||0)+1}`:''}</div></div><span class="badge ${c.protocol==='dvrip'?'blue':''}">${esc(protocolLabel(c))}</span></div><div class="entity-meta"><span class="badge">${icon('link')} ${c.protocol==='dvrip'?'DVRIP : '+esc(c.port||34567):'RTSP : '+esc(c.rtsp_port||554)}</span><span class="badge">${esc(c.username||'Без логина')}</span></div><div class="entity-actions"><button class="btn btn-sm camera-edit" data-id="${esc(c.id)}">${icon('edit')} Изменить</button><button class="btn btn-sm btn-danger camera-delete" data-id="${esc(c.id)}">${icon('trash')} Удалить</button></div></article>`).join('');
    $('#main-content').innerHTML=pageHeader('Камеры','Добавляйте регистраторы DVRIP и IP-камеры с RTSP-потоками.',actions)+`<div class="toolbar"><div class="toolbar-left"><div class="search-wrap">${icon('search')}<input class="field" id="camera-search" placeholder="Поиск по названию, IP или протоколу" value="${esc(state.cameraSearch)}"></div></div><div class="toolbar-right"><span class="small-muted">${filtered.length} из ${state.cameras.length} устройств</span></div></div>${cards?`<div class="camera-list-grid">${cards}</div>`:emptyState(state.cameras.length?'Ничего не найдено':'Пока нет камер',state.cameras.length?'Измените поисковый запрос.':'Добавьте регистратор или IP-камеру, чтобы начать просмотр.',`<button class="btn btn-primary" id="camera-add-empty">${icon('plus')} Добавить камеру</button>`)}`;
    $('#camera-add')?.addEventListener('click',()=>openCameraModal());$('#camera-add-empty')?.addEventListener('click',()=>openCameraModal());
    $('#camera-search')?.addEventListener('input',e=>{state.cameraSearch=e.target.value;const pos=e.target.selectionStart;renderCameras();const input=$('#camera-search');input?.focus();input?.setSelectionRange(pos,pos);});
    $$('.camera-edit').forEach(btn=>btn.addEventListener('click',()=>openCameraModal(camById(btn.dataset.id))));
    $$('.camera-delete').forEach(btn=>btn.addEventListener('click',()=>deleteCamera(btn.dataset.id)));
  }
  function openCameraModal(camera=null) {
    if(!IS_ADMIN)return;
    const c=camera?{...camera,password:''}:{id:'',name:'',protocol:'dvrip',ip:'',port:34567,rtsp_port:554,channel:0,rtsp_path:'',username:'admin',password:''};
    const isEdit=Boolean(c.id);
    let availableOnvifProfiles=[];
    const protocolFields=()=>c.protocol==='dvrip'?`<div class="form-row"><div class="form-field"><label for="cam-port">Порт DVRIP</label><input class="field" type="number" min="1" max="65535" id="cam-port" name="port" value="${esc(c.port||34567)}" required></div><div class="form-field"><label for="cam-rtsp-port">Порт RTSP</label><input class="field" type="number" min="1" max="65535" id="cam-rtsp-port" name="rtsp_port" value="${esc(c.rtsp_port||554)}" required></div></div><div class="form-field"><label for="cam-channel">Канал регистратора</label><select class="select" name="channel" id="cam-channel">${Array.from({length:64},(_,i)=>`<option value="${i}" ${Number(c.channel||0)===i?'selected':''}>Канал ${i+1}</option>`).join('')}</select><span class="help">Для DVRIP канал вводится в API с нумерацией от 0; в интерфейсе показывается привычный номер от 1.</span></div>`:`<div class="form-row"><div class="form-field"><label for="cam-port">Порт ONVIF / веб-службы</label><input class="field" type="number" min="1" max="65535" id="cam-port" name="port" value="${esc(c.port||80)}"></div><div class="form-field"><label for="cam-rtsp-port">Порт RTSP</label><input class="field" type="number" min="1" max="65535" id="cam-rtsp-port" name="rtsp_port" value="${esc(c.rtsp_port||554)}" required></div></div><div class="form-field"><label for="cam-rtsp-path">RTSP path</label><input class="field" id="cam-rtsp-path" name="rtsp_path" value="${esc(c.rtsp_path||'')}" placeholder="/Streaming/Channels/101"><span class="help">Можно ввести путь вручную либо запросить доступные профили через ONVIF у совместимой камеры.</span></div><div class="form-field"><div class="page-actions"><button type="button" class="btn" id="cam-get-profiles">${icon('search')} Получить профили ONVIF</button></div><div id="cam-profile-status" class="small-muted">Для получения профилей укажите IP, порт ONVIF и учётные данные.</div><div id="cam-profile-select-wrap" class="form-field hidden"><label for="cam-onvif-profile">Профиль видеопотока</label><select id="cam-onvif-profile" class="select"></select></div></div>`;
    $('#modal-root').innerHTML=`<div class="modal-backdrop" data-backdrop><section class="modal" role="dialog" aria-modal="true" aria-labelledby="camera-modal-title"><div class="modal-head"><div><h2 id="camera-modal-title">${isEdit?'Настройки камеры':'Добавить камеру'}</h2><p>${isEdit?'Измените параметры подключения.':'Добавьте регистратор или IP-камеру в систему.'}</p></div><button class="icon-btn btn-icon" data-close aria-label="Закрыть">${icon('close')}</button></div><form id="camera-form"><div class="modal-body form-stack"><div class="form-row"><div class="form-field"><label for="cam-name">Название камеры *</label><input class="field" id="cam-name" name="name" value="${esc(c.name)}" required maxlength="100" placeholder="Например, Вход / Склад"></div><div class="form-field"><label for="cam-protocol">Тип устройства *</label><select class="select" id="cam-protocol" name="protocol"><option value="dvrip" ${c.protocol==='dvrip'?'selected':''}>Видеорегистратор / коаксиал (DVRIP)</option><option value="onvif" ${c.protocol!=='dvrip'?'selected':''}>IP-камера (RTSP / ONVIF)</option></select></div></div><div class="form-field"><label for="cam-ip">IP-адрес или имя узла *</label><input class="field" id="cam-ip" name="ip" value="${esc(c.ip)}" required placeholder="172.17.6.50"></div><div id="camera-protocol-fields">${protocolFields()}</div><div class="form-row"><div class="form-field"><label for="cam-username">Имя пользователя</label><input class="field" id="cam-username" name="username" value="${esc(c.username||'admin')}" autocomplete="off"></div><div class="form-field"><label for="cam-password">Пароль устройства</label><input class="field" id="cam-password" name="password" type="password" value="" autocomplete="new-password" placeholder="${isEdit?'Пусто — оставить прежний пароль':'Пароль устройства'}"><span class="help">Пароль шифруется перед сохранением на сервере.</span></div></div><div id="camera-test-result" class="hidden"></div></div><div class="modal-foot"><button type="button" class="btn" id="camera-test">${icon('link')} Проверить соединение</button><div class="modal-foot-right"><button type="button" class="btn" data-close>Отмена</button><button type="submit" class="btn btn-primary">${icon('check')} Сохранить</button></div></div></form></section></div>`;
    const protocol=$('#cam-protocol');
    const bindOnvifProfilePicker=()=>{
      const queryButton=$('#cam-get-profiles');if(!queryButton)return;
      queryButton.addEventListener('click',async()=>{
        const data=formObject($('#camera-form'));data.id=c.id||'';data.protocol='onvif';data.port=Number(data.port||80);
        const status=$('#cam-profile-status');const selectWrap=$('#cam-profile-select-wrap');
        status.textContent='Подключаемся к ONVIF-службе и запрашиваем профили…';queryButton.disabled=true;
        try{
          const result=await api('/api/onvif/profiles',{method:'POST',body:data});availableOnvifProfiles=result.profiles||[];
          if(!availableOnvifProfiles.length){status.textContent='Камера ответила, но профили видеопотока не найдены.';selectWrap.classList.add('hidden');return;}
          const select=$('#cam-onvif-profile');select.innerHTML=availableOnvifProfiles.map((p,i)=>`<option value="${i}">${esc(p.name||p.token||`Профиль ${i+1}`)}${p.uri?` — ${esc(p.uri)}`:''}</option>`).join('');
          selectWrap.classList.remove('hidden');status.textContent=`Найдено профилей: ${availableOnvifProfiles.length}. Выбор заполнит RTSP-порт и путь.`;
          select.dispatchEvent(new Event('change'));
        }catch(err){status.textContent='Ошибка ONVIF: '+err.message;showToast(err.message,'error');}
        finally{queryButton.disabled=false;}
      });
      $('#cam-onvif-profile')?.addEventListener('change',e=>{const p=availableOnvifProfiles[Number(e.target.value)];if(!p)return;const port=$('#cam-rtsp-port');const path=$('#cam-rtsp-path');if(port&&p.rtsp_port)port.value=p.rtsp_port;if(path&&p.rtsp_path)path.value=p.rtsp_path;});
    };
    protocol.addEventListener('change',()=>{c.protocol=protocol.value;$('#camera-protocol-fields').innerHTML=protocolFields();bindOnvifProfilePicker();});
    bindOnvifProfilePicker();
    $('#camera-form').addEventListener('submit',async e=>{e.preventDefault();const data=formObject(e.target);data.id=c.id||'';data.protocol=protocol.value;data.port=Number(data.port|| (data.protocol==='dvrip'?34567:80));data.rtsp_port=Number(data.rtsp_port||554);if(data.protocol==='dvrip')data.channel=Number(data.channel||0);else data.rtsp_path=data.rtsp_path||'';const btn=e.target.querySelector('button[type="submit"]');btn.disabled=true;try{await api('/api/cameras',{method:'POST',body:data});closeModal();await loadData();activateView('cameras');showToast(isEdit?'Камера обновлена':'Камера добавлена');}catch(err){showToast(err.message,'error');}finally{btn.disabled=false;}});
    $('#camera-test').addEventListener('click',async()=>{const data=formObject($('#camera-form'));data.id=c.id||'';data.protocol=protocol.value;data.port=Number(data.port||(data.protocol==='dvrip'?34567:80));data.rtsp_port=Number(data.rtsp_port||554);if(data.protocol==='dvrip')data.channel=Number(data.channel||0);const box=$('#camera-test-result');box.className='notice';box.textContent='Проверяем соединение…';try{const result=await api('/api/cameras/test',{method:'POST',body:data});box.className=result.ok?'notice':'form-alert';box.innerHTML=result.ok?`${icon('check')} Соединение успешно.`:`${icon('alert')} ${esc(result.error||'Проверка не прошла')}`;}catch(err){box.className='form-alert';box.textContent=err.message;}});
    bindModalClose();$('#cam-name').focus();
  }
  function formObject(form) { const data={};new FormData(form).forEach((value,key)=>{data[key]=value;});return data; }
  async function deleteCamera(id) {const cam=camById(id);if(!cam||!confirm(`Удалить камеру «${cam.name}»? Она также будет удалена из групп.`))return;try{await api(`/api/cameras/${encodeURIComponent(id)}`,{method:'DELETE'});state.liveSlots=state.liveSlots.filter(s=>s.camId!==id);await loadData();renderCameras();showToast('Камера удалена');}catch(e){showToast(e.message,'error');}}

  // GROUPS
  function renderGroups() {
    const cards=state.groups.map(g=>{const cams=(g.camera_ids||[]).map(id=>camById(id)).filter(Boolean);return `<article class="entity-card"><div class="entity-card-head"><div class="entity-icon">${icon('folder')}</div><div style="min-width:0;flex:1"><div class="entity-title">${esc(g.name)}</div><div class="entity-description">${cams.length} ${cams.length===1?'камера':'камер'} в группе</div></div><span class="badge">${cams.length}</span></div><div class="entity-meta">${cams.length?cams.slice(0,5).map(c=>`<span class="badge">${esc(c.name)}</span>`).join('')+(cams.length>5?`<span class="badge">+${cams.length-5}</span>`:''):'<span class="small-muted">В группу пока не добавлены камеры</span>'}</div><div class="entity-actions"><button class="btn btn-sm group-watch" data-id="${esc(g.id)}">${icon('eye')} Смотреть</button><button class="btn btn-sm group-edit" data-id="${esc(g.id)}">${icon('edit')} Изменить</button><button class="btn btn-sm btn-danger group-delete" data-id="${esc(g.id)}">${icon('trash')} Удалить</button></div></article>`;}).join('');
    $('#main-content').innerHTML=pageHeader('Группы камер','Объединяйте камеры по объектам или отделам, чтобы быстро открывать нужный набор.',`<button class="btn btn-primary" id="group-add">${icon('plus')} Создать группу</button>`)+(cards?`<div class="group-grid">${cards}</div>`:emptyState('Нет групп','Создайте группу и выберите камеры, которые должны в неё входить.',`<button class="btn btn-primary" id="group-add-empty">${icon('plus')} Создать группу</button>`));
    $('#group-add')?.addEventListener('click',()=>openGroupModal());$('#group-add-empty')?.addEventListener('click',()=>openGroupModal());
    $$('.group-edit').forEach(b=>b.addEventListener('click',()=>openGroupModal(groupById(b.dataset.id))));
    $$('.group-watch').forEach(b=>b.addEventListener('click',()=>{const g=groupById(b.dataset.id);if(!g)return;state.selectedGroup=g.id;state.liveSlots=(g.camera_ids||[]).filter(id=>camById(id)).map(id=>({uid:++state.slotCounter,camId:id,stream:'sub'}));activateView('live');}));
    $$('.group-delete').forEach(b=>b.addEventListener('click',()=>deleteGroup(b.dataset.id)));
  }
  function openGroupModal(group=null) {
    const g=group?{...group,camera_ids:[...(group.camera_ids||[])]}:{id:'',name:'',camera_ids:[]};const selected=new Set(g.camera_ids);
    $('#modal-root').innerHTML=`<div class="modal-backdrop" data-backdrop><section class="modal modal-sm" role="dialog" aria-modal="true"><div class="modal-head"><div><h2>${g.id?'Редактирование группы':'Новая группа'}</h2><p>Укажите название и выберите камеры.</p></div><button class="icon-btn btn-icon" data-close>${icon('close')}</button></div><form id="group-form"><div class="modal-body form-stack"><div class="form-field"><label for="group-name">Название группы *</label><input class="field" id="group-name" name="name" required maxlength="100" value="${esc(g.name)}" placeholder="Например, Периметр"></div><div class="form-field"><label>Камеры в группе</label><div class="checkbox-list">${state.cameras.length?state.cameras.map(c=>`<label class="check-row"><input type="checkbox" name="camera_ids" value="${esc(c.id)}" ${selected.has(c.id)?'checked':''}><span><b>${esc(c.name)}</b><small>${esc(c.ip)}</small></span></label>`).join(''):'<div class="empty-inline">Сначала добавьте камеры.</div>'}</div></div></div><div class="modal-foot"><span></span><div class="modal-foot-right"><button type="button" class="btn" data-close>Отмена</button><button class="btn btn-primary" type="submit">${icon('check')} Сохранить</button></div></div></form></section></div>`;
    $('#group-form').addEventListener('submit',async e=>{e.preventDefault();const camera_ids=$$('[name="camera_ids"]:checked',e.target).map(x=>x.value);try{await api('/api/groups',{method:'POST',body:{id:g.id||'',name:$('#group-name').value.trim(),camera_ids}});closeModal();await loadData();renderGroups();showToast(g.id?'Группа обновлена':'Группа создана');}catch(err){showToast(err.message,'error');}});bindModalClose();$('#group-name').focus();
  }
  async function deleteGroup(id){const g=groupById(id);if(!g||!confirm(`Удалить группу «${g.name}»? Камеры останутся в системе.`))return;try{await api(`/api/groups/${encodeURIComponent(id)}`,{method:'DELETE'});await loadData();renderGroups();showToast('Группа удалена');}catch(e){showToast(e.message,'error');}}

  // USERS
  function renderUsers() {
    const filtered=state.users.filter(u=>`${u.username} ${u.role}`.toLowerCase().includes(state.userSearch.toLowerCase()));
    const rows=filtered.map(u=>`<tr><td><div style="display:flex;align-items:center;gap:9px"><span class="avatar">${esc(u.username.slice(0,1).toUpperCase())}</span><div><div class="cell-main">${esc(u.username)}</div><div class="cell-sub">Тема: ${esc(u.theme||'auto')}</div></div></div></td><td><span class="badge ${u.role==='admin'?'blue':'green'}">${u.role==='admin'?'Администратор':'Только просмотр'}</span></td><td><span class="small-muted">${u.username===USER.username?'Текущая учётная запись':'—'}</span></td><td><div class="table-actions"><button class="btn btn-sm user-edit" data-user="${esc(u.username)}">${icon('edit')} Изменить</button>${u.username!==USER.username?`<button class="btn btn-sm btn-danger user-delete" data-user="${esc(u.username)}">${icon('trash')}</button>`:''}</div></td></tr>`).join('');
    $('#main-content').innerHTML=pageHeader('Пользователи','Управление учётными записями и уровнем доступа.',`<button class="btn btn-primary" id="user-add">${icon('plus')} Создать пользователя</button>`)+`<div class="toolbar"><div class="toolbar-left"><div class="search-wrap">${icon('search')}<input class="field" id="user-search" placeholder="Найти пользователя" value="${esc(state.userSearch)}"></div></div><div class="toolbar-right"><span class="small-muted">Всего пользователей: ${state.users.length}</span></div></div><section class="panel"><div class="table-wrap"><table class="data-table"><thead><tr><th>Учётная запись</th><th>Роль</th><th>Состояние</th><th style="text-align:right">Действия</th></tr></thead><tbody>${rows||`<tr><td colspan="4"><div class="empty-inline">Пользователи не найдены.</div></td></tr>`}</tbody></table></div></section><div class="notice" style="margin-top:14px">${icon('shield')} Администратор может управлять устройствами, камерами, группами и учётными записями. Роль «Только просмотр» предназначена для просмотра камер и архива.</div>`;
    $('#user-add')?.addEventListener('click',()=>openUserModal());$('#user-search')?.addEventListener('input',e=>{state.userSearch=e.target.value;const pos=e.target.selectionStart;renderUsers();const el=$('#user-search');el?.focus();el?.setSelectionRange(pos,pos);});
    $$('.user-edit').forEach(b=>b.addEventListener('click',()=>openUserModal(state.users.find(u=>u.username===b.dataset.user))));
    $$('.user-delete').forEach(b=>b.addEventListener('click',()=>deleteUser(b.dataset.user)));
  }
  function openUserModal(user=null) {
    const u=user?{...user,password:''}:{username:'',role:'viewer',password:''};const edit=!!user;
    $('#modal-root').innerHTML=`<div class="modal-backdrop" data-backdrop><section class="modal modal-sm" role="dialog" aria-modal="true"><div class="modal-head"><div><h2>${edit?'Изменить пользователя':'Создать пользователя'}</h2><p>${edit?'Можно изменить роль и сбросить пароль.':'Создайте новую учётную запись.'}</p></div><button class="icon-btn btn-icon" data-close>${icon('close')}</button></div><form id="user-form"><div class="modal-body form-stack"><div class="form-field"><label for="user-form-name">Имя пользователя *</label><input class="field" id="user-form-name" name="username" value="${esc(u.username)}" ${edit?'readonly':''} required minlength="2" maxlength="64" autocomplete="off"></div><div class="form-field"><label for="user-form-role">Уровень доступа</label><select class="select" id="user-form-role" name="role"><option value="viewer" ${u.role==='viewer'?'selected':''}>Пользователь — только просмотр</option><option value="admin" ${u.role==='admin'?'selected':''}>Администратор — полный доступ</option></select></div><div class="form-field"><label for="user-form-password">${edit?'Новый пароль':'Пароль *'}</label><input class="field" id="user-form-password" name="password" type="password" ${edit?'':'required'} minlength="6" autocomplete="new-password" placeholder="${edit?'Оставьте пустым, чтобы не менять':'Не менее 6 символов'}"><span class="help">Пароль не отображается после сохранения.</span></div></div><div class="modal-foot"><span></span><div class="modal-foot-right"><button type="button" class="btn" data-close>Отмена</button><button type="submit" class="btn btn-primary">${icon('check')} Сохранить</button></div></div></form></section></div>`;
    $('#user-form').addEventListener('submit',async e=>{e.preventDefault();const data=formObject(e.target);try{if(edit){delete data.username;await api(`/api/users/${encodeURIComponent(u.username)}`,{method:'PUT',body:data});}else await api('/api/users',{method:'POST',body:data});closeModal();await loadData();renderUsers();showToast(edit?'Пользователь обновлён':'Пользователь создан');}catch(err){showToast(err.message,'error');}});bindModalClose();$('#user-form-name').focus();
  }
  async function deleteUser(username){if(username===USER.username)return showToast('Нельзя удалить собственную учётную запись из текущего сеанса.','warning');if(!confirm(`Удалить пользователя «${username}»?`))return;try{await api(`/api/users/${encodeURIComponent(username)}`,{method:'DELETE'});await loadData();renderUsers();showToast('Пользователь удалён');}catch(e){showToast(e.message,'error');}}

  // DEVICE ADMINISTRATION — only generic information is exposed by the existing DVRIP backend.
  function renderDevices() {
    if(window.VMSDevices){devicePageCleanup?.();devicePageCleanup=window.VMSDevices.render({root:$('#main-content'),cameras:state.cameras,selectedId:state.deviceCamId,isAdmin:IS_ADMIN,onSelect:id=>state.deviceCamId=id,onError:m=>showToast(m,'error'),onSuccess:m=>showToast(m)});return;}
    const devices=state.cameras;
    const options=devices.map(c=>`<option value="${esc(c.id)}" ${state.deviceCamId===c.id?'selected':''}>${esc(c.name)} · ${esc(c.ip)} · ${esc(protocolLabel(c))}</option>`).join('');
    const cam=camById(state.deviceCamId);const isOnvif=cam?.protocol==='onvif';
    const info=state.deviceInfo?.system_info?JSON.stringify(state.deviceInfo.system_info,null,2):'Нажмите «Запросить информацию», чтобы получить данные устройства.';
    const controls=isOnvif?`<div class="divider"></div><div class="form-field"><label for="device-hostname">Изменить сетевое имя (ONVIF)</label><div class="form-row"><input class="field" id="device-hostname" maxlength="63" placeholder="camera-lobby" value="${esc(state.deviceInfo?.system_info?.hostname||'')}"><button id="device-set-hostname" class="btn">${icon('check')} Применить</button></div><span class="help">Изменение поддерживается только устройствами, разрешающими ONVIF SetHostname. После применения это меняет сетевое имя, а не название карточки в Web VMS.</span></div>`:`<div class="notice">${icon('info')} Изменение параметров DVRIP-регистратора выполняется через его собственный веб-интерфейс; набор команд записи настроек у производителей различается.</div>`;
    $('#main-content').innerHTML=pageHeader('Устройства','Техническая информация, ONVIF-профили и доступные операции управления.')+(!devices.length?emptyState('Нет устройств','Добавьте камеру или регистратор, чтобы открыть их системную информацию.'): `<div class="content-grid"><section class="panel"><div class="panel-head"><div><h2 class="panel-title">Карточка устройства</h2><p class="panel-note">Запросы выполняются с правами администратора.</p></div><span class="badge blue">ADMIN</span></div><div class="panel-body form-stack"><div class="form-field"><label for="device-select">Устройство</label><select id="device-select" class="select">${options}</select></div><div class="entity-card" style="padding:13px"><div class="entity-card-head"><div class="entity-icon">${icon(isOnvif?'camera':'server')}</div><div style="min-width:0;flex:1"><div class="entity-title" id="device-card-name">${esc(cam?.name||'—')}</div><div class="entity-description" id="device-card-address">${esc(cam?.ip||'—')} · ${esc(protocolLabel(cam||{}))} · порт ${esc(cam?.port||80)}</div></div><span class="badge">${cam?'Добавлено':'—'}</span></div></div><div class="page-actions"><button class="btn btn-primary" id="device-query">${icon('refresh')} Запросить информацию</button>${cam?`<a class="btn" id="device-open" href="http://${esc(cam.ip)}" target="_blank" rel="noopener noreferrer">${icon('link')} Веб-интерфейс устройства</a>`:''}</div>${controls}</div></section><section class="panel"><div class="panel-head"><div><h2 class="panel-title">Системная информация</h2><p class="panel-note">Ответ регистратора или ONVIF-устройства.</p></div><span class="badge ${state.deviceInfo?.success?'green':''}" id="device-info-state">${state.deviceInfo?.success?'Получено':'Не запрашивалась'}</span></div><div class="panel-body"><pre class="device-info-pre" id="device-info-output">${esc(info)}</pre></div></section></div>`);
    $('#device-select')?.addEventListener('change',e=>{state.deviceCamId=e.target.value;state.deviceInfo=null;renderDevices();});
    $('#device-query')?.addEventListener('click',loadDeviceInfo);
    $('#device-set-hostname')?.addEventListener('click',setDeviceHostname);
  }
  async function loadDeviceInfo() {
    const cam=camById(state.deviceCamId);if(!cam)return showToast('Выберите устройство.','warning');
    const output=$('#device-info-output');const badge=$('#device-info-state');if(output)output.textContent='Запрос выполняется…';if(badge)badge.textContent='Подключение…';
    try{const result=await api('/api/device/info',{method:'POST',body:{cam_id:cam.id}});state.deviceInfo=result;if(output)output.textContent=JSON.stringify(result.system_info??result,null,2);if(badge){badge.textContent=result.success?'Получено':'Ошибка';badge.className=`badge ${result.success?'green':'red'}`;}const name=$('#device-hostname');if(name&&result.system_info?.hostname)name.value=result.system_info.hostname;showToast('Информация устройства получена');}
    catch(e){state.deviceInfo=null;if(output)output.textContent=JSON.stringify({error:e.message},null,2);if(badge){badge.textContent='Ошибка подключения';badge.className='badge red';}showToast(e.message,'error');}
  }
  async function setDeviceHostname() {
    const cam=camById(state.deviceCamId);const hostname=$('#device-hostname')?.value.trim();if(!cam||!hostname)return showToast('Укажите новое имя устройства.','warning');
    if(!confirm(`Изменить сетевое имя устройства ${cam.ip} на «${hostname}»?`))return;
    try{await api('/api/device/hostname',{method:'POST',body:{cam_id:cam.id,hostname}});showToast('Имя устройства изменено.');await loadDeviceInfo();}
    catch(e){showToast(e.message,'error');}
  }

  function bindModalClose() {
    $$('[data-close]').forEach(btn=>btn.addEventListener('click',closeModal));
    $('[data-backdrop]')?.addEventListener('click',e=>{if(e.target.matches('[data-backdrop]'))closeModal();});
  }
  function closeModal() { $('#modal-root').innerHTML=''; }

  document.addEventListener('DOMContentLoaded', init);
})();
