/* Capability-based ONVIF / DVRIP controls. No device changes occur during rendering. */
(() => {
  'use strict';
  const escape = value => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const query = (root, selector) => root.querySelector(selector);
  const allowed = value => value === true || value?.supported === true;
  const icons = {
    camera:'<rect x="3" y="6" width="13" height="12" rx="2"/><path d="m16 10 5-3v10l-5-3"/>',
    refresh:'<path d="M20 7v5h-5M4 17v-5h5M5.6 9A7 7 0 0 1 18 6l2 6M4 12l2 6a7 7 0 0 0 12.4-3"/>',
    link:'<path d="M10 13a5 5 0 0 0 7.5.5l3-3a5 5 0 0 0-7-7L12 5m2 6a5 5 0 0 0-7.5-.5l-3 3a5 5 0 0 0 7 7L12 19"/>',
    info:'<circle cx="12" cy="12" r="9"/><path d="M12 11v6m0-10h.01"/>',
    save:'<path d="m5 12 4 4L19 6"/>',
    arrow:'<path d="m6 9 6 6 6-6"/>',
    power:'<path d="M12 2v10m-6-7a9 9 0 1 0 12 0"/>',
    target:'<circle cx="12" cy="12" r="7"/><path d="M12 1v6m0 10v6M1 12h6m10 0h6"/>',
    settings:'<path d="M4 4v16M12 4v16M20 4v16M1 8h6m2 8h6m2-6h6"/>'
  };
  const icon = name => `<svg viewBox="0 0 24 24" aria-hidden="true">${icons[name] || icons.info}</svg>`;
  const empty = message => `<div class="dc-empty">${icon('info')}<span>${escape(message)}</span></div>`;
  const loading = message => `<div class="dc-empty" role="status"><span class="dc-spinner"></span><span>${escape(message || 'Запрос к устройству…')}</span></div>`;
  const field = (label, content, hint = '') => `<label class="dc-field"><span>${escape(label)}</span>${content}${hint ? `<small>${escape(hint)}</small>` : ''}</label>`;
  const panel = (title, description, contents, extra = '') => `<section class="dc-panel ${extra}"><div class="dc-panel-head"><h2>${escape(title)}</h2>${description ? `<p>${escape(description)}</p>` : ''}</div><div class="dc-panel-body">${contents}</div></section>`;
  const safeWebURL = camera => {
    try {
      const host = String(camera?.ip || '').trim();
      if (!host || /[\s/@?#\\]/.test(host)) return '';
      const url = new URL(`http://${host.includes(':') && !host.startsWith('[') ? `[${host}]` : host}`);
      return url.protocol === 'http:' && !url.username && !url.password ? url.href : '';
    } catch (_) { return ''; }
  };
  async function request(path, body, signal) {
    const response = await fetch(path, {method:'POST', credentials:'same-origin', headers:{'Content-Type':'application/json','X-Requested-With':'XMLHttpRequest'}, body:JSON.stringify(body), signal});
    let data;
    try { data = await response.json(); } catch (_) { throw new Error(response.status === 401 ? 'Сеанс завершён. Войдите снова.' : `Не удалось прочитать ответ сервера (${response.status}).`); }
    if (!response.ok || data.success === false || data.error) throw new Error(data.error || `Ошибка устройства (${response.status}).`);
    return data;
  }
  function asText(value) {
    if (value === null || value === undefined || value === '') return '—';
    return typeof value === 'object' ? JSON.stringify(value, null, 2) : String(value);
  }
  function infoTable(data) {
    const names = {manufacturer:'Производитель',Manufacturer:'Производитель',model:'Модель',Model:'Модель',firmware_version:'Прошивка',FirmwareVersion:'Прошивка',serial_number:'Серийный номер',SerialNumber:'Серийный номер',hardware_id:'Оборудование',hostname:'Сетевое имя',protocol:'Протокол',ChannelNum:'Видеоканалы',DeviceType:'Тип устройства',SerialNo:'Серийный номер',SoftWareVersion:'Версия ПО',BuildTime:'Сборка'};
    if (!data || !Object.keys(data).length) return empty('Устройство не вернуло сведения.');
    return `<dl class="dc-info">${Object.entries(data).map(([key,value]) => `<div><dt>${escape(names[key] || key)}</dt><dd>${escape(asText(value))}</dd></div>`).join('')}</dl>`;
  }
  function numericInput(name, value, range, step = 1, unit = '') {
    const min = Number(range?.Min), max = Number(range?.Max);
    const bounds = `${Number.isFinite(min) ? ` min="${min}"` : ''}${Number.isFinite(max) ? ` max="${max}"` : ''}`;
    return `<span class="dc-input-unit"><input class="field" type="number" name="${name}" step="${step}"${bounds} value="${escape(value ?? '')}" required>${unit ? `<span>${escape(unit)}</span>` : ''}</span>`;
  }

  function createPTZ(root, camera, options = {}, capabilities = null) {
    let disposed = false, controller = new AbortController(), profile = '', movingProfile = '', stopLoop = 0, moving = false, moveBusy = false;
    let cap = capabilities;
    const notifyError = message => options.onError?.(message);
    const call = body => request('/api/device/ptz', {cam_id:camera.id,profile_token:profile,...body}, controller.signal);
    const stop = () => {
      clearInterval(stopLoop); stopLoop = 0;
      if (!moving) return;
      moving = false;
      request('/api/device/ptz', {cam_id:camera.id,profile_token:movingProfile || profile,action:'stop'}).catch(error => {if (!disposed) notifyError(error.message);});
      root.querySelectorAll('.dc-ptz-key.is-moving').forEach(button => button.classList.remove('is-moving'));
    };
    const stopOnHidden = () => {if (document.hidden) stop();};
    const start = (button, direction) => {
      stop(); moving = true; movingProfile = profile; const commandProfile = profile; button.classList.add('is-moving');
      const speed = Number(query(root, '[data-ptz-speed]')?.value || 0.4);
      const [pan, tilt, zoom] = direction.map(value => value * speed);
      const send = async () => {
        if (moveBusy || !moving || disposed) return;
        moveBusy = true;
        try { await call({profile_token:commandProfile,action:'move',pan,tilt,zoom}); }
        catch (error) {stop(); if (!disposed && error.name !== 'AbortError') notifyError(error.message);}
        finally {moveBusy = false; if (!moving || commandProfile !== profile) request('/api/device/ptz',{cam_id:camera.id,profile_token:commandProfile,action:'stop'}).catch(()=>{});}
      };
      send(); stopLoop = setInterval(send, 350);
    };
    const presets = async () => {
      const select = query(root, '[data-ptz-preset]');
      if (!select) return;
      select.disabled = true;
      try {
        const data = await call({action:'presets'});
        if (disposed) return;
        const list = data.presets || [];
        select.innerHTML = `<option value="">${list.length ? 'Выберите позицию' : 'Нет сохранённых позиций'}</option>` + list.map(item => `<option value="${escape(item.token ?? item.PresetToken)}">${escape(item.name || item.Name || item.token || 'Позиция')}</option>`).join('');
        select.disabled = !list.length;
      } catch (error) {
        if (disposed) return;
        select.innerHTML = '<option value="">Позиции недоступны</option>';
        query(root, '[data-preset-note]').textContent = error.message;
      }
    };
    const render = () => {
      if (disposed) return;
      const profiles = (cap?.profiles || []).filter(item => item.ptz !== false);
      if (!allowed(cap?.capabilities?.ptz) || !profiles.length) {
        root.innerHTML = empty(camera.protocol === 'dvrip' ? 'Управление PTZ этого регистратора доступно в ПО производителя.' : 'Камера не сообщила о поддержке PTZ через ONVIF.'); return;
      }
      profile = profiles.some(item => item.token === profile) ? profile : profiles[0].token;
      const keys = [[-1,1,0,'↖','Влево и вверх'],[0,1,0,'↑','Вверх'],[1,1,0,'↗','Вправо и вверх'],[-1,0,0,'←','Влево'],[0,0,0,'■','Остановить'],[1,0,0,'→','Вправо'],[-1,-1,0,'↙','Влево и вниз'],[0,-1,0,'↓','Вниз'],[1,-1,0,'↘','Вправо и вниз']];
      root.innerHTML = `<div class="dc-ptz"><div class="dc-ptz-caption"><b>Поворот и масштаб</b><span class="badge blue">ONVIF PTZ</span></div>${profiles.length > 1 ? field('Профиль',`<select class="select" data-ptz-profile>${profiles.map(item => `<option value="${escape(item.token)}" ${item.token === profile ? 'selected' : ''}>${escape(item.name || item.token)}</option>`).join('')}</select>`) : ''}<div class="dc-ptz-controls"><div class="dc-ptz-pad">${keys.map(([pan,tilt,zoom,text,label]) => `<button class="dc-ptz-key" type="button" data-direction="${pan},${tilt},${zoom}" aria-label="${label}" title="${label}">${text}</button>`).join('')}</div><div class="dc-ptz-zoom"><button class="dc-ptz-key" data-direction="0,0,1" type="button" aria-label="Приблизить">+</button><span>ZOOM</span><button class="dc-ptz-key" data-direction="0,0,-1" type="button" aria-label="Отдалить">−</button></div></div>${field('Скорость', '<input type="range" data-ptz-speed min="0.1" max="1" step="0.1" value="0.4">')}<p class="dc-muted">Удерживайте кнопку для движения, отпустите для остановки.</p><div class="dc-divider"></div>${field('Сохранённая позиция','<select class="select" data-ptz-preset disabled><option>Загрузка позиций…</option></select>')}<div class="dc-action-row"><button class="btn btn-sm" type="button" data-preset-goto>Перейти</button><button class="btn btn-sm" type="button" data-preset-save>Сохранить</button><button class="btn btn-sm btn-danger" type="button" data-preset-delete>Удалить</button></div><p data-preset-note class="dc-muted" aria-live="polite"></p></div>`;
      root.querySelectorAll('[data-direction]').forEach(button => {
        const direction = button.dataset.direction.split(',').map(Number), isStop = direction.every(value => value === 0);
        button.addEventListener('pointerdown', event => {if(event.button !== 0) return; event.preventDefault(); if(isStop) {stop();call({action:'stop'}).catch(e=>notifyError(e.message));} else {button.setPointerCapture(event.pointerId);start(button,direction);}});
        button.addEventListener('pointerup',stop); button.addEventListener('pointercancel',stop); button.addEventListener('lostpointercapture',stop);
        button.addEventListener('keydown', event => {if(![' ','Enter'].includes(event.key) || event.repeat) return;event.preventDefault();if(isStop){stop();call({action:'stop'}).catch(e=>notifyError(e.message));}else start(button,direction);});
        button.addEventListener('keyup', event => {if([' ','Enter'].includes(event.key)){event.preventDefault();stop();}});
        button.addEventListener('blur',stop);
      });
      query(root,'[data-ptz-profile]')?.addEventListener('change', event => {stop();profile=event.target.value;presets();});
      query(root,'[data-preset-goto]').addEventListener('click', async () => {
        const token = query(root,'[data-ptz-preset]').value;if(!token)return;stop();
        try{await call({action:'goto',preset_token:token});}catch(error){notifyError(error.message);}
      });
      query(root,'[data-preset-save]').addEventListener('click', async () => {
        const name = window.prompt('Название новой позиции PTZ:');if(name === null || !name.trim())return;stop();
        try{await call({action:'save',name:name.trim()});options.onSuccess?.('Позиция PTZ сохранена');await presets();}catch(error){notifyError(error.message);}
      });
      query(root,'[data-preset-delete]').addEventListener('click', async () => {
        const select = query(root,'[data-ptz-preset]'), token = select.value;if(!token || !window.confirm(`Удалить позицию «${select.selectedOptions[0].textContent}»?`))return;stop();
        try{await call({action:'remove',preset_token:token});options.onSuccess?.('Позиция PTZ удалена');await presets();}catch(error){notifyError(error.message);}
      });
      presets();
    };
    window.addEventListener('pointerup',stop);window.addEventListener('blur',stop);document.addEventListener('visibilitychange',stopOnHidden);
    if (options.isAdmin === false) root.innerHTML = empty('Управление PTZ доступно администратору.');
    else if (cap) render();
    else {root.innerHTML = loading('Проверка PTZ…');request('/api/device/capabilities',{cam_id:camera.id},controller.signal).then(data=>{cap=data;render();}).catch(error=>{if(!disposed && error.name!=='AbortError')root.innerHTML=empty(error.message);});}
    return () => {disposed=true;stop();controller.abort();window.removeEventListener('pointerup',stop);window.removeEventListener('blur',stop);document.removeEventListener('visibilitychange',stopOnHidden);};
  }

  let cleanupPage = null;
  function render(options) {
    cleanupPage?.();
    const root = options.root;
    if (!root) return () => {};
    let selectedId = options.selectedId || options.cameras?.[0]?.id || '', version = 0, disposed = false, ptzCleanup = null, aborter = new AbortController();
    let camera = null, caps = null, selectedProfile = '', activeTab = 'info';
    const success = message => options.onSuccess?.(message);
    const fail = error => {if(error.name !== 'AbortError' && !disposed)options.onError?.(error.message || String(error));};
    const current = () => !disposed && root.isConnected;
    const call = (path, body = {}) => request(path,{cam_id:camera.id,...body},aborter.signal);
    const dispose = () => {disposed=true;aborter.abort();ptzCleanup?.();};
    cleanupPage = dispose;
    if (options.isAdmin === false) {root.innerHTML=empty('Управление устройствами доступно администратору.');return dispose;}
    const header = `<div class="dc-heading"><div><p class="dc-eyebrow">КОНФИГУРАЦИЯ СИСТЕМЫ</p><h1>Устройства</h1><p>Параметры камер и регистраторов, доступные через их протокол.</p></div><span class="dc-access">АДМИНИСТРАТОР</span></div>`;
    if (!options.cameras?.length) {root.innerHTML = `<div class="dc-page">${header}${empty('Добавьте камеру или регистратор в разделе «Камеры».')}</div>`;return dispose;}
    root.innerHTML = `<div class="dc-page">${header}<div class="dc-device-toolbar"><label class="dc-device-picker"><span>Устройство</span><select class="select" data-device-select>${options.cameras.map(cam=>`<option value="${escape(cam.id)}" ${cam.id===selectedId?'selected':''}>${escape(cam.name)} · ${escape(cam.ip)}</option>`).join('')}</select></label><button class="btn" data-device-refresh>${icon('refresh')} Обновить</button><a class="btn" data-device-web target="_blank" rel="noopener noreferrer">${icon('link')} Веб-интерфейс</a></div><div data-device-workspace></div></div>`;
    query(root,'[data-device-select]').addEventListener('change',event=>{selectedId=event.target.value;options.onSelect?.(selectedId);load();});
    query(root,'[data-device-refresh]').addEventListener('click',load);
    async function load() {
      const thisVersion = ++version;ptzCleanup?.();ptzCleanup=null;aborter.abort();aborter=new AbortController();caps=null;
      camera=options.cameras.find(item=>item.id===selectedId)||options.cameras[0];selectedId=camera.id;
      query(root,'[data-device-select]').value=selectedId;
      const web=query(root,'[data-device-web]'),href=safeWebURL(camera);web.hidden=!href;if(href)web.href=href;
      query(root,'[data-device-workspace]').innerHTML=loading('Проверка возможностей устройства…');
      try{const data=await call('/api/device/capabilities');if(!current()||thisVersion!==version)return;caps=data;selectedProfile=(data.profiles||[])[0]?.token||'';draw();}
      catch(error){if(!current()||thisVersion!==version||error.name==='AbortError')return;query(root,'[data-device-workspace]').innerHTML=panel('Устройство недоступно',`${camera.name} · ${camera.ip}`,`<div class="dc-error" role="alert">${escape(error.message)}</div><p class="dc-muted">Проверьте адрес, порт службы и учётные данные в разделе «Камеры», затем нажмите «Обновить».</p>`);fail(error);}
    }
    function draw() {
      const cap=caps.capabilities||{};
      const tabs=[['info','Система',true],['encoder','Видеопоток',allowed(cap.encoder)],['imaging','Изображение',allowed(cap.imaging)],['ptz','PTZ и позиции',allowed(cap.ptz)]];
      if(!tabs.some(([id,,available])=>id===activeTab&&available))activeTab='info';
      const unsupported=tabs.filter(([, ,available])=>!available).map(([,label])=>label);
      query(root,'[data-device-workspace]').innerHTML=`<div class="dc-device-identity"><span class="dc-device-icon">${icon('camera')}</span><div><h2>${escape(camera.name)}</h2><p>${escape(camera.ip)} <span>·</span> ${escape(caps.protocol||camera.protocol||'RTSP').toUpperCase()}</p></div><span class="badge green">Связь установлена</span></div><div class="dc-tabs" role="tablist" aria-label="Параметры устройства">${tabs.map(([id,label,available])=>`<button type="button" class="dc-tab ${activeTab===id?'active':''}" data-device-tab="${id}" role="tab" aria-selected="${activeTab===id}" ${!available?'disabled title="Устройство не сообщило о поддержке этой функции"':''}>${escape(label)}</button>`).join('')}</div><div class="dc-tab-content" data-device-content></div>${unsupported.length?`<p class="dc-support-note">Не заявлены устройством: ${escape(unsupported.join(', '))}. Для дополнительных функций используйте веб-интерфейс или ПО производителя.</p>`:''}${(caps.notes||[]).map(note=>`<p class="dc-support-note">${escape(note)}</p>`).join('')}`;
      root.querySelectorAll('[data-device-tab]').forEach(button=>button.addEventListener('click',()=>{ptzCleanup?.();ptzCleanup=null;activeTab=button.dataset.deviceTab;draw();}));
      const content=query(root,'[data-device-content]');
      if(activeTab==='info')renderInfo(content);
      else if(activeTab==='ptz'){content.innerHTML=panel('Управление поворотной камерой','Доступность отдельных команд зависит от профиля устройства.','<div data-ptz></div>','dc-ptz-panel');ptzCleanup=createPTZ(query(content,'[data-ptz]'),camera,{isAdmin:true,onError:options.onError,onSuccess:options.onSuccess},caps);}
      else renderSettings(content,activeTab);
    }
    async function renderInfo(content) {
      const thisVersion=version, cap=caps.capabilities||{};
      content.innerHTML=`<div class="dc-system-grid">${panel('Системная информация','Данные непосредственно с устройства.','<div data-system-info>'+loading()+'</div>')}${panel('Время и обслуживание','Операции выполняются на выбранном устройстве.',`<div data-system-time>${loading()}</div><div class="dc-action-row">${allowed(cap.time)?`<button class="btn" data-time-sync>${icon('refresh')} ${camera.protocol==='dvrip'?'Установить время этого компьютера':'Синхронизировать время'}</button>`:''}${allowed(cap.reboot)?`<button class="btn btn-danger" data-device-reboot>${icon('power')} Перезагрузить</button>`:''}</div>${camera.protocol==='onvif'?`<form data-hostname-form class="dc-hostname-form">${field('Сетевое имя','<input class="field" name="hostname" maxlength="63" pattern="[A-Za-z0-9][A-Za-z0-9-]{0,62}" placeholder="camera-lobby" required>','Латинские буквы, цифры и дефис. Имя устройства в сети.')}<button class="btn" type="submit">Применить имя</button></form>`:''}`)}${panel('Сеть','Текущие интерфейсы и адреса.','<div data-system-network>'+loading()+'</div>','dc-network-panel')}</div>`;
      query(content,'[data-time-sync]')?.addEventListener('click',async event=>{
        const button=event.currentTarget;button.disabled=true;
        const now=new Date(),pad=value=>String(value).padStart(2,'0'),localTime=`${now.getFullYear()}-${pad(now.getMonth()+1)}-${pad(now.getDate())}T${pad(now.getHours())}:${pad(now.getMinutes())}:${pad(now.getSeconds())}`;
        try{await call('/api/device/system',{action:'time',utc:now.toISOString(),local_time:localTime});success('Время устройства синхронизировано');if(current()&&thisVersion===version&&content.isConnected)renderInfo(content);}catch(error){fail(error);}finally{button.disabled=false;}
      });
      query(content,'[data-device-reboot]')?.addEventListener('click',async event=>{
        if(!window.confirm(`Перезагрузить устройство «${camera.name}» (${camera.ip})? Все его каналы временно станут недоступны.`))return;
        const button=event.currentTarget;button.disabled=true;
        try{await call('/api/device/system',{action:'reboot',confirm:true});success('Команда перезагрузки отправлена');}catch(error){fail(error);}finally{button.disabled=false;}
      });
      query(content,'[data-hostname-form]')?.addEventListener('submit',async event=>{
        event.preventDefault();const form=event.currentTarget,button=query(form,'button');button.disabled=true;
        try{await call('/api/device/hostname',{hostname:form.elements.hostname.value.trim()});success('Сетевое имя изменено');}catch(error){fail(error);}finally{button.disabled=false;}
      });
      try{
        const data=await call('/api/device/system',{action:'read'});
        if(!current()||version!==thisVersion||!content.isConnected)return;
        query(content,'[data-system-info]').innerHTML=infoTable(data.system_info);
        query(content,'[data-system-time]').innerHTML=data.time?`<pre class="dc-data-pre">${escape(asText(data.time))}</pre>`:empty('Устройство не предоставило время.');
        query(content,'[data-system-network]').innerHTML=data.network?`<pre class="dc-data-pre">${escape(asText(data.network))}</pre>`:empty('Сетевые параметры недоступны через этот протокол.');
        const hostname=query(content,'[name="hostname"]');if(hostname)hostname.value=data.system_info?.hostname||'';
      }catch(error){if(current()&&version===thisVersion&&content.isConnected){query(content,'[data-system-info]').innerHTML=`<div class="dc-error" role="alert">${escape(error.message)}</div>`;query(content,'[data-system-time]').innerHTML=empty('Время не получено');query(content,'[data-system-network]').innerHTML=empty('Сеть не получена');}fail(error);}
    }
    function renderSettings(content,kind) {
      const profiles=(caps.profiles||[]).filter(item=>kind==='encoder'?item.encoder_token:item.video_source_token);
      const allProfiles=profiles.length?profiles:(caps.profiles||[]);
      if(!allProfiles.some(item=>item.token===selectedProfile))selectedProfile=allProfiles[0]?.token||'';
      content.innerHTML=panel(kind==='encoder'?'Настройки видеопотока':'Настройки изображения','Параметры считываются с камеры. Изменения применяются кнопкой сохранения.',`${field('Профиль',`<select class="select" data-settings-profile>${allProfiles.map(item=>`<option value="${escape(item.token)}" ${item.token===selectedProfile?'selected':''}>${escape(item.name||item.token)}</option>`).join('')}</select>`)}<div data-settings-body>${loading()}</div>`,'dc-settings-panel');
      query(content,'[data-settings-profile]').addEventListener('change',event=>{selectedProfile=event.target.value;readSettings();});
      readSettings();
      async function readSettings() {
        const thisVersion=version,profile=selectedProfile,body=query(content,'[data-settings-body]');body.innerHTML=loading();
        try{
          const data=await call(`/api/device/${kind}`,{profile_token:profile});
          if(!current()||version!==thisVersion||!content.isConnected||profile!==selectedProfile)return;
          const settings=data.settings||{},settingsOptions=data.options||{};
          let fields='',editable=0;
          if(kind==='encoder'){
            const resolutions=[...(settingsOptions.resolutions||[])],canSetResolution=resolutions.length>0;
            if(!resolutions.some(item=>Number(item.width)===Number(settings.width)&&Number(item.height)===Number(settings.height))&&settings.width&&settings.height)resolutions.unshift({width:settings.width,height:settings.height});
            fields=field('Кодек',`<input class="field" value="${escape(settings.encoding||'—')}" disabled>`)+field('Разрешение',`<select class="select" ${canSetResolution?'name="resolution" required':'disabled'}>${resolutions.map(item=>`<option value="${Number(item.width)}x${Number(item.height)}" ${Number(item.width)===Number(settings.width)&&Number(item.height)===Number(settings.height)?'selected':''}>${Number(item.width)} × ${Number(item.height)}</option>`).join('')}</select>`);
            if(canSetResolution)editable++;
            for(const [name,label,step,unit]of [['fps','Частота кадров',1,'кадр/с'],['bitrate','Битрейт',1,'кбит/с'],['quality','Качество',0.1,'']]){
              if(settings[name]==null)continue;
              if(settingsOptions[name]){fields+=field(label,numericInput(name,settings[name],settingsOptions[name],step,unit));editable++;}
              else fields+=field(label,`<input class="field" value="${escape(settings[name])}${unit?' '+escape(unit):''}" disabled>`,'Устройство не сообщило допустимый диапазон изменения.');
            }
          }else{
            const labels={Brightness:'Яркость',Contrast:'Контраст',ColorSaturation:'Насыщенность',Sharpness:'Резкость'};
            const supported=Object.entries(labels).filter(([name])=>settings[name]!=null&&settingsOptions[name]);editable=supported.length;
            fields=supported.map(([name,label])=>field(label,numericInput(name,settings[name],settingsOptions[name],0.1),`${settingsOptions[name].Min ?? '—'} — ${settingsOptions[name].Max ?? '—'}`)).join('');
          }
          if(!fields){body.innerHTML=empty('Камера не предоставила редактируемые параметры этого профиля.');return;}
          body.innerHTML=`<form data-settings-form><div class="dc-fields-grid">${fields}</div><div class="dc-settings-foot"><p class="dc-muted">${editable?'Изменение видеопотока может кратковременно прервать просмотр.':'Устройство предоставило параметры только для чтения.'}</p><button class="btn btn-primary" type="submit" ${!editable?'disabled':''}>${icon('save')} Сохранить параметры</button></div><p class="dc-inline-status" role="status"></p></form>`;
          query(body,'[data-settings-form]').addEventListener('submit',async event=>{
            event.preventDefault();const form=event.currentTarget,button=query(form,'[type="submit"]'),values=new FormData(form),next={};
            for(const [name,value]of values){if(name==='resolution'){const [width,height]=String(value).split('x').map(Number);next.width=width;next.height=height;}else next[name]=Number(value);}
            button.disabled=true;query(form,'.dc-inline-status').textContent='Сохранение…';
            try{await call(`/api/device/${kind}`,{profile_token:profile,settings:next});if(current()&&content.isConnected&&profile===selectedProfile){success('Параметры устройства сохранены');await readSettings();}}
            catch(error){if(form.isConnected)query(form,'.dc-inline-status').textContent=error.message;fail(error);}finally{button.disabled=false;}
          });
        }catch(error){if(current()&&version===thisVersion&&content.isConnected&&profile===selectedProfile)body.innerHTML=`<div class="dc-error" role="alert">${escape(error.message)}</div>`;fail(error);}
      }
    }
    load();return dispose;
  }
  window.VMSDevices = Object.freeze({render,mountPTZ:createPTZ,safeWebURL});
})();
