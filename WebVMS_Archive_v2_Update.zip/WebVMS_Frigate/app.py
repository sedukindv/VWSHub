from __future__ import annotations

import atexit
import json
import logging
import os
import re
import shutil
import struct
import subprocess
import tempfile
import threading
import time
import uuid
import queue
from datetime import datetime, timedelta
from pathlib import Path, PurePosixPath
from urllib.parse import quote, urlsplit, urlunsplit

from flask import (
    Flask, abort, jsonify, render_template, request,
    send_from_directory, session, redirect, url_for, Response, stream_with_context
)
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
from cryptography.fernet import Fernet, InvalidToken
from dvrip import DVRIPCam

try:
    from onvif import ONVIFCamera
except ImportError:
    ONVIFCamera = None

app = Flask(__name__)

BASE_DIR = Path(__file__).parent
DATA_DIR = Path(os.environ.get("WEBVMS_DATA_DIR", str(BASE_DIR)))
DATA_DIR.mkdir(parents=True, exist_ok=True)
STATIC_ROOT = BASE_DIR / "static"
LIVE_ROOT = Path(os.environ.get("LIVE_ROOT", str(Path(tempfile.gettempdir()) / "vms-live")))

SECRET_FILE = DATA_DIR / ".flask_secret"
def _load_secret() -> str:
    configured = os.environ.get("FLASK_SECRET_KEY")
    if configured: return configured
    if SECRET_FILE.exists(): return SECRET_FILE.read_text(encoding="utf-8").strip()
    value = uuid.uuid4().hex + uuid.uuid4().hex
    SECRET_FILE.write_text(value, encoding="utf-8")
    try: os.chmod(SECRET_FILE, 0o600)
    except Exception: pass
    return value
app.secret_key = _load_secret()
app.config.update(
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE="Lax",
    SESSION_COOKIE_SECURE=os.environ.get("COOKIE_SECURE", "0") == "1",
    PERMANENT_SESSION_LIFETIME=timedelta(days=7),
    MAX_CONTENT_LENGTH=1024 * 1024,
)

logging.basicConfig(
    level=os.environ.get("LOG_LEVEL", "INFO"),
    format="%(asctime)s %(levelname)s %(name)s: %(message)s",
)
log = logging.getLogger("web-vms")

OK_CODES = {100, 150, 515}
DVRIP_HEADER = struct.Struct("BB2xII2xHI")

KEY_FILE = DATA_DIR / ".camkey"

def _load_fernet() -> Fernet:
    if KEY_FILE.exists():
        key = KEY_FILE.read_bytes().strip()
    else:
        key = Fernet.generate_key()
        KEY_FILE.write_bytes(key)
        try: os.chmod(KEY_FILE, 0o600)
        except Exception: pass
        log.warning("Создан новый ключ шифрования %s — сохраните его!", KEY_FILE)
    return Fernet(key)

FERNET = _load_fernet()

def enc_pwd(s: str) -> str:
    if not s: return ""
    return "enc:" + FERNET.encrypt(s.encode()).decode()

def dec_pwd(s: str) -> str:
    if not s: return ""
    if s.startswith("enc:"):
        try: return FERNET.decrypt(s[4:].encode()).decode()
        except InvalidToken: return ""
    return s

class DataStore:
    def __init__(self, base_dir: Path):
        self.users_file = base_dir / "users.json"
        self.cameras_file = base_dir / "camconfig.json"
        self.groups_file = base_dir / "groups.json"
        self.lock = threading.RLock()
        self._migrate_if_needed()
        self._ensure_defaults()

    def _migrate_if_needed(self):
        if self.users_file.exists() and self.cameras_file.exists(): return
        old = self.users_file.parent / "vms_data.json"
        if old.exists():
            try:
                with open(old, "r", encoding="utf-8") as f: data = json.load(f)
                self._write(self.users_file, data.get("users", []))
                self._write(self.cameras_file, data.get("cameras", []))
                self._write(self.groups_file, data.get("groups", []))
            except Exception: pass

    def _ensure_defaults(self):
        if not self.users_file.exists():
            self._write(self.users_file, [
                {"username": "admin", "password_hash": generate_password_hash("admin"), "role": "admin", "theme": "auto"},
                {"username": "viewer", "password_hash": generate_password_hash("viewer"), "role": "viewer", "theme": "auto"},
            ])
        if not self.cameras_file.exists(): self._write(self.cameras_file, [])
        if not self.groups_file.exists(): self._write(self.groups_file, [])

    @staticmethod
    def _read(path: Path, default):
        if not path.exists(): return default
        try:
            with open(path, "r", encoding="utf-8") as f: return json.load(f)
        except Exception: return default

    @staticmethod
    def _write(path: Path, data):
        tmp = path.with_suffix(path.suffix + ".tmp")
        with open(tmp, "w", encoding="utf-8") as f: json.dump(data, f, ensure_ascii=False, indent=2)
        tmp.replace(path)

    def get_users(self): return self._read(self.users_file, [])
    def get_cameras(self): return self._read(self.cameras_file, [])
    def get_groups(self): return self._read(self.groups_file, [])

    def save_users(self, users):
        with self.lock: self._write(self.users_file, users)
    def save_cameras(self, cameras):
        with self.lock: self._write(self.cameras_file, cameras)
    def save_groups(self, groups):
        with self.lock: self._write(self.groups_file, groups)

store = DataStore(DATA_DIR)

# Encrypt legacy camera passwords that were previously stored as plain text.
try:
    _cams = store.get_cameras()
    _changed = False
    for _cam in _cams:
        _pwd = _cam.get("password", "")
        if _pwd and not _pwd.startswith("enc:"):
            _cam["password"] = enc_pwd(_pwd)
            _changed = True
    if _changed:
        store.save_cameras(_cams)
        log.warning("Пароли камер перенесены в зашифрованный формат.")
except Exception:
    log.exception("Не удалось выполнить миграцию паролей камер")

def current_user():
    uname = session.get("username")
    if not uname: return None
    for u in store.get_users():
        if u.get("username") == uname: return u
    return None

def get_camera(cam_id: str):
    return next((c for c in store.get_cameras() if c.get("id") == cam_id), None)

def build_rtsp_live_url(cam, stream_type="main"):
    proto = cam.get("protocol", "dvrip")
    ip = cam["ip"]
    user = cam.get("username", "")
    pwd = dec_pwd(cam.get("password", ""))
    user_enc = quote(user, safe="")
    pass_enc = quote(pwd, safe="")
    rtsp_port = int(cam.get("rtsp_port", 554))

    if proto == "dvrip":
        channel = int(cam.get("channel", 0))
        s = 0 if stream_type == "main" else 1
        return (f"rtsp://{user_enc}:{pass_enc}@{ip}:{rtsp_port}/"
                f"user={user}&password={pwd}"
                f"&channel={channel + 1}&stream={s}.sdp?real_stream")
    path = cam.get("rtsp_path", "").strip()
    if path and not path.startswith("/"): path = "/" + path
    return f"rtsp://{user_enc}:{pass_enc}@{ip}:{rtsp_port}{path}"

def onvif_connect(cam):
    if ONVIFCamera is None:
        raise RuntimeError("ONVIF-модуль не установлен. Выполните: pip install -r requirements.txt")
    from zeep.transports import Transport
    return ONVIFCamera(
        str(cam["ip"]), int(cam.get("port", 80)),
        str(cam.get("username", "")), dec_pwd(cam.get("password", "")),
        transport=Transport(timeout=6, operation_timeout=6),
    )


def dvr_connect(cam):
    dvr = DVRIPCam(cam["ip"], user=cam.get("username", ""),
                   password=dec_pwd(cam.get("password", "")),
                   port=int(cam.get("port", 34567)))
    if not dvr.login(): raise ConnectionError("Не удалось авторизоваться на устройстве")
    try:
        dvr.timeout = 60
        dvr.socket.settimeout(60)
    except Exception: pass
    return dvr

class LiveManager:
    def __init__(self, root: Path):
        self.root = root
        self.root.mkdir(parents=True, exist_ok=True)
        self.lock = threading.RLock()
        self.streams = {}

    def _stop_locked(self, key):
        item = self.streams.pop(key, None)
        if not item: return
        proc = item.get("process")
        if proc and proc.poll() is None:
            proc.terminate()
            try: proc.wait(timeout=3)
            except subprocess.TimeoutExpired: proc.kill(); proc.wait(timeout=2)
        try: item["log_file"].close()
        except Exception: pass
        shutil.rmtree(item["directory"], ignore_errors=True)

    def stop(self, cam_id, stream):
        with self.lock: self._stop_locked((cam_id, stream))

    def release(self, cam_id, stream, consumer):
        """Release this browser's lease; other browsers keep their shared stream."""
        with self.lock:
            item = self.streams.get((cam_id, stream))
            if not item: return
            leases = item.setdefault("leases", {})
            leases.pop(consumer, None)
            cutoff = time.monotonic() - 30
            if not any(seen > cutoff for seen in leases.values()):
                self._stop_locked((cam_id, stream))

    def reap(self):
        """Bound abandoned FFmpeg processes even when a browser closes abruptly."""
        while True:
            time.sleep(10)
            with self.lock:
                cutoff = time.monotonic() - 30
                for key, item in list(self.streams.items()):
                    if not any(seen > cutoff for seen in item.get("leases", {}).values()):
                        self._stop_locked(key)

    def stop_all(self):
        with self.lock:
            for k in list(self.streams): self._stop_locked(k)

    def ensure(self, cam_id, stream, consumer="legacy"):
        if stream not in ("main", "sub"): raise ValueError("Поток: main или sub")
        if not re.fullmatch(r"[A-Za-z0-9_-]{1,100}", str(cam_id)): raise ValueError("Некорректный идентификатор камеры")
        cam = get_camera(cam_id)
        if not cam: raise ValueError("Камера не найдена")
        ffmpeg = shutil.which("ffmpeg")
        if not ffmpeg: raise RuntimeError("FFmpeg не установлен")

        key = (cam_id, stream)
        with self.lock:
            ex = self.streams.get(key)
            if ex and ex["process"].poll() is None:
                ex.setdefault("leases", {})[consumer] = time.monotonic()
                return ex
            if ex: self._stop_locked(key)

            directory = self.root / f"{cam_id}_{stream}"
            shutil.rmtree(directory, ignore_errors=True)
            directory.mkdir(parents=True, exist_ok=True)
            log_file = open(directory / "ffmpeg.log", "ab", buffering=0)

            cmd = [
                ffmpeg, "-hide_banner", "-nostdin", "-loglevel", "warning",
                "-rtsp_transport", "tcp", "-i", build_rtsp_live_url(cam, stream),
                "-map", "0:v:0", "-an", "-c:v", "copy",
                "-f", "hls", "-hls_time", "2", "-hls_list_size", "6",
                "-hls_delete_threshold", "2",
                "-hls_flags", "delete_segments+append_list+omit_endlist+independent_segments",
                "-hls_segment_filename", str(directory / "seg_%06d.ts"),
                str(directory / "index.m3u8"),
            ]
            proc = subprocess.Popen(cmd, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=log_file)
            item = {"process": proc, "directory": directory, "log_file": log_file, "leases": {consumer: time.monotonic()}}
            self.streams[key] = item
            return item

live_manager = LiveManager(LIVE_ROOT)
threading.Thread(target=live_manager.reap, name="live-stream-reaper", daemon=True).start()
atexit.register(live_manager.stop_all)

def normalize_time(v: str) -> str:
    v = (v or "").strip().replace("T", " ")
    for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d %H:%M", "%Y-%m-%d"):
        try: return datetime.strptime(v, fmt).strftime("%Y-%m-%d %H:%M:%S")
        except ValueError: continue
    raise ValueError("Время: ГГГГ-ММ-ДД ЧЧ:ММ[:СС]")

def parse_times_from_path(path: str):
    base = re.split(r"[\\/]", path)[-1]
    date_match = re.search(r"(20\d{2})[-_/]?(\d{2})[-_/]?(\d{2})", path)
    tm = re.search(r"(?P<h1>\d{2})[._:-](?P<m1>\d{2})[._:-](?P<s1>\d{2})-(?P<h2>\d{2})[._:-](?P<m2>\d{2})[._:-](?P<s2>\d{2})", base)
    if not date_match or not tm: return None, None
    try:
        y, mo, d = (int(date_match.group(i)) for i in (1, 2, 3))
        v = {k: int(x) for k, x in tm.groupdict().items()}
        st = datetime(y, mo, d, v["h1"], v["m1"], v["s1"])
        en = datetime(y, mo, d, v["h2"], v["m2"], v["s2"])
    except ValueError: return None, None
    if en < st: en += timedelta(days=1)
    return st.strftime("%Y-%m-%d %H:%M:%S"), en.strftime("%Y-%m-%d %H:%M:%S")

def normalize_recordings(records, channel=0):
    """Validate, sort and deduplicate recorder file ranges without filling gaps."""
    normalized, seen = [], set()
    for record in records:
        if not isinstance(record, dict):
            continue
        path = record.get("FilePath") or record.get("FileName") or record.get("Path") or record.get("Name")
        if not isinstance(path, str) or not path.strip() or len(path) > 2048 or "\x00" in path:
            continue
        fallback = None
        times = []
        for key, index in (("BeginTime", 0), ("EndTime", 1)):
            try:
                value = normalize_time(record.get(key))
            except (ValueError, TypeError, AttributeError):
                if fallback is None:
                    fallback = parse_times_from_path(path)
                value = fallback[index]
            times.append(value)
        start, end = times
        if not start or not end or start >= end:
            continue
        identity = (path, start, end)
        if identity in seen:
            continue
        seen.add(identity)
        # Keep complete ranges, including files crossing query boundaries;
        # callers can clip these to their displayed search window.
        normalized.append({"FileName": path, "FilePath": path,
                           "BeginTime": start, "EndTime": end,
                           "Channel": record.get("Channel", channel)})
    return sorted(normalized, key=lambda row: (row["BeginTime"], row["EndTime"], row["FilePath"]))


def _group_recordings(records, gap_seconds=300):
    if not records: return []
    parsed = []
    for r in records:
        try:
            bt = datetime.strptime(r["BeginTime"], "%Y-%m-%d %H:%M:%S")
            et = datetime.strptime(r["EndTime"], "%Y-%m-%d %H:%M:%S")
        except Exception: continue
        if et <= bt: continue
        parsed.append((bt, et, r))
    if not parsed: return []

    parsed.sort(key=lambda x: x[0])
    groups = []
    cur_bt, cur_et, items = parsed[0][0], parsed[0][1], [parsed[0][2]]
    for bt, et, r in parsed[1:]:
        if (bt - cur_et).total_seconds() <= gap_seconds:
            if et > cur_et: cur_et = et
            items.append(r)
        else:
            groups.append((cur_bt, cur_et, items))
            cur_bt, cur_et, items = bt, et, [r]
    groups.append((cur_bt, cur_et, items))

    result = []
    for bt, et, items in groups:
        result.append({
            "BeginTime": bt.strftime("%Y-%m-%d %H:%M:%S"),
            "EndTime":   et.strftime("%Y-%m-%d %H:%M:%S"),
            "Files":     len(items),
            # A group can span short recording gaps. Keep its actual intervals
            # so the timeline does not paint unavailable footage as recorded.
            "Intervals": [{"BeginTime": r["BeginTime"], "EndTime": r["EndTime"]} for r in items],
            "FileName": items[0].get("FileName"),
            "FilePath": items[0].get("FileName"),
            "Channel":  items[0].get("Channel", 0),
        })
    return result

def recv_exact(sock, size: int) -> bytes:
    data = bytearray()
    while len(data) < size:
        part = sock.recv(size - len(data))
        if not part: raise ConnectionError("Регистратор закрыл соединение во время чтения архива")
        data.extend(part)
    return bytes(data)

def dvrip_stream_chunks(cam, msg_id: int, payload: dict):
    body = json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    body += b"\x0a\x00"
    packet = DVRIP_HEADER.pack(255, 0, cam.session, cam.packet_count, msg_id, len(body)) + body
    cam.busy.acquire()
    try:
        cam.socket_send(packet)
        while True:
            header = recv_exact(cam.socket, 20)
            _head, _version, _session, _seq, _msg, data_len = DVRIP_HEADER.unpack(header)
            if data_len == 0: return
            yield recv_exact(cam.socket, data_len)
    finally:
        cam.busy.release()

def dvrip_playback_chunks(cam, file_path: str, start: str, end: str, mode="time", channel=0):
    params = {
        "StreamType": 0, "Value": 0, "TransMode": "TCP", "Channel": channel,
    }
    if mode == "files" and file_path:
        params["PlayMode"] = "ByName"
        params["FileName"] = file_path
    else:
        params["PlayMode"] = "ByTime"
        params["FileName"] = "*"

    times = {"StartTime": start, "EndTime": end}
    start_payload = {"Name": "OPPlayBack", "OPPlayBack": {"Action": "DownloadStart", "Parameter": params, **times}}
    stop_payload = {"Name": "OPPlayBack", "OPPlayBack": {"Action": "DownloadStop", "Parameter": params, **times}}
    try:
        yield from dvrip_stream_chunks(cam, 1420, start_payload)
    finally:
        try: cam.send(1420, stop_payload)
        except Exception: pass

def iter_dvr_video_frames(chunks, metadata=None):
    buffer = bytearray()
    codec_format = None
    waiting_for_keyframe = True
    max_frame_size = 64 * 1024 * 1024
    for chunk in chunks:
        if chunk: buffer.extend(chunk)
        while True:
            marker = buffer.find(b"\x00\x00\x01")
            if marker < 0:
                if len(buffer) > 3: del buffer[:-3]
                break
            if marker > 0: del buffer[:marker]
            if len(buffer) < 4: break
            frame_type = buffer[3]
            if frame_type in (0xFC, 0xFE):
                header_size = 16
                if len(buffer) < header_size: break
                payload_size = struct.unpack_from("<I", buffer, 12)[0]
                frame_fps = buffer[5]
                frame_datetime = struct.unpack_from("<I", buffer, 8)[0]
                media_code = buffer[4] & 0x0F
                if media_code == 2: discovered_format = "h264"
                elif media_code == 3: discovered_format = "hevc"
                elif media_code == 1: discovered_format = "m4v"
                else: discovered_format = None
            elif frame_type == 0xFD:
                header_size = 8
                if len(buffer) < header_size: break
                payload_size = struct.unpack_from("<I", buffer, 4)[0]
                discovered_format = codec_format
            elif frame_type in (0xFA, 0xF9):
                header_size = 8
                if len(buffer) < header_size: break
                payload_size = struct.unpack_from("<H", buffer, 6)[0]
                discovered_format = None
            else:
                del buffer[0]; continue
            if payload_size < 0 or payload_size > max_frame_size:
                del buffer[0]; continue
            total = header_size + payload_size
            if len(buffer) < total: break
            payload = bytes(buffer[header_size:total])
            del buffer[:total]
            if frame_type in (0xFC, 0xFE) and discovered_format:
                codec_format = discovered_format
                waiting_for_keyframe = False
                if metadata is not None and not metadata:
                    # OpenIPC/python-dvr: keyframe wrapper is BBBBII after
                    # the marker: media,FPS,width/8,height/8,datetime,length.
                    if 1 <= frame_fps <= 120:
                        metadata["fps"] = frame_fps
                    packed = frame_datetime
                    try:
                        stamp = datetime(2000 + ((packed >> 26) & 0x3F),
                                         (packed >> 22) & 0x0F, (packed >> 17) & 0x1F,
                                         (packed >> 12) & 0x1F, (packed >> 6) & 0x3F,
                                         packed & 0x3F)
                        metadata["start_time"] = stamp.strftime("%Y-%m-%d %H:%M:%S")
                    except ValueError:
                        pass
            if frame_type == 0xFD and codec_format:
                discovered_format = codec_format
            if not payload or discovered_format is None: continue
            if waiting_for_keyframe: continue
            yield discovered_format, payload

def create_archive_response(cam_info: dict, file_path: str, start: str, end: str, as_attachment: bool = False, mode="time"):
    ffmpeg = shutil.which("ffmpeg")
    if not ffmpeg: return jsonify({"error": "FFmpeg не установлен."}), 503

    cam = None
    channel = int(cam_info.get("channel", 0))
    try:
        cam = dvr_connect(cam_info)
        params = {"StreamType": 0, "Value": 0, "TransMode": "TCP", "Channel": channel}
        if mode == "files" and file_path:
            params["PlayMode"] = "ByName"
            params["FileName"] = file_path
        else:
            params["PlayMode"] = "ByTime"
            params["FileName"] = "*"

        claim = cam.send(1424, {
            "Name": "OPPlayBack",
            "OPPlayBack": {"Action": "Claim", "Parameter": params, "StartTime": start, "EndTime": end},
        })
        if not isinstance(claim, dict) or claim.get("Ret") not in OK_CODES:
            raise RuntimeError(f"Регистратор отказал в чтении архива: {claim!r}")
    except Exception as exc:
        if cam: cam.close()
        return jsonify({"error": str(exc)}), 502

    output_queue = queue.Queue(maxsize=64)
    cancel = threading.Event()
    state = {"error": None, "process": None}
    metadata = {}
    cleanup_lock = threading.Lock()

    def queue_put(item):
        while not cancel.is_set():
            try: output_queue.put(item, timeout=0.25); return True
            except queue.Full: continue
        return False

    def worker():
        proc = None
        frame_iter = None
        reader = None
        try:
            frame_iter = iter_dvr_video_frames(dvrip_playback_chunks(cam, file_path, start, end, mode=mode, channel=channel), metadata)
            first_frame = next(frame_iter, None)
            if first_frame is None: raise RuntimeError("Регистратор не передал видеокадры.")
            input_format, first_bytes = first_frame
            if cancel.is_set(): return
            # Elementary video lost container timestamps when DVR wrappers were
            # removed. Use the recorder's validated FPS, rather than FFmpeg's
            # fallback (often 25 FPS), without touching the live RTSP pipeline.
            rate_options = ["-r", str(metadata["fps"])] if "fps" in metadata else []
            duration = (datetime.strptime(end, "%Y-%m-%d %H:%M:%S") - datetime.strptime(start, "%Y-%m-%d %H:%M:%S")).total_seconds()
            proc = subprocess.Popen(
                [ffmpeg, "-hide_banner", "-loglevel", "error", "-fflags", "+genpts+discardcorrupt",
                 "-err_detect", "ignore_err", "-probesize", "32", "-analyzeduration", "0",
                 "-f", input_format] + rate_options + ["-i", "pipe:0", "-map", "0:v:0", "-c:v", "copy", "-an", "-t", str(duration),
                 "-movflags", "frag_keyframe+empty_moov+default_base_moof", "-f", "mp4", "pipe:1"],
                stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE, bufsize=0,
            )
            state["process"] = proc
            if cancel.is_set():
                proc.terminate()
                try: proc.wait(timeout=2)
                except subprocess.TimeoutExpired:
                    proc.kill()
                    proc.wait(timeout=2)
                return

            def read_ffmpeg_errors():
                try:
                    for line in iter(proc.stderr.readline, b''):
                        if line: log.error("FFmpeg Playback Error: %s", line.decode(errors="replace").strip())
                except Exception: pass
            threading.Thread(target=read_ffmpeg_errors, daemon=True).start()

            def read_ffmpeg_output():
                try:
                    while not cancel.is_set():
                        chunk = proc.stdout.read(64 * 1024)
                        if not chunk: break
                        if not queue_put(chunk): break
                except Exception: pass

            reader = threading.Thread(target=read_ffmpeg_output, name="archive-mp4-reader", daemon=True)
            reader.start()

            proc.stdin.write(first_bytes)
            for _format, frame_bytes in frame_iter:
                if cancel.is_set() or proc.poll() is not None: break
                proc.stdin.write(frame_bytes)
            try: proc.stdin.close()
            except Exception: pass
            if cancel.is_set() and proc.poll() is None: proc.terminate()
            try: proc.wait(timeout=10)
            except subprocess.TimeoutExpired: proc.kill(); proc.wait(timeout=2)
            if reader: reader.join(timeout=3)
        except Exception as exc:
            state["error"] = str(exc)
            log.error("Archive worker failed: %s", exc)
            if proc and proc.poll() is None:
                proc.terminate()
                try: proc.wait(timeout=2)
                except subprocess.TimeoutExpired: proc.kill()
            if reader: reader.join(timeout=2)
        finally:
            if frame_iter is not None:
                try: frame_iter.close()
                except Exception: pass
            if proc:
                for name in ("stdin", "stdout", "stderr"):
                    try:
                        stream_obj = getattr(proc, name, None)
                        if stream_obj: stream_obj.close()
                    except Exception: pass
            if cam:
                try: cam.close()
                except Exception: pass
            try: output_queue.put(None, timeout=1)
            except: pass

    thread = threading.Thread(target=worker, name="archive-dvrip-worker", daemon=True)
    thread.start()

    def cleanup_archive():
        # Called by both generator.finally and Response.close. The latter also
        # covers a browser closing a prepared response before its first read.
        with cleanup_lock:
            if state.get("cleaned"):
                return
            state["cleaned"] = True
            cancel.set()
            if cam:
                try:
                    # close() alone need not wake another thread blocked in
                    # recv() on every platform; shutdown interrupts it first.
                    sock = getattr(cam, "socket", None)
                    if sock is not None:
                        sock.shutdown(2)
                except Exception:
                    pass
                try: cam.close()
                except Exception: pass
            proc = state.get("process")
            if proc and proc.poll() is None:
                try:
                    proc.terminate()
                    try: proc.wait(timeout=2)
                    except subprocess.TimeoutExpired:
                        proc.kill()
                        proc.wait(timeout=2)
                except Exception:
                    pass
            thread.join(timeout=2)
    
    try:
        first_chunk = output_queue.get(timeout=15)
    except queue.Empty:
        cleanup_archive()
        return jsonify({"error": "Регистратор не прислал видео за 15 секунд."}), 504

    if first_chunk is None:
        cleanup_archive()
        return jsonify({"error": state["error"] or "Ошибка чтения архива"}), 502

    def generate_mp4():
        try:
            # Preserve the MP4 header order and never requeue into a possibly full
            # producer queue. Requeueing placed ftyp/moov after media or sentinel.
            yield first_chunk
            while True:
                try: chunk = output_queue.get(timeout=1.0)
                except queue.Empty:
                    if not thread.is_alive(): break
                    continue
                if chunk is None: break
                yield chunk
        except (BrokenPipeError, ConnectionResetError, GeneratorExit): pass
        finally:
            cleanup_archive()

    headers = {"Cache-Control": "no-store", "X-Accel-Buffering": "no", "Accept-Ranges": "none"}
    # Recorder-local, second-precision diagnostics; not a frame-accurate seek
    # guarantee. The browser's ordinary <video> API cannot read these headers.
    if metadata.get("start_time"):
        headers["X-Archive-Start-Time"] = metadata["start_time"]
    if metadata.get("fps"):
        headers["X-Archive-Frame-Rate"] = str(metadata["fps"])
    if as_attachment:
        base_name = secure_filename(PurePosixPath(file_path.replace("\\", "/")).name)
        base_name = re.sub(r"\.(h264|h265|264|265|dav|mp4)$", "", base_name, flags=re.IGNORECASE) or "recording"
        if mode == "time":
            camera_name = secure_filename(str(cam_info.get("name") or "")) or secure_filename(str(cam_info.get("id") or "")) or "recording"
            begin_label = datetime.strptime(start, "%Y-%m-%d %H:%M:%S").strftime("%Y%m%d_%H%M%S")
            end_label = datetime.strptime(end, "%Y-%m-%d %H:%M:%S").strftime("%Y%m%d_%H%M%S")
            base_name = f"{camera_name[:80]}_{begin_label}-{end_label}"
        headers["Content-Disposition"] = f'attachment; filename="{base_name}.mp4"'

    response = Response(stream_with_context(generate_mp4()), mimetype="video/mp4", headers=headers)
    response.call_on_close(cleanup_archive)
    return response

@app.route("/static/<path:filename>")
def static_files(filename):
    return send_from_directory(STATIC_ROOT, filename)

@app.before_request
def check_auth():
    if request.endpoint in {"login", "health", "static_files", "static"}: return
    if not current_user():
        if request.path.startswith("/api/") or request.path.startswith("/live/") or request.path.startswith("/archive/"):
            return jsonify({"error": "Требуется авторизация"}), 401
        return redirect(url_for("login"))
    if request.method in {"POST", "PUT", "PATCH", "DELETE"}:
        origin = request.headers.get("Origin")
        if origin and origin.rstrip("/") != request.host_url.rstrip("/"):
            return jsonify({"error": "Запрос с другого сайта отклонён"}), 403
    if "live_consumer" not in session:
        session["live_consumer"] = uuid.uuid4().hex

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "GET":
        if current_user(): return redirect(url_for("index"))
        return render_template("login.html")
    data = request.get_json(silent=True) or request.form
    username = (data.get("username") or "").strip()
    password = data.get("password") or ""
    user = next((u for u in store.get_users() if u.get("username") == username), None)
    if not user or not check_password_hash(user.get("password_hash", ""), password):
        if request.is_json: return jsonify({"error": "Неверный логин или пароль"}), 401
        return render_template("login.html", error="Неверный логин или пароль")
    session.clear()
    session["username"] = user["username"]
    session.permanent = True
    if request.is_json: return jsonify({"success": True})
    return redirect(url_for("index"))

@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))

@app.route("/health")
def health(): return jsonify({"status": "ok", "time": datetime.now().isoformat()})

@app.route("/")
def index():
    user = current_user()
    return render_template("index.html", user={k: user.get(k) for k in ("username", "role", "theme")})

@app.route("/api/users", methods=["GET", "POST"])
def api_users():
    me = current_user()
    if not me or me.get("role") != "admin": return jsonify({"error": "Доступ запрещён"}), 403
    users = store.get_users()
    if request.method == "GET":
        return jsonify([{"username": u["username"], "role": u["role"], "theme": u.get("theme", "auto")} for u in users])
    data = request.get_json() or {}
    uname = (data.get("username") or "").strip()
    pwd = data.get("password") or ""
    role = data.get("role") if data.get("role") in ("admin", "viewer") else "viewer"
    if not uname or not pwd: return jsonify({"error": "Укажите имя и пароль"}), 400
    if any(u["username"] == uname for u in users): return jsonify({"error": "Пользователь уже существует"}), 400
    users.append({"username": uname, "password_hash": generate_password_hash(pwd), "role": role, "theme": "auto"})
    store.save_users(users)
    return jsonify({"success": True})

@app.route("/api/users/<username>", methods=["DELETE", "PUT"])
def api_user_manage(username):
    me = current_user()
    if not me or me.get("role") != "admin": return jsonify({"error": "Доступ запрещён"}), 403
    users = store.get_users()
    target = next((u for u in users if u.get("username") == username), None)
    if not target: return jsonify({"error": "Пользователь не найден"}), 404
    if request.method == "DELETE":
        if username == me.get("username"):
            return jsonify({"error": "Нельзя удалить собственную учётную запись из текущего сеанса"}), 400
        admins = [u for u in users if u["role"] == "admin" and u["username"] != username]
        if target.get("role") == "admin" and not admins:
            return jsonify({"error": "Нельзя удалить последнего администратора"}), 400
        users = [u for u in users if u["username"] != username]
        store.save_users(users)
        return jsonify({"success": True})
    data = request.get_json(silent=True) or {}
    requested_role = data.get("role")
    if target.get("role") == "admin" and requested_role == "viewer":
        other_admins = [u for u in users if u.get("role") == "admin" and u.get("username") != username]
        if not other_admins:
            return jsonify({"error": "Нельзя понизить роль последнего администратора"}), 400
    if data.get("password") and len(str(data["password"])) < 6:
        return jsonify({"error": "Пароль должен содержать минимум 6 символов"}), 400
    for u in users:
        if u["username"] == username:
            if data.get("password"): u["password_hash"] = generate_password_hash(data["password"])
            if requested_role in ("admin", "viewer"): u["role"] = requested_role
            if data.get("theme") in ("auto", "light", "dark"): u["theme"] = data["theme"]
    store.save_users(users)
    return jsonify({"success": True})

@app.route("/api/profile/theme", methods=["POST"])
def api_set_theme():
    me = current_user()
    if not me: return jsonify({"error": "Не авторизован"}), 401
    theme = (request.get_json() or {}).get("theme")
    if theme not in ("auto", "light", "dark"): return jsonify({"error": "Некорректная тема"}), 400
    users = store.get_users()
    for u in users:
        if u["username"] == me["username"]: u["theme"] = theme
    store.save_users(users)
    return jsonify({"success": True})

@app.route("/api/cameras", methods=["GET", "POST"])
def api_cameras():
    me = current_user()
    cameras = store.get_cameras()
    if request.method == "GET":
        # Never return stored credentials to the browser; empty password on edit means keep existing.
        return jsonify([{k: v for k, v in c.items() if k != "password"} for c in cameras])
    if not me or me.get("role") != "admin": return jsonify({"error": "Доступ запрещён"}), 403
    d = request.get_json(silent=True) or {}
    name = str(d.get("name") or "").strip()
    ip = str(d.get("ip") or "").strip()
    if not name or not ip: return jsonify({"error": "Укажите название и IP"}), 400
    if len(name) > 150 or len(ip) > 253 or not re.fullmatch(r"[A-Za-z0-9_.:-]+", ip) or ".." in ip:
        return jsonify({"error": "Укажите корректный IP-адрес или DNS-имя устройства"}), 400
    protocol = d.get("protocol", "dvrip")
    if protocol not in ("dvrip", "onvif"):
        return jsonify({"error": "Неизвестный протокол камеры"}), 400
    try:
        port = int(d.get("port", 34567 if protocol == "dvrip" else 80))
        rtsp_port = int(d.get("rtsp_port", 554))
        channel = int(d.get("channel", 0)) if protocol == "dvrip" else 0
    except (TypeError, ValueError):
        return jsonify({"error": "Порты и канал должны быть числами"}), 400
    if not (1 <= port <= 65535 and 1 <= rtsp_port <= 65535):
        return jsonify({"error": "Порт должен быть в диапазоне 1–65535"}), 400
    if protocol == "dvrip" and not (0 <= channel <= 63):
        return jsonify({"error": "Канал регистратора должен быть в диапазоне 1–64"}), 400
    cam_id = d.get("id") or f"cam_{uuid.uuid4().hex}"
    if not isinstance(cam_id, str) or not re.fullmatch(r"[A-Za-z0-9_-]{1,100}", cam_id):
        return jsonify({"error": "Некорректный идентификатор камеры"}), 400
    existing = next((c for c in cameras if c.get("id") == cam_id), None)
    pwd_in = d.get("password", "")
    if existing and pwd_in == "": stored_pwd = existing.get("password", "")
    else: stored_pwd = enc_pwd(pwd_in) if pwd_in else ""
    new_cam = {
        "id": cam_id, "name": name, "protocol": protocol, "ip": ip,
        "port": port, "rtsp_port": rtsp_port,
        "username": str(d.get("username") or "admin").strip(), "password": stored_pwd,
    }
    if protocol == "dvrip": new_cam["channel"] = channel
    else:
        new_cam["rtsp_path"] = str(d.get("rtsp_path") or "").strip()
        new_cam["rtsp_sub_path"] = str(d.get("rtsp_sub_path") or (existing or {}).get("rtsp_sub_path") or "").strip()
        for key in ("rtsp_path", "rtsp_sub_path"):
            path = new_cam[key]
            if len(path) > 2048 or "://" in path or any(ord(c) < 32 for c in path):
                return jsonify({"error": "Укажите только путь RTSP без адреса/учётных данных"}), 400
    if existing is not None: cameras[cameras.index(existing)] = new_cam
    else: cameras.append(new_cam)
    store.save_cameras(cameras)
    if existing is not None:
        live_manager.stop(cam_id, "main")
        live_manager.stop(cam_id, "sub")
    return jsonify({"success": True, "camera": {k: v for k, v in new_cam.items() if k != "password"}})

@app.route("/api/cameras/<cam_id>", methods=["DELETE"])
def api_camera_delete(cam_id):
    me = current_user()
    if not me or me.get("role") != "admin": return jsonify({"error": "Доступ запрещён"}), 403
    store.save_cameras([c for c in store.get_cameras() if c.get("id") != cam_id])
    groups = store.get_groups()
    for g in groups: g["camera_ids"] = [c for c in g.get("camera_ids", []) if c != cam_id]
    store.save_groups(groups)
    live_manager.stop(cam_id, "main")
    live_manager.stop(cam_id, "sub")
    return jsonify({"success": True})

@app.route("/api/cameras/test", methods=["POST"])
def api_camera_test():
    me = current_user()
    if not me or me.get("role") != "admin": return jsonify({"error": "Доступ запрещён"}), 403
    d = request.get_json() or {}
    pwd = d.get("password", "")
    if not pwd and d.get("id"):
        existing = get_camera(d["id"])
        if existing: pwd = dec_pwd(existing.get("password", ""))
    try:
        if d.get("protocol", "dvrip") == "dvrip":
            dvr = DVRIPCam(d["ip"], user=d.get("username", ""), password=pwd, port=int(d.get("port", 34567)))
            if not dvr.login(): return jsonify({"ok": False, "error": "Авторизация не удалась"}), 200
            dvr.close()
            return jsonify({"ok": True})
        else:
            ffmpeg = shutil.which("ffmpeg")
            if not ffmpeg:
                return jsonify({"ok": False, "error": "FFmpeg не установлен на сервере"}), 200
            cam_stub = {"protocol": "onvif", "ip": d["ip"], "username": d.get("username", ""), "password": pwd, "rtsp_port": int(d.get("rtsp_port", 554)), "rtsp_path": d.get("rtsp_path", "")}
            url = build_rtsp_live_url(cam_stub, "main")
            proc = subprocess.run([ffmpeg, "-hide_banner", "-loglevel", "error", "-rtsp_transport", "tcp", "-i", url, "-t", "1", "-f", "null", "-"], capture_output=True, text=True, timeout=15)
            if proc.returncode == 0: return jsonify({"ok": True})
            return jsonify({"ok": False, "error": proc.stderr.strip()[:300]}), 200
    except Exception as e:
        return jsonify({"ok": False, "error": str(e)}), 200

@app.route("/api/groups", methods=["GET", "POST"])
def api_groups():
    me = current_user()
    groups = store.get_groups()
    if request.method == "GET": return jsonify(groups)
    if not me or me.get("role") != "admin": return jsonify({"error": "Доступ запрещён"}), 403
    d = request.get_json(silent=True) or {}
    name = str(d.get("name") or "").strip()
    if not name: return jsonify({"error": "Укажите название группы"}), 400
    requested_ids = d.get("camera_ids", [])
    if not isinstance(requested_ids, list): return jsonify({"error": "Список камер должен быть массивом"}), 400
    existing_ids = {c.get("id") for c in store.get_cameras()}
    camera_ids = list(dict.fromkeys(str(cid) for cid in requested_ids if str(cid) in existing_ids))
    gid = d.get("id") or f"grp_{int(time.time() * 1000)}"
    new_group = {"id": gid, "name": name, "camera_ids": camera_ids}
    idx = next((i for i, g in enumerate(groups) if g.get("id") == gid), None)
    if idx is not None: groups[idx] = new_group
    else: groups.append(new_group)
    store.save_groups(groups)
    return jsonify({"success": True, "group": new_group})

@app.route("/api/groups/<gid>", methods=["DELETE"])
def api_group_delete(gid):
    me = current_user()
    if not me or me.get("role") != "admin": return jsonify({"error": "Доступ запрещён"}), 403
    store.save_groups([g for g in store.get_groups() if g.get("id") != gid])
    return jsonify({"success": True})

@app.route("/api/live/stop", methods=["POST"])
def api_live_stop():
    d = request.get_json(silent=True) or {}
    if d.get("cam_id"):
        live_manager.release(d["cam_id"], d.get("stream", "main"), session.get("live_consumer"))
    return jsonify({"stopped": True})

@app.route("/live/<cam_id>/<stream>/index.m3u8")
def live_playlist(cam_id, stream):
    try: item = live_manager.ensure(cam_id, stream, session.get("live_consumer"))
    except Exception as e: return jsonify({"error": str(e)}), 503
    playlist = item["directory"] / "index.m3u8"
    deadline = time.time() + 10
    while time.time() < deadline and not playlist.exists():
        if item["process"].poll() is not None: break
        time.sleep(0.2)
    if not playlist.exists(): return jsonify({"error": "Не удалось получить поток с камеры"}), 502
    r = send_from_directory(item["directory"], "index.m3u8", mimetype="application/vnd.apple.mpegurl", max_age=0)
    r.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
    return r

@app.route("/live/<cam_id>/<stream>/<path:filename>")
def live_segment(cam_id, stream, filename):
    if stream not in ("main", "sub") or Path(filename).name != filename or not filename.endswith((".ts", ".m3u8")): abort(404)
    with live_manager.lock: item = live_manager.streams.get((cam_id, stream))
    if not item: abort(404)
    with live_manager.lock:
        item.setdefault("leases", {})[session.get("live_consumer")] = time.monotonic()
    r = send_from_directory(item["directory"], filename, max_age=0)
    r.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
    if filename.endswith(".m3u8"): r.headers["Content-Type"] = "application/vnd.apple.mpegurl"
    return r

@app.route("/api/recordings")
def api_recordings():
    cam_id = request.args.get("cam_id")
    mode = request.args.get("mode", "time")
    cam = get_camera(cam_id)
    if not cam or cam.get("protocol") != "dvrip": return jsonify({"error": "Архив доступен только для DVRIP"}), 400
    if mode not in ("time", "files"): return jsonify({"error": "Неизвестный режим поиска архива"}), 400
    try:
        start = normalize_time(request.args.get("start"))
        end = normalize_time(request.args.get("end"))
        if datetime.strptime(start, "%Y-%m-%d %H:%M:%S") >= datetime.strptime(end, "%Y-%m-%d %H:%M:%S"):
            return jsonify({"error": "Начало периода должно быть раньше конца"}), 400
    except ValueError as e: return jsonify({"error": str(e)}), 400
    channel = int(cam.get("channel", 0))

    dvr = None
    try:
        dvr = dvr_connect(cam)
        raw = dvr.list_local_files(start, end, "h264", channel=channel) or []
    except Exception as e: return jsonify({"error": str(e)}), 502
    finally:
        if dvr:
            try: dvr.close()
            except Exception: pass

    if not isinstance(raw, (list, tuple)):
        return jsonify({"error": "Регистратор вернул некорректный список записей"}), 502
    norm = normalize_recordings(raw, channel)

    if mode == "files":
        return jsonify(norm)
    return jsonify(_group_recordings(norm, gap_seconds=300))

@app.route("/api/playback")
def api_playback():
    cam_id = request.args.get("cam_id")
    mode = request.args.get("mode", "time")
    if mode not in ("time", "files"): return jsonify({"error": "Режим архива: time или files"}), 400
    cam = get_camera(cam_id)
    if not cam: return jsonify({"error": "Камера не найдена"}), 404
    if cam.get("protocol") != "dvrip":
        return jsonify({"error": "Архив доступен только для DVRIP-совместимых регистраторов"}), 400
    file_path = (request.args.get("path") or "").strip()
    # Пустой путь разрешён для режима по времени: регистратор выбирает записи сам.
    if (not file_path and mode != "time") or len(file_path) > 2048 or "\x00" in file_path:
        return jsonify({"error": "Некорректный путь"}), 400
    try:
        start = normalize_time(request.args.get("start"))
        end = normalize_time(request.args.get("end"))
        if datetime.strptime(start, "%Y-%m-%d %H:%M:%S") >= datetime.strptime(end, "%Y-%m-%d %H:%M:%S"):
            return jsonify({"error": "Начало периода должно быть раньше конца"}), 400
    except ValueError as exc:
        return jsonify({"error": str(exc)}), 400
    return create_archive_response(cam, file_path, start, end, as_attachment=False, mode=mode)

@app.route("/api/download")
def api_download():
    cam_id = request.args.get("cam_id")
    mode = request.args.get("mode", "time")
    if mode not in ("time", "files"): return jsonify({"error": "Режим архива: time или files"}), 400
    cam = get_camera(cam_id)
    if not cam: return jsonify({"error": "Камера не найдена"}), 404
    if cam.get("protocol") != "dvrip":
        return jsonify({"error": "Архив доступен только для DVRIP-совместимых регистраторов"}), 400
    file_path = (request.args.get("path") or "").strip()
    # Для экспорта по времени путь к отдельному файлу не требуется.
    if (not file_path and mode != "time") or len(file_path) > 2048 or "\x00" in file_path:
        return jsonify({"error": "Некорректный путь"}), 400
    try:
        start = normalize_time(request.args.get("start"))
        end = normalize_time(request.args.get("end"))
        if datetime.strptime(start, "%Y-%m-%d %H:%M:%S") >= datetime.strptime(end, "%Y-%m-%d %H:%M:%S"):
            return jsonify({"error": "Начало периода должно быть раньше конца"}), 400
    except ValueError as exc:
        return jsonify({"error": str(exc)}), 400
    return create_archive_response(cam, file_path, start, end, as_attachment=True, mode=mode)

@app.route("/api/onvif/profiles", methods=["POST"])
def api_onvif_profiles():
    me = current_user()
    if not me or me.get("role") != "admin": return jsonify({"error": "Доступ запрещён"}), 403
    d = request.get_json(silent=True) or {}
    existing = get_camera(str(d.get("id") or "")) if d.get("id") else None
    ip = str(d.get("ip") or (existing or {}).get("ip") or "").strip()
    username = str(d.get("username") or (existing or {}).get("username") or "").strip()
    password = d.get("password") or dec_pwd((existing or {}).get("password", ""))
    try:
        port = int(d.get("port", (existing or {}).get("port", 80)))
        if not ip or not (1 <= port <= 65535):
            return jsonify({"error": "Укажите IP-адрес и корректный ONVIF-порт"}), 400
        cam = {"ip": ip, "port": port, "username": username, "password": enc_pwd(password) if password else ""}
        client = onvif_connect(cam)
        media = client.create_media_service()
        profiles = media.GetProfiles() or []
        result = []
        for profile in profiles:
            token = str(getattr(profile, "token", "") or "")
            name = str(getattr(profile, "Name", "") or token or "Профиль")
            uri = ""
            try:
                stream = media.GetStreamUri({
                    "StreamSetup": {"Stream": "RTP-Unicast", "Transport": {"Protocol": "RTSP"}},
                    "ProfileToken": token,
                })
                uri = str(getattr(stream, "Uri", "") or "")
            except Exception as exc:
                log.warning("ONVIF GetStreamUri не удался для %s / %s: %s", ip, token, exc)
            parsed = urlsplit(uri)
            path = parsed.path or ""
            if parsed.query: path += "?" + parsed.query
            if parsed.fragment: path += "#" + parsed.fragment
            # Some cameras include their password in GetStreamUri; strip userinfo.
            safe_netloc = parsed.netloc.rsplit("@", 1)[-1]
            safe_uri = urlunsplit((parsed.scheme, safe_netloc, parsed.path, parsed.query, parsed.fragment))
            result.append({"token": token, "name": name, "uri": safe_uri,
                           "rtsp_port": parsed.port or 554, "rtsp_path": path})
        return jsonify({"success": True, "ip": ip, "profiles": result})
    except Exception as exc:
        log.warning("ONVIF profiles query failed for %s: %s", ip or "?", exc)
        return jsonify({"error": str(exc)[:500]}), 502


@app.route("/api/device/hostname", methods=["POST"])
def api_device_hostname():
    me = current_user()
    if not me or me.get("role") != "admin": return jsonify({"error": "Доступ запрещён"}), 403
    d = request.get_json(silent=True) or {}
    cam = get_camera(str(d.get("cam_id") or ""))
    if not cam: return jsonify({"error": "Устройство не найдено"}), 404
    if cam.get("protocol") != "onvif":
        return jsonify({"error": "Изменение имени через этот интерфейс поддерживается только для ONVIF-устройств"}), 400
    hostname = str(d.get("hostname") or "").strip()
    if not re.fullmatch(r"[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?", hostname):
        return jsonify({"error": "Имя должно содержать 1–63 символа: латинские буквы, цифры и дефис; без дефиса в начале/конце"}), 400
    try:
        client = onvif_connect(cam)
        client.create_devicemgmt_service().SetHostname({"Name": hostname})
        return jsonify({"success": True, "hostname": hostname})
    except Exception as exc:
        log.warning("ONVIF SetHostname failed for %s: %s", cam.get("ip"), exc)
        return jsonify({"error": str(exc)[:500]}), 502


@app.route("/api/device/info", methods=["POST"])
def api_device_info():
    me = current_user()
    if not me or me.get("role") != "admin":
        return jsonify({"error": "Доступ запрещён"}), 403
    cam = get_camera((request.get_json(silent=True) or {}).get("cam_id"))
    if not cam:
        return jsonify({"error": "Устройство не найдено"}), 404
    if cam.get("protocol") == "onvif":
        try:
            client = onvif_connect(cam)
            service = client.create_devicemgmt_service()
            info = service.GetDeviceInformation()
            try:
                hostname_response = service.GetHostname()
                hostname = str(getattr(hostname_response, "Name", "") or "")
            except Exception:
                hostname = ""
            system_info = {
                "manufacturer": str(getattr(info, "Manufacturer", "") or ""),
                "model": str(getattr(info, "Model", "") or ""),
                "firmware_version": str(getattr(info, "FirmwareVersion", "") or ""),
                "serial_number": str(getattr(info, "SerialNumber", "") or ""),
                "hardware_id": str(getattr(info, "HardwareId", "") or ""),
                "hostname": hostname,
                "protocol": "ONVIF",
            }
            return jsonify({"success": True, "ip": cam["ip"], "system_info": system_info})
        except Exception as exc:
            log.warning("ONVIF device info failed for %s: %s", cam.get("ip"), exc)
            return jsonify({"error": str(exc)[:500]}), 502
    if cam.get("protocol") != "dvrip":
        return jsonify({"error": "Для этого типа устройства нет адаптера информации"}), 400
    dvr = None
    try:
        dvr = dvr_connect(cam)
        try: sys_info = dvr.get_system_info()
        except Exception as e: sys_info = {"error": str(e)}
        return jsonify({"success": True, "ip": cam["ip"], "system_info": sys_info})
    except Exception as e:
        return jsonify({"error": str(e)}), 502
    finally:
        if dvr:
            try: dvr.close()
            except Exception: pass

from device_control import register_device_routes
register_device_routes(app, current_user, get_camera, lambda cam: onvif_connect(cam), lambda cam: dvr_connect(cam), log)

if __name__ == "__main__":
    host = os.environ.get("WEB_HOST", "0.0.0.0")
    port = int(os.environ.get("WEB_PORT", 5000))
    log.info("Web VMS слушает http://%s:%s", host, port)
    app.run(host=host, port=port, debug=False, threaded=True)
