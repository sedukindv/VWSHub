"""Archive regressions: malformed recorder metadata, frame timing and cancellation."""
import io
import queue
import struct
from datetime import datetime
from unittest.mock import Mock

import pytest


def record(path, begin, end):
    return {"FileName": path, "BeginTime": begin, "EndTime": end}


def keyframe(fps=15, stamp=None):
    stamp = stamp or datetime(2026, 10, 29, 12, 0, 3)
    packed = ((stamp.year - 2000) << 26) | (stamp.month << 22) | (stamp.day << 17) | (stamp.hour << 12) | (stamp.minute << 6) | stamp.second
    return b"\x00\x00\x01\xfc" + struct.pack("<BBBBII", 2, fps, 160, 90, packed, 5) + b"FRAME"


def prepare_response(vms, monkeypatch, items=(b"HEADER", b"BODY", None)):
    chunks = queue.Queue()
    for item in items:
        chunks.put(item)
    monkeypatch.setattr(vms.queue, "Queue", lambda **kwargs: chunks)
    worker = Mock()
    worker.is_alive.return_value = False
    monkeypatch.setattr(vms.threading, "Thread", Mock(return_value=worker))
    monkeypatch.setattr(vms.shutil, "which", lambda _: "test-ffmpeg")
    dvr = Mock()
    dvr.send.return_value = {"Ret": 100}
    monkeypatch.setattr(vms, "dvr_connect", Mock(return_value=dvr))
    return dvr, worker


def test_archive_files_sorted_deduplicated_and_invalid_intervals_dropped(admin, vms, monkeypatch):
    first = record("/first.h264", "2026-10-29T12:00:00", "2026-10-29T12:10:00")
    second = record("/second.h264", "2026-10-29 12:20:00", "2026-10-29 12:30:00")
    dvr = Mock()
    dvr.list_local_files.return_value = [second, None, "wrong", first, first,
        record("/backward.h264", "2026-10-29 12:20:00", "2026-10-29 12:10:00"),
        record("/zero.h264", "2026-10-29 12:10:00", "2026-10-29 12:10:00"),
        record("/bad.h264", {"bad": "value"}, "unparseable")]
    monkeypatch.setattr(vms, "dvr_connect", Mock(return_value=dvr))
    response = admin.get("/api/recordings", query_string={"cam_id":"dvr_1", "start":"2026-10-29 12:00:00", "end":"2026-10-29 13:00:00", "mode":"files"})
    assert response.status_code == 200
    values = response.get_json()
    assert [r["FilePath"] for r in values] == ["/first.h264", "/second.h264"]
    assert values[0]["BeginTime"] == "2026-10-29 12:00:00"
    dvr.close.assert_called_once()


def test_bad_recorder_response_is_error_not_empty_archive(admin, vms, monkeypatch):
    dvr = Mock()
    dvr.list_local_files.return_value = {"Ret": 107, "Error": "forbidden"}
    monkeypatch.setattr(vms, "dvr_connect", Mock(return_value=dvr))
    response = admin.get("/api/recordings", query_string={"cam_id":"dvr_1", "start":"2026-10-29", "end":"2026-10-30", "mode":"files"})
    assert response.status_code == 502
    dvr.close.assert_called_once()


def test_groups_never_include_reversed_recording(vms):
    assert vms._group_recordings([record("/bad", "2026-10-29 13:00:00", "2026-10-29 12:00:00")]) == []


def test_close_before_first_response_read_releases_dvr(vms, monkeypatch):
    dvr, worker = prepare_response(vms, monkeypatch)
    with vms.app.test_request_context("/api/playback"):
        response = vms.create_archive_response(vms.get_camera("dvr_1"), "", "2026-10-29 12:00:00", "2026-10-29 13:00:00")
        response.close()
        response.close()
    dvr.socket.shutdown.assert_called_once_with(2)
    dvr.close.assert_called_once()
    worker.join.assert_called_once_with(timeout=2)


def test_startup_timeout_releases_dvr(vms, monkeypatch):
    dvr, worker = prepare_response(vms, monkeypatch)
    never_ready = Mock()
    never_ready.get.side_effect = queue.Empty
    monkeypatch.setattr(vms.queue, "Queue", lambda **kwargs: never_ready)
    with vms.app.test_request_context("/api/playback"):
        response, code = vms.create_archive_response(vms.get_camera("dvr_1"), "", "2026-10-29 12:00:00", "2026-10-29 13:00:00")
    assert code == 504
    dvr.socket.shutdown.assert_called_once_with(2)
    dvr.close.assert_called_once()


@pytest.mark.parametrize("fps,expected", [(15,15),(25,25),(0,None),(255,None)])
def test_frame_parser_preserves_valid_recorder_rate_and_initial_time(vms, fps, expected):
    metadata = {}
    raw = keyframe(fps)
    frames = list(vms.iter_dvr_video_frames([raw[:9], raw[9:]], metadata))
    assert frames == [("h264", b"FRAME")]
    assert metadata.get("fps") == expected
    assert metadata["start_time"] == "2026-10-29 12:00:03"


def test_stream_uses_recorder_fps_as_input_and_exposes_diagnostics(vms, monkeypatch):
    class FakeFFmpeg:
        def __init__(self):
            self.stdin = io.BytesIO()
            self.stdout = io.BytesIO(b"MP4-HEADER-MEDIA")
            self.stderr = io.BytesIO()
            self.returncode = None
        def poll(self): return self.returncode
        def wait(self, timeout=None): self.returncode = 0; return 0
        def terminate(self): self.returncode = -15
        def kill(self): self.returncode = -9
    proc = FakeFFmpeg()
    launch = Mock(return_value=proc)
    monkeypatch.setattr(vms.subprocess, "Popen", launch)
    monkeypatch.setattr(vms.shutil, "which", lambda _: "test-ffmpeg")
    dvr = Mock()
    dvr.send.return_value = {"Ret":100}
    monkeypatch.setattr(vms, "dvr_connect", Mock(return_value=dvr))
    monkeypatch.setattr(vms, "dvrip_playback_chunks", lambda *args, **kwargs: iter([keyframe(15)]))
    with vms.app.test_request_context("/api/playback"):
        response = vms.create_archive_response(vms.get_camera("dvr_1"), "", "2026-10-29 12:00:00", "2026-10-29 13:00:00")
        assert response.get_data() == b"MP4-HEADER-MEDIA"
        assert response.headers["X-Archive-Start-Time"] == "2026-10-29 12:00:03"
        assert response.headers["X-Archive-Frame-Rate"] == "15"
        response.close()
    arguments = launch.call_args.args[0]
    assert arguments.index("-r") < arguments.index("-i")
    assert arguments[arguments.index("-r")+1] == "15"
    # A recorder ignoring EndTime must not keep producing an unlimited clip.
    assert arguments.index("-t") > arguments.index("-i")
    assert float(arguments[arguments.index("-t")+1]) == 3600


def test_time_export_filename_identifies_camera_and_range(vms, monkeypatch):
    prepare_response(vms, monkeypatch)
    with vms.app.test_request_context("/api/download"):
        response = vms.create_archive_response(vms.get_camera("dvr_1"), "", "2026-10-29 23:59:00", "2026-10-30 00:01:00", as_attachment=True)
        assert "Test_DVR_20261029_235900-20261030_000100.mp4" in response.headers["Content-Disposition"]
        assert response.headers["Accept-Ranges"] == "none"
        response.close()
