import io
import queue
import struct
import time
from types import SimpleNamespace
from unittest.mock import Mock

import pytest


def test_anonymous_api_and_live_require_auth(client):
    for url in ["/api/cameras", "/api/recordings", "/live/dvr_1/sub/index.m3u8"]:
        assert client.get(url).status_code == 401
    assert client.get("/").status_code == 302
    assert client.get("/health").status_code == 200


def test_login_rejects_wrong_and_accepts_valid_password(client):
    assert client.post("/login", json={"username": "admin", "password": "wrong"}).status_code == 401
    assert client.post("/login", json={"username": "admin", "password": "test-admin-pass"}).status_code == 200
    assert client.get("/api/users").status_code == 200


def test_page_never_embeds_password_hash(admin):
    html = admin.get("/").get_data(as_text=True)
    assert "password_hash" not in html
    assert "scrypt:" not in html
    assert "WEBVMS_USER" in html


def test_camera_listing_hides_password_from_all_roles(viewer):
    result = viewer.get("/api/cameras").get_json()
    assert len(result) == 2
    assert all("password" not in camera for camera in result)
    assert "device-secret" not in str(result)


@pytest.mark.parametrize("endpoint,payload", [
    ("/api/cameras", {"name": "No", "ip": "192.0.2.3"}),
    ("/api/groups", {"name": "No", "camera_ids": []}),
    ("/api/users", {"username": "no", "password": "password"}),
    ("/api/device/capabilities", {"cam_id": "onvif_1"}),
    ("/api/device/ptz", {"cam_id": "onvif_1", "action": "move"}),
    ("/api/device/imaging", {"cam_id": "onvif_1"}),
    ("/api/device/encoder", {"cam_id": "onvif_1"}),
    ("/api/device/system", {"cam_id": "dvr_1", "action": "reboot", "confirm": True}),
])
def test_viewer_cannot_change_or_manage_devices(viewer, endpoint, payload):
    assert viewer.post(endpoint, json=payload).status_code == 403


@pytest.mark.parametrize("changes", [
    {"id": "../outside"}, {"id": "..\\outside"}, {"protocol": "bogus"},
    {"port": 0}, {"port": 65536}, {"channel": 64}, {"channel": -1}, {"rtsp_port": "oops"},
])
def test_camera_validation_rejects_unsafe_or_invalid_fields(admin, changes):
    payload = {"name": "Camera", "ip": "192.0.2.30", "protocol": "dvrip", "port": 34567, "channel": 0}
    payload.update(changes)
    assert admin.post("/api/cameras", json=payload).status_code == 400


def test_camera_edit_preserves_password_and_existing_rtsp_semantics(admin, vms):
    before = vms.get_camera("onvif_1")["password"]
    payload = {"id": "onvif_1", "name": "Renamed", "ip": "192.0.2.20", "protocol": "onvif", "port": 80, "rtsp_port": 554, "rtsp_path": "/new/main", "rtsp_sub_path": "/new/sub", "password": ""}
    response = admin.post("/api/cameras", json=payload)
    assert response.status_code == 200
    assert "password" not in response.get_json()["camera"]
    camera = vms.get_camera("onvif_1")
    assert camera["password"] == before
    assert vms.build_rtsp_live_url(camera, "sub").endswith("/new/main")
    assert vms.build_rtsp_live_url(camera, "main").endswith("/new/main")


def test_camera_delete_removes_group_membership(admin, vms):
    vms.store.save_groups([{"id": "group1", "name": "Group", "camera_ids": ["dvr_1", "onvif_1"]}])
    assert admin.delete("/api/cameras/dvr_1").status_code == 200
    assert vms.store.get_groups()[0]["camera_ids"] == ["onvif_1"]


def test_last_admin_cannot_be_demoted_or_deleted(admin):
    assert admin.put("/api/users/admin", json={"role": "viewer"}).status_code == 400
    assert admin.delete("/api/users/admin").status_code == 400


def test_cross_origin_write_rejected(admin):
    assert admin.post("/api/profile/theme", json={"theme": "light"}, headers={"Origin": "https://unrelated.invalid"}).status_code == 403


def archive_query(**changes):
    value = dict(cam_id="dvr_1", start="2026-10-29 12:00:00", end="2026-10-29 13:00:00", mode="time", path="")
    value.update(changes)
    return value


@pytest.mark.parametrize("endpoint", ["recordings", "playback", "download"])
@pytest.mark.parametrize("changes", [
    {"mode": "bogus", "path": "some-file.h264"},
    {"cam_id": "onvif_1"}, {"start": "bad"},
    {"end": "2026-10-29 12:00:00"}, {"end": "2026-10-28 12:00:00"},
])
def test_archive_validation_before_device_connection(admin, vms, monkeypatch, endpoint, changes):
    connect = Mock(side_effect=AssertionError("must reject before connecting"))
    monkeypatch.setattr(vms, "dvr_connect", connect)
    assert admin.get("/api/" + endpoint, query_string=archive_query(**changes)).status_code == 400
    connect.assert_not_called()


@pytest.mark.parametrize("endpoint,attachment", [("playback", False), ("download", True)])
def test_time_archive_accepts_empty_filename(admin, vms, monkeypatch, endpoint, attachment):
    response = Mock(return_value={"success": True})
    monkeypatch.setattr(vms, "create_archive_response", response)
    assert admin.get("/api/" + endpoint, query_string=archive_query()).status_code == 200
    assert response.call_args.args[1] == ""
    assert response.call_args.kwargs["as_attachment"] is attachment


def test_recording_search_closes_connection_and_parses_midnight(admin, vms, monkeypatch):
    dvr = Mock()
    dvr.list_local_files.return_value = [{"FileName": "/idea0/2026-10-28/001/23.59.00-00.02.00[M].h264"}]
    monkeypatch.setattr(vms, "dvr_connect", Mock(return_value=dvr))
    data = admin.get("/api/recordings", query_string=archive_query(mode="files")).get_json()
    assert data[0]["BeginTime"] == "2026-10-28 23:59:00"
    assert data[0]["EndTime"] == "2026-10-29 00:02:00"
    dvr.close.assert_called_once()


def test_shared_live_release_preserves_other_consumers(vms, qa_path):
    manager = vms.LiveManager(qa_path / "hls")
    proc = Mock()
    proc.poll.return_value = None
    folder = qa_path / "hls" / "dvr_1_sub"
    folder.mkdir()
    manager.streams[("dvr_1", "sub")] = {"process": proc, "directory": folder, "log_file": io.BytesIO(), "leases": {"a": time.monotonic(), "b": time.monotonic()}}
    manager.release("dvr_1", "sub", "a")
    assert ("dvr_1", "sub") in manager.streams
    proc.terminate.assert_not_called()
    manager.release("dvr_1", "sub", "b")
    assert not manager.streams
    proc.terminate.assert_called_once()


def test_archive_mp4_header_is_first_chunk(vms, monkeypatch):
    # A deterministic prefilled worker queue catches the old requeue-header bug.
    chunks = queue.Queue()
    for chunk in [b"MP4-HEADER", b"MP4-BODY", None]:
        chunks.put(chunk)
    monkeypatch.setattr(vms.queue, "Queue", lambda **kwargs: chunks)
    fake_thread = Mock()
    fake_thread.is_alive.return_value = False
    monkeypatch.setattr(vms.threading, "Thread", Mock(return_value=fake_thread))
    monkeypatch.setattr(vms.shutil, "which", lambda _: "test-ffmpeg")
    dvr = Mock()
    dvr.send.return_value = {"Ret": 100}
    monkeypatch.setattr(vms, "dvr_connect", Mock(return_value=dvr))
    with vms.app.test_request_context("/api/playback"):
        response = vms.create_archive_response(vms.get_camera("dvr_1"), "", "2026-10-29 12:00:00", "2026-10-29 13:00:00")
        assert response.get_data() == b"MP4-HEADERMP4-BODY"


def test_dvr_frame_parser_accepts_split_keyframe_and_drops_leading_interframe(vms):
    inter = b"\x00\x00\x01\xfd" + struct.pack("<I", 3) + b"old"
    key = b"\x00\x00\x01\xfc\x02" + b"\x00" * 7 + struct.pack("<I", 3) + b"new"
    next_frame = b"\x00\x00\x01\xfd" + struct.pack("<I", 4) + b"next"
    stream = inter + key + next_frame
    assert list(vms.iter_dvr_video_frames([stream[:11], stream[11:20], stream[20:]])) == [("h264", b"new"), ("h264", b"next")]
