"""Local UI preview with generated data; never opens real camera connections.

Run `python tests/preview_server.py`, open http://127.0.0.1:5080.
This script signs the local browser into a generated account. It is a test helper,
not the normal production entrypoint. Stop it with Ctrl+C after visual QA.
"""
import importlib.util
import os
import sys
import uuid
from datetime import datetime, timedelta
from pathlib import Path


PROJECT = Path(__file__).resolve().parents[1]
data = PROJECT.parent / ".qa-tests" / ("preview-" + uuid.uuid4().hex)
data.mkdir(parents=True)
os.environ["WEBVMS_DATA_DIR"] = str(data)
os.environ["LIVE_ROOT"] = str(data / "live")
os.environ["FLASK_SECRET_KEY"] = "local-preview-generated-accounts-only"
sys.path.insert(0, str(PROJECT))
spec = importlib.util.spec_from_file_location("vms_preview", PROJECT / "app.py")
vms = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = vms
spec.loader.exec_module(vms)

names = ["Главный вход", "Парковка", "Внутренний двор", "Приёмная", "Коридор · 1 этаж", "Склад", "Погрузочная зона", "Периметр"]
cameras = []
for index, name in enumerate(names):
    cameras.append({"id": f"preview_{index + 1}", "name": name, "protocol": "dvrip" if index < 4 else "onvif", "ip": "192.0.2.10" if index < 4 else f"192.0.2.{20 + index}", "port": 34567 if index < 4 else 80, "rtsp_port": 554, "channel": index if index < 4 else 0, "username": "preview", "password": "", "rtsp_path": "/test"})
vms.store.save_cameras(cameras)
vms.store.save_groups([{"id": "outdoor", "name": "Территория", "camera_ids": [c["id"] for c in cameras[:3]]}, {"id": "indoor", "name": "Здание", "camera_ids": [c["id"] for c in cameras[3:6]]}])


def preview_login():
    vms.session["username"] = "admin"


def unavailable(*args, **kwargs):
    return vms.jsonify(error="Тестовый просмотр: камера не подключена"), 503


class PreviewDVR:
    def list_local_files(self, start, end, kind, channel=0):
        beginning, ending = datetime.fromisoformat(start), datetime.fromisoformat(end)
        span = ending - beginning
        result = []
        for index in range(6):
            first = beginning + span * (index / 6)
            last = min(ending, first + span * 0.12)
            result.append({"FileName": f"/preview/segment-{index}.h264", "BeginTime": first.strftime("%Y-%m-%d %H:%M:%S"), "EndTime": last.strftime("%Y-%m-%d %H:%M:%S"), "Channel": channel})
        return result

    def get_system_info(self):
        return {"Model": "Preview NVR", "Firmware": "test", "VideoInChannel": 4}

    def get_time(self):
        return datetime.now().isoformat(timespec="seconds")

    def get_netcommon(self):
        return {"HostIP": "192.0.2.10", "HostName": "preview-nvr"}

    def close(self):
        pass


def refuse_onvif(*args, **kwargs):
    raise RuntimeError("Preview mode: no real camera connection")


vms.app.before_request_funcs[None].insert(0, preview_login)
vms.app.view_functions["live_playlist"] = unavailable
vms.app.view_functions["live_segment"] = unavailable
vms.app.view_functions["api_playback"] = unavailable
vms.app.view_functions["api_download"] = unavailable
vms.app.view_functions["api_camera_test"] = unavailable
vms.dvr_connect = lambda camera: PreviewDVR()
vms.onvif_connect = refuse_onvif
if __name__ == "__main__":
    print("Generated-data preview; real camera/network connections disabled.", flush=True)
    vms.app.run(host="127.0.0.1", port=5080, debug=False, threaded=True)
