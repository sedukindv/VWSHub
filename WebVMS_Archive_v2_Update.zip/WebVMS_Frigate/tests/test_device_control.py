"""Protocol contracts tested against fake devices; never contact the user's LAN."""
from datetime import datetime
from types import SimpleNamespace as NS
from unittest.mock import Mock

import pytest


@pytest.fixture
def device(vms, monkeypatch):
    config = NS(token="enc", Encoding="H264", Resolution=NS(Width=1920, Height=1080),
                RateControl=NS(FrameRateLimit=25, BitrateLimit=4096), Quality=4.0)
    options = NS(H264=NS(ResolutionsAvailable=[NS(Width=1920, Height=1080), NS(Width=1280, Height=720)],
                         FrameRateRange=NS(Min=1, Max=30)),
                 Extension=NS(H264=NS(BitrateRange=NS(Min=256, Max=8192))),
                 QualityRange=NS(Min=1, Max=6))
    profile = NS(token="main", Name="Main", VideoSourceConfiguration=NS(SourceToken="source"),
                 VideoEncoderConfiguration=NS(token="enc"), PTZConfiguration=NS(token="ptz-config"))
    media = Mock()
    media.GetProfiles.return_value = [profile]
    media.GetVideoEncoderConfiguration.return_value = config
    media.GetVideoEncoderConfigurationOptions.return_value = options
    ptz = Mock()
    ptz.GetPresets.return_value = [NS(token="home", Name="Home")]
    imaging = Mock()
    imaging.GetOptions.return_value = NS(Brightness=NS(Min=0, Max=100), Contrast=NS(Min=0, Max=10))
    imaging.GetImagingSettings.return_value = NS(Brightness=50, Contrast=3)
    system = Mock()
    system.GetCapabilities.return_value = NS(PTZ=NS(XAddr="/ptz"), Imaging=NS(XAddr="/imaging"))
    system.GetDeviceInformation.return_value = NS(Manufacturer="Test", Model="Fake")
    system.GetSystemDateAndTime.return_value = NS(DaylightSavings=False, TimeZone=NS(TZ="UTC0"))
    client = NS(services={"media": media, "ptz": ptz, "imaging": imaging, "devicemgmt": system})
    connect = Mock(return_value=client)
    monkeypatch.setattr(vms, "onvif_connect", connect)
    return NS(client=client, connect=connect, media=media, ptz=ptz, imaging=imaging, system=system, config=config)


def test_onvif_capabilities_follow_profiles_and_services(admin, device):
    response = admin.post("/api/device/capabilities", json={"cam_id": "onvif_1"})
    assert response.status_code == 200
    result = response.get_json()
    assert result["capabilities"]["ptz"] is True
    assert result["capabilities"]["imaging"] is True
    assert result["profiles"][0]["video_source_token"] == "source"


@pytest.mark.parametrize("value", [float("nan"), float("inf"), -1.01, 1.01, True, "oops"])
def test_ptz_rejects_invalid_velocity_without_device_connection(admin, device, value):
    assert admin.post("/api/device/ptz", json={"cam_id": "onvif_1", "action": "move", "pan": value}).status_code == 400
    device.connect.assert_not_called()


def test_ptz_device_timeout_limits_motion_after_lost_browser(admin, device):
    response = admin.post("/api/device/ptz", json={"cam_id": "onvif_1", "profile_token": "main", "action": "move", "pan": 0.4, "tilt": -0.3})
    assert response.status_code == 200
    payload = device.ptz.ContinuousMove.call_args.args[0]
    assert payload["ProfileToken"] == "main"
    assert 0 < payload["Timeout"].total_seconds() <= 1
    assert payload["Velocity"] == {"PanTilt": {"x": 0.4, "y": -0.3}}
    assert admin.post("/api/device/ptz", json={"cam_id": "onvif_1", "action": "stop"}).status_code == 200
    device.ptz.Stop.assert_called_with({"ProfileToken": "main", "PanTilt": True, "Zoom": True})
    assert device.connect.call_count == 1


def test_ptz_fixed_profile_cannot_move(admin, device):
    device.media.GetProfiles.return_value[0].PTZConfiguration = None
    assert admin.post("/api/device/ptz", json={"cam_id": "onvif_1", "action": "move", "zoom": 0.5}).status_code == 501
    device.ptz.ContinuousMove.assert_not_called()


def test_imaging_validates_ranges_reported_by_camera(admin, device):
    response = admin.post("/api/device/imaging", json={"cam_id": "onvif_1", "settings": {"Brightness": 101}})
    assert response.status_code == 400
    device.imaging.SetImagingSettings.assert_not_called()
    response = admin.post("/api/device/imaging", json={"cam_id": "onvif_1", "settings": {"Brightness": 73}})
    assert response.status_code == 200
    device.imaging.SetImagingSettings.assert_called_once_with({"VideoSourceToken": "source", "ImagingSettings": {"Brightness": 73.0}, "ForcePersistence": True})
    assert response.get_json()["options"]["Brightness"] == {"Min": 0, "Max": 100}


def test_encoder_updates_only_supported_values_and_preserves_unedited_fields(admin, device):
    response = admin.post("/api/device/encoder", json={"cam_id": "onvif_1", "settings": {"width": 1280, "height": 720, "fps": 15, "bitrate": 2048}})
    assert response.status_code == 200
    assert device.config.Resolution.Width == 1280
    assert device.config.RateControl.FrameRateLimit == 15
    assert device.config.RateControl.BitrateLimit == 2048
    assert device.config.Quality == 4
    device.media.SetVideoEncoderConfiguration.assert_called_once_with({"Configuration": device.config, "ForcePersistence": True})
    assert response.get_json()["options"]["bitrate"] == {"Min": 256, "Max": 8192}


def test_encoder_rejects_unsupported_resolution_before_persistence(admin, device):
    assert admin.post("/api/device/encoder", json={"cam_id": "onvif_1", "settings": {"width": 4000, "height": 3000}}).status_code == 400
    device.media.SetVideoEncoderConfiguration.assert_not_called()


def test_reboot_requires_explicit_confirmation(admin, device):
    assert admin.post("/api/device/system", json={"cam_id": "onvif_1", "action": "reboot"}).status_code == 400
    device.connect.assert_not_called()
    device.system.SystemReboot.return_value = "Rebooting"
    assert admin.post("/api/device/system", json={"cam_id": "onvif_1", "action": "reboot", "confirm": True}).status_code == 200
    device.system.SystemReboot.assert_called_once_with()


def test_onvif_time_is_utc_and_preserves_timezone(admin, device):
    response = admin.post("/api/device/system", json={"cam_id": "onvif_1", "action": "time", "utc": "2026-10-29T12:34:56+06:00"})
    assert response.status_code == 200
    payload = device.system.SetSystemDateAndTime.call_args.args[0]
    assert payload["UTCDateTime"]["Time"] == {"Hour": 6, "Minute": 34, "Second": 56}
    assert payload["TimeZone"].TZ == "UTC0"


def test_dvrip_time_uses_explicit_local_clock_and_closes_connection(admin, vms, monkeypatch):
    dvr = Mock()
    dvr.set_time.return_value = {"Ret": 100}
    monkeypatch.setattr(vms, "dvr_connect", Mock(return_value=dvr))
    assert admin.post("/api/device/system", json={"cam_id": "dvr_1", "action": "time", "local_time": "2026-10-29T18:45:00"}).status_code == 200
    dvr.set_time.assert_called_once_with(datetime(2026, 10, 29, 18, 45))
    dvr.close.assert_called_once()


def test_device_errors_never_echo_credential_bearing_urls(admin, device):
    device.imaging.GetOptions.side_effect = RuntimeError("failed rtsp://admin:secret@192.0.2.3/main")
    response = admin.post("/api/device/imaging", json={"cam_id": "onvif_1"})
    assert response.status_code == 502
    assert "secret" not in response.get_data(as_text=True)


def test_recording_group_keeps_actual_intervals_across_two_minute_gap(vms):
    records = [
        {"BeginTime": "2026-10-29 12:00:00", "EndTime": "2026-10-29 12:05:00", "FileName": "first.h264"},
        {"BeginTime": "2026-10-29 12:07:00", "EndTime": "2026-10-29 12:10:00", "FileName": "second.h264"},
    ]
    groups = vms._group_recordings(records)
    assert len(groups) == 1
    assert groups[0]["Files"] == 2
    assert groups[0]["BeginTime"] == "2026-10-29 12:00:00"
    assert groups[0]["EndTime"] == "2026-10-29 12:10:00"
    assert groups[0]["Intervals"] == [
        {"BeginTime": "2026-10-29 12:00:00", "EndTime": "2026-10-29 12:05:00"},
        {"BeginTime": "2026-10-29 12:07:00", "EndTime": "2026-10-29 12:10:00"},
    ]
