"""All API tests use generated users, keys and TEST-NET cameras in a temp folder."""
import importlib.util
import sys
import uuid
from pathlib import Path

import pytest


PROJECT = Path(__file__).resolve().parents[1]


@pytest.fixture
def qa_path():
    # Avoid platform-specific restrictive mkdtemp ACLs in sandboxed Windows runs.
    target = PROJECT.parent / ".qa-tests" / uuid.uuid4().hex
    target.mkdir(parents=True)
    return target


@pytest.fixture(scope="session")
def vms():
    import os
    data = PROJECT.parent / ".qa-tests" / uuid.uuid4().hex
    data.mkdir(parents=True)
    os.environ["WEBVMS_DATA_DIR"] = str(data)
    os.environ["LIVE_ROOT"] = str(data / "live")
    os.environ["FLASK_SECRET_KEY"] = "isolated-test-session-secret"
    sys.path.insert(0, str(PROJECT))
    spec = importlib.util.spec_from_file_location("vms_qa_app", PROJECT / "app.py")
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    module.app.config.update(TESTING=True)
    yield module
    module.live_manager.stop_all()


@pytest.fixture(autouse=True)
def reset_data(vms):
    from werkzeug.security import generate_password_hash
    vms.store.save_users([
        {"username": "admin", "password_hash": generate_password_hash("test-admin-pass", method="pbkdf2:sha256:1000"), "role": "admin", "theme": "dark"},
        {"username": "viewer", "password_hash": generate_password_hash("test-viewer-pass", method="pbkdf2:sha256:1000"), "role": "viewer", "theme": "dark"},
    ])
    vms.store.save_cameras([
        {"id": "dvr_1", "name": "Test DVR", "protocol": "dvrip", "ip": "192.0.2.10", "port": 34567, "rtsp_port": 554, "channel": 0, "username": "admin", "password": vms.enc_pwd("device-secret")},
        {"id": "onvif_1", "name": "Test ONVIF", "protocol": "onvif", "ip": "192.0.2.20", "port": 80, "rtsp_port": 554, "rtsp_path": "/main", "rtsp_sub_path": "/sub", "username": "admin", "password": vms.enc_pwd("device-secret")},
    ])
    vms.store.save_groups([])


@pytest.fixture
def client(vms):
    return vms.app.test_client()


@pytest.fixture
def admin(client):
    with client.session_transaction() as session:
        session["username"] = "admin"
    return client


@pytest.fixture
def viewer(client):
    with client.session_transaction() as session:
        session["username"] = "viewer"
    return client
